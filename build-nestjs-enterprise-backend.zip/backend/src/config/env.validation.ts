import * as Joi from 'joi';

export function validateEnv(config: Record<string, unknown>) {
  const schema = Joi.object({
    NODE_ENV: Joi.string().valid('development', 'production', 'test').default('development'),
    PORT: Joi.number().default(3001),
    DATABASE_URL: Joi.string().required(),
    JWT_SECRET: Joi.string().min(32).required(),
    JWT_EXPIRES_IN: Joi.string().default('7d'),
    JWT_REFRESH_SECRET: Joi.string().min(32).required(),
    JWT_REFRESH_EXPIRES_IN: Joi.string().default('30d'),
    API_VERSION: Joi.string().default('v1'),
    API_PREFIX: Joi.string().default('api'),
    THROTTLE_TTL: Joi.number().default(60000),
    THROTTLE_LIMIT: Joi.number().default(100),
  }).unknown(true);

  const { error, value } = schema.validate(config, { abortEarly: false });

  if (error) {
    const messages = error.details.map((d) => d.message).join('; ');
    throw new Error(`⚠️  Environment validation failed: ${messages}`);
  }

  return value;
}
