import { registerAs } from '@nestjs/config';

export default registerAs('app', () => ({
  nodeEnv: process.env.NODE_ENV || 'development',
  port: parseInt(process.env.PORT, 10) || 3001,
  apiVersion: process.env.API_VERSION || 'v1',
  apiPrefix: process.env.API_PREFIX || 'api',
  corsOrigin: process.env.CORS_ORIGIN?.split(',') || ['http://localhost:5173'],
  throttleTtl: parseInt(process.env.THROTTLE_TTL, 10) || 60000,
  throttleLimit: parseInt(process.env.THROTTLE_LIMIT, 10) || 100,
  logLevel: process.env.LOG_LEVEL || 'info',
}));
