// =============================================================
// GLOBAL EXCEPTION FILTER
// =============================================================

import {
  ExceptionFilter,
  Catch,
  ArgumentsHost,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';
import { Prisma } from '@prisma/client';

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  private readonly logger = new Logger(GlobalExceptionFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const response = ctx.getResponse<Response>();
    const request = ctx.getRequest<Request>();

    let status = HttpStatus.INTERNAL_SERVER_ERROR;
    let message = 'Internal server error';
    let errors: any = null;
    let code = 'INTERNAL_ERROR';

    // ─── HttpException ──────────────────────────────────────
    if (exception instanceof HttpException) {
      status = exception.getStatus();
      const exceptionResponse = exception.getResponse();
      if (typeof exceptionResponse === 'string') {
        message = exceptionResponse;
      } else if (typeof exceptionResponse === 'object') {
        const resp = exceptionResponse as any;
        message = resp.message || message;
        errors = Array.isArray(resp.message) ? resp.message : null;
        if (errors) message = 'Validation failed';
      }
      code = this.getErrorCode(status);
    }

    // ─── Prisma Errors ──────────────────────────────────────
    else if (exception instanceof Prisma.PrismaClientKnownRequestError) {
      const prismaError = this.handlePrismaError(exception);
      status = prismaError.status;
      message = prismaError.message;
      code = prismaError.code;
    }

    else if (exception instanceof Prisma.PrismaClientValidationError) {
      status = HttpStatus.BAD_REQUEST;
      message = 'Invalid data provided';
      code = 'VALIDATION_ERROR';
    }

    // ─── Unknown Errors ─────────────────────────────────────
    else if (exception instanceof Error) {
      this.logger.error(`Unhandled error: ${exception.message}`, exception.stack);
      message = process.env.NODE_ENV === 'production' ? 'Internal server error' : exception.message;
    }

    this.logger.error(
      `${request.method} ${request.url} → ${status} — ${message}`,
      exception instanceof Error ? exception.stack : String(exception),
    );

    response.status(status).json({
      success: false,
      statusCode: status,
      code,
      message,
      errors,
      timestamp: new Date().toISOString(),
      path: request.url,
      method: request.method,
    });
  }

  private handlePrismaError(error: Prisma.PrismaClientKnownRequestError) {
    switch (error.code) {
      case 'P2002':
        const field = (error.meta?.target as string[])?.join(', ') || 'field';
        return { status: HttpStatus.CONFLICT, message: `${field} already exists`, code: 'DUPLICATE_ENTRY' };
      case 'P2025':
        return { status: HttpStatus.NOT_FOUND, message: 'Record not found', code: 'NOT_FOUND' };
      case 'P2003':
        return { status: HttpStatus.BAD_REQUEST, message: 'Foreign key constraint failed', code: 'FK_CONSTRAINT' };
      case 'P2014':
        return { status: HttpStatus.BAD_REQUEST, message: 'Relation violation', code: 'RELATION_ERROR' };
      default:
        this.logger.error(`Prisma error ${error.code}: ${error.message}`);
        return { status: HttpStatus.INTERNAL_SERVER_ERROR, message: 'Database error', code: 'DB_ERROR' };
    }
  }

  private getErrorCode(status: number): string {
    const codes: Record<number, string> = {
      400: 'BAD_REQUEST',
      401: 'UNAUTHORIZED',
      403: 'FORBIDDEN',
      404: 'NOT_FOUND',
      409: 'CONFLICT',
      422: 'UNPROCESSABLE_ENTITY',
      429: 'TOO_MANY_REQUESTS',
      500: 'INTERNAL_ERROR',
      503: 'SERVICE_UNAVAILABLE',
    };
    return codes[status] || 'UNKNOWN_ERROR';
  }
}
