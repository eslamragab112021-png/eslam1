// =============================================================
// PRISMA SERVICE — Database Connection & Lifecycle
// =============================================================

import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common';
import { PrismaClient } from '@prisma/client';

@Injectable()
export class PrismaService extends PrismaClient implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);

  constructor() {
    super({
      log: [
        { level: 'query', emit: 'event' },
        { level: 'error', emit: 'stdout' },
        { level: 'warn', emit: 'stdout' },
      ],
      errorFormat: 'pretty',
    });
  }

  async onModuleInit() {
    try {
      await this.$connect();
      this.logger.log('✅ Database connected successfully (Neon PostgreSQL)');

      // Log slow queries in development
      if (process.env.NODE_ENV !== 'production') {
        (this as any).$on('query', (e: any) => {
          if (e.duration > 500) {
            this.logger.warn(`⚠️  Slow query (${e.duration}ms): ${e.query}`);
          }
        });
      }
    } catch (error) {
      this.logger.error('❌ Database connection failed:', error);
      throw error;
    }
  }

  async onModuleDestroy() {
    await this.$disconnect();
    this.logger.log('Database disconnected');
  }

  // ─── Helper: Clean up test data ─────────────────────────────
  async cleanDatabase() {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('Cannot clean database in production');
    }
    const tableNames = [
      'audit_logs', 'activity_logs', 'notifications', 'leave_requests',
      'attendance_records', 'role_permissions', 'employees', 'departments',
      'shifts', 'users', 'permissions', 'roles', 'companies',
    ];
    for (const table of tableNames) {
      await this.$executeRawUnsafe(`TRUNCATE TABLE "${table}" CASCADE;`);
    }
  }
}
