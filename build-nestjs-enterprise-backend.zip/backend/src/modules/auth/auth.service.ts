// =============================================================
// AUTH SERVICE — Authentication & Token Management
// =============================================================

import {
  Injectable,
  UnauthorizedException,
  BadRequestException,
  ConflictException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcryptjs';
import { PrismaService } from '../../prisma/prisma.service';
import { LoginDto } from './dto/login.dto';
import { RegisterDto } from './dto/register.dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly configService: ConfigService,
  ) {}

  async validateUser(email: string, password: string) {
    const user = await this.prisma.user.findUnique({
      where: { email: email.toLowerCase() },
      include: {
        role: {
          include: { permissions: { include: { permission: true } } },
        },
        company: true,
        employee: { include: { department: true } },
      },
    });

    if (!user) throw new UnauthorizedException('Invalid email or password');
    if (user.status !== 'ACTIVE') throw new UnauthorizedException('Account is not active');

    const isValid = await bcrypt.compare(password, user.password);
    if (!isValid) throw new UnauthorizedException('Invalid email or password');

    return user;
  }

  async login(loginDto: LoginDto, ipAddress?: string) {
    const user = await this.validateUser(loginDto.email, loginDto.password);

    const tokens = await this.generateTokens(user.id, user.email, user.role?.slug);

    // Update last login
    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date(), lastLoginIp: ipAddress, refreshToken: tokens.refreshToken },
    });

    // Log activity
    await this.prisma.activityLog.create({
      data: {
        userId: user.id,
        action: 'LOGIN',
        module: 'auth',
        description: `User ${user.email} logged in successfully`,
        ipAddress,
      },
    });

    // Audit log
    await this.prisma.auditLog.create({
      data: {
        userId: user.id,
        action: 'LOGIN',
        resource: 'auth',
        resourceId: user.id,
        status: 'success',
        ipAddress,
      },
    });

    this.logger.log(`User logged in: ${user.email} from ${ipAddress}`);

    const { password: _, refreshToken: __, ...safeUser } = user;

    return {
      message: 'Login successful',
      data: {
        user: safeUser,
        tokens,
      },
    };
  }

  async register(registerDto: RegisterDto) {
    const existing = await this.prisma.user.findUnique({
      where: { email: registerDto.email.toLowerCase() },
    });

    if (existing) throw new ConflictException('Email address already registered');

    const hashedPassword = await bcrypt.hash(registerDto.password, 12);

    // Find default employee role
    const employeeRole = await this.prisma.role.findFirst({
      where: { slug: 'employee' },
    });

    const company = await this.prisma.company.findFirst();

    const user = await this.prisma.user.create({
      data: {
        email: registerDto.email.toLowerCase(),
        password: hashedPassword,
        firstName: registerDto.firstName,
        lastName: registerDto.lastName,
        phone: registerDto.phone,
        status: 'ACTIVE',
        emailVerified: false,
        roleId: employeeRole?.id,
        companyId: company?.id,
      },
      include: { role: true, company: true },
    });

    const tokens = await this.generateTokens(user.id, user.email, user.role?.slug);

    await this.prisma.auditLog.create({
      data: {
        userId: user.id,
        action: 'CREATE',
        resource: 'auth',
        resourceId: user.id,
        status: 'success',
      },
    });

    const { password: _, ...safeUser } = user;

    return {
      message: 'Registration successful',
      data: { user: safeUser, tokens },
    };
  }

  async refreshTokens(refreshToken: string) {
    try {
      const payload = this.jwtService.verify(refreshToken, {
        secret: this.configService.get('jwt.refreshSecret'),
      });

      const user = await this.prisma.user.findUnique({
        where: { id: payload.sub },
        include: { role: true },
      });

      if (!user || !user.refreshToken) throw new UnauthorizedException('Invalid refresh token');

      const isValid = refreshToken === user.refreshToken;
      if (!isValid) throw new UnauthorizedException('Refresh token mismatch');

      const tokens = await this.generateTokens(user.id, user.email, user.role?.slug);

      await this.prisma.user.update({
        where: { id: user.id },
        data: { refreshToken: tokens.refreshToken },
      });

      return { message: 'Tokens refreshed', data: { tokens } };
    } catch {
      throw new UnauthorizedException('Invalid or expired refresh token');
    }
  }

  async logout(userId: string) {
    await this.prisma.user.update({
      where: { id: userId },
      data: { refreshToken: null },
    });

    await this.prisma.activityLog.create({
      data: { userId, action: 'LOGOUT', module: 'auth', description: 'User logged out' },
    });

    return { message: 'Logged out successfully', data: null };
  }

  async getProfile(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: {
        role: { include: { permissions: { include: { permission: true } } } },
        company: true,
        employee: { include: { department: true, shift: true } },
      },
    });

    if (!user) throw new UnauthorizedException('User not found');

    const { password: _, refreshToken: __, ...safeUser } = user;

    return { message: 'Profile retrieved', data: safeUser };
  }

  async changePassword(userId: string, currentPassword: string, newPassword: string) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new UnauthorizedException('User not found');

    const isValid = await bcrypt.compare(currentPassword, user.password);
    if (!isValid) throw new BadRequestException('Current password is incorrect');

    const hashedPassword = await bcrypt.hash(newPassword, 12);
    await this.prisma.user.update({ where: { id: userId }, data: { password: hashedPassword } });

    await this.prisma.auditLog.create({
      data: { userId, action: 'UPDATE', resource: 'auth', status: 'success' },
    });

    return { message: 'Password changed successfully', data: null };
  }

  private async generateTokens(userId: string, email: string, role?: string) {
    const payload = { sub: userId, email, role };

    const [accessToken, refreshToken] = await Promise.all([
      this.jwtService.signAsync(payload, {
        secret: this.configService.get('jwt.secret'),
        expiresIn: this.configService.get('jwt.expiresIn', '7d'),
      }),
      this.jwtService.signAsync(payload, {
        secret: this.configService.get('jwt.refreshSecret'),
        expiresIn: this.configService.get('jwt.refreshExpiresIn', '30d'),
      }),
    ]);

    return { accessToken, refreshToken };
  }
}
