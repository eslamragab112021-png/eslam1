// =============================================================
// USERS SERVICE
// =============================================================

import { Injectable, NotFoundException, ConflictException, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PaginationDto, createPaginatedResult } from '../../common/dto/pagination.dto';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import * as bcrypt from 'bcryptjs';
import { Prisma } from '@prisma/client';

@Injectable()
export class UsersService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(query: PaginationDto & { status?: string; roleId?: string; companyId?: string }) {
    const { page = 1, limit = 10, search, sortBy = 'createdAt', sortOrder = 'desc', status, roleId, companyId } = query;
    const skip = (page - 1) * limit;

    const where: Prisma.UserWhereInput = {
      ...(search && {
        OR: [
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
        ],
      }),
      ...(status && { status: status as any }),
      ...(roleId && { roleId }),
      ...(companyId && { companyId }),
    };

    const [data, total] = await Promise.all([
      this.prisma.user.findMany({
        where,
        include: { role: true, company: true, employee: { include: { department: true } } },
        orderBy: { [sortBy]: sortOrder },
        skip,
        take: limit,
      }),
      this.prisma.user.count({ where }),
    ]);

    // Remove passwords
    const safeData = data.map(({ password, refreshToken, ...u }) => u);

    return { message: 'Users retrieved', data: createPaginatedResult(safeData, total, page, limit) };
  }

  async findOne(id: string) {
    const user = await this.prisma.user.findUnique({
      where: { id },
      include: {
        role: { include: { permissions: { include: { permission: true } } } },
        company: true,
        employee: { include: { department: true, shift: true } },
        notifications: { take: 5, orderBy: { createdAt: 'desc' } },
      },
    });

    if (!user) throw new NotFoundException(`User with ID ${id} not found`);

    const { password, refreshToken, ...safeUser } = user;
    return { message: 'User retrieved', data: safeUser };
  }

  async create(createUserDto: CreateUserDto) {
    const existing = await this.prisma.user.findUnique({ where: { email: createUserDto.email } });
    if (existing) throw new ConflictException('Email already in use');

    const hashedPassword = await bcrypt.hash(createUserDto.password, 12);
    const user = await this.prisma.user.create({
      data: { ...createUserDto, password: hashedPassword, email: createUserDto.email.toLowerCase() },
      include: { role: true, company: true },
    });

    const { password, refreshToken, ...safeUser } = user;
    return { message: 'User created successfully', data: safeUser };
  }

  async update(id: string, updateUserDto: UpdateUserDto) {
    await this.findOne(id);

    if (updateUserDto.email) {
      const existing = await this.prisma.user.findFirst({
        where: { email: updateUserDto.email, NOT: { id } },
      });
      if (existing) throw new ConflictException('Email already in use');
    }

    const user = await this.prisma.user.update({
      where: { id },
      data: updateUserDto,
      include: { role: true, company: true },
    });

    const { password, refreshToken, ...safeUser } = user;
    return { message: 'User updated successfully', data: safeUser };
  }

  async remove(id: string) {
    await this.findOne(id);
    await this.prisma.user.delete({ where: { id } });
    return { message: 'User deleted successfully', data: null };
  }

  async updateStatus(id: string, status: string) {
    await this.findOne(id);
    const user = await this.prisma.user.update({
      where: { id },
      data: { status: status as any },
    });
    const { password, refreshToken, ...safeUser } = user;
    return { message: `User status updated to ${status}`, data: safeUser };
  }

  async getStats() {
    const [total, active, inactive, suspended] = await Promise.all([
      this.prisma.user.count(),
      this.prisma.user.count({ where: { status: 'ACTIVE' } }),
      this.prisma.user.count({ where: { status: 'INACTIVE' } }),
      this.prisma.user.count({ where: { status: 'SUSPENDED' } }),
    ]);
    return { message: 'User stats', data: { total, active, inactive, suspended } };
  }
}
