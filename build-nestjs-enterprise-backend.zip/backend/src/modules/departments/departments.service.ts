import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PaginationDto, createPaginatedResult } from '../../common/dto/pagination.dto';
import { Prisma } from '@prisma/client';

@Injectable()
export class DepartmentsService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(query: PaginationDto & { companyId?: string; isActive?: string }) {
    const { page = 1, limit = 10, search, sortBy = 'name', sortOrder = 'asc', companyId, isActive } = query;
    const skip = (page - 1) * limit;

    const where: Prisma.DepartmentWhereInput = {
      ...(search && { OR: [{ name: { contains: search, mode: 'insensitive' } }, { code: { contains: search, mode: 'insensitive' } }] }),
      ...(companyId && { companyId }),
      ...(isActive !== undefined && { isActive: isActive === 'true' }),
    };

    const [data, total] = await Promise.all([
      this.prisma.department.findMany({
        where,
        include: {
          company: { select: { id: true, name: true } },
          manager: { select: { id: true, firstName: true, lastName: true, jobTitle: true } },
          parent: { select: { id: true, name: true } },
          _count: { select: { employees: true, children: true } },
        },
        orderBy: { [sortBy]: sortOrder },
        skip,
        take: limit,
      }),
      this.prisma.department.count({ where }),
    ]);

    return { message: 'Departments retrieved', data: createPaginatedResult(data, total, page, limit) };
  }

  async findOne(id: string) {
    const dept = await this.prisma.department.findUnique({
      where: { id },
      include: {
        company: true,
        manager: true,
        parent: true,
        children: true,
        employees: { include: { user: { select: { email: true } } }, take: 20 },
        _count: { select: { employees: true } },
      },
    });
    if (!dept) throw new NotFoundException(`Department ${id} not found`);
    return { message: 'Department retrieved', data: dept };
  }

  async create(dto: any) {
    const existing = await this.prisma.department.findFirst({ where: { code: dto.code, companyId: dto.companyId } });
    if (existing) throw new ConflictException('Department code already exists in this company');

    const dept = await this.prisma.department.create({
      data: dto,
      include: { company: true, manager: true },
    });
    return { message: 'Department created', data: dept };
  }

  async update(id: string, dto: any) {
    await this.findOne(id);
    const dept = await this.prisma.department.update({ where: { id }, data: dto, include: { company: true } });
    return { message: 'Department updated', data: dept };
  }

  async remove(id: string) {
    const dept = await this.prisma.department.findUnique({ where: { id }, include: { _count: { select: { employees: true } } } });
    if (!dept) throw new NotFoundException(`Department ${id} not found`);
    if ((dept as any)._count.employees > 0) throw new ConflictException('Cannot delete department with active employees');

    await this.prisma.department.delete({ where: { id } });
    return { message: 'Department deleted', data: null };
  }

  async getTree(companyId: string) {
    const depts = await this.prisma.department.findMany({
      where: { companyId },
      include: { children: true, manager: { select: { firstName: true, lastName: true } }, _count: { select: { employees: true } } },
    });
    const roots = depts.filter(d => !d.parentId);
    return { message: 'Department tree', data: roots };
  }
}
