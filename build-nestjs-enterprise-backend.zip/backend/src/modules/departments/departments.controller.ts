import { Controller, Get, Post, Put, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { DepartmentsService } from './departments.service';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('departments')
@ApiBearerAuth('JWT-auth')
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'departments', version: '1' })
export class DepartmentsController {
  constructor(private readonly service: DepartmentsService) {}

  @Get() @ApiOperation({ summary: 'Get all departments' })
  findAll(@Query() query: PaginationDto & { companyId?: string }) { return this.service.findAll(query); }

  @Get('tree/:companyId') @ApiOperation({ summary: 'Get department hierarchy tree' })
  getTree(@Param('companyId', ParseUUIDPipe) companyId: string) { return this.service.getTree(companyId); }

  @Get(':id') @ApiOperation({ summary: 'Get department by ID' })
  findOne(@Param('id', ParseUUIDPipe) id: string) { return this.service.findOne(id); }

  @Post() @Roles('super-admin', 'hr-manager') @ApiOperation({ summary: 'Create department' })
  create(@Body() dto: any) { return this.service.create(dto); }

  @Put(':id') @Roles('super-admin', 'hr-manager') @ApiOperation({ summary: 'Update department' })
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: any) { return this.service.update(id, dto); }

  @Delete(':id') @Roles('super-admin') @ApiOperation({ summary: 'Delete department' })
  remove(@Param('id', ParseUUIDPipe) id: string) { return this.service.remove(id); }
}
