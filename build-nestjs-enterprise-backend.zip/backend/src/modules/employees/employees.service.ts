// =============================================================
// EMPLOYEES SERVICE
// =============================================================

import { Injectable, NotFoundException, ConflictException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { PaginationDto, createPaginatedResult } from '../../common/dto/pagination.dto';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';
import { Prisma } from '@prisma/client';

const EMPLOYEE_INCLUDE = {
  user: { select: { id: true, email: true, status: true, lastLoginAt: true } },
  department: true,
  shift: true,
  manager: { select: { id: true, firstName: true, lastName: true, jobTitle: true } },
  company: { select: { id: true, name: true, slug: true } },
} as const;

@Injectable()
export class EmployeesService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(query: PaginationDto & {
    status?: string;
    departmentId?: string;
    companyId?: string;
    employmentType?: string;
  }) {
    const { page = 1, limit = 10, search, sortBy = 'createdAt', sortOrder = 'desc', status, departmentId, companyId, employmentType } = query;
    const skip = (page - 1) * limit;

    const where: Prisma.EmployeeWhereInput = {
      ...(search && {
        OR: [
          { firstName: { contains: search, mode: 'insensitive' } },
          { lastName: { contains: search, mode: 'insensitive' } },
          { email: { contains: search, mode: 'insensitive' } },
          { employeeId: { contains: search, mode: 'insensitive' } },
          { jobTitle: { contains: search, mode: 'insensitive' } },
        ],
      }),
      ...(status && { status: status as any }),
      ...(departmentId && { departmentId }),
      ...(companyId && { companyId }),
      ...(employmentType && { employmentType: employmentType as any }),
    };

    const [data, total] = await Promise.all([
      this.prisma.employee.findMany({
        where,
        include: EMPLOYEE_INCLUDE,
        orderBy: { [sortBy]: sortOrder },
        skip,
        take: limit,
      }),
      this.prisma.employee.count({ where }),
    ]);

    return { message: 'Employees retrieved', data: createPaginatedResult(data, total, page, limit) };
  }

  async findOne(id: string) {
    const employee = await this.prisma.employee.findUnique({
      where: { id },
      include: {
        ...EMPLOYEE_INCLUDE,
        subordinates: { select: { id: true, firstName: true, lastName: true, jobTitle: true } },
        attendanceRecords: { take: 10, orderBy: { date: 'desc' } },
        leaveRequests: { take: 5, orderBy: { createdAt: 'desc' } },
      },
    });

    if (!employee) throw new NotFoundException(`Employee with ID ${id} not found`);
    return { message: 'Employee retrieved', data: employee };
  }

  async findByEmployeeId(employeeId: string) {
    const employee = await this.prisma.employee.findUnique({
      where: { employeeId },
      include: EMPLOYEE_INCLUDE,
    });

    if (!employee) throw new NotFoundException(`Employee ${employeeId} not found`);
    return { message: 'Employee retrieved', data: employee };
  }

  async create(dto: CreateEmployeeDto) {
    const existing = await this.prisma.employee.findFirst({
      where: { OR: [{ email: dto.email }, { employeeId: dto.employeeId }] },
    });
    if (existing) throw new ConflictException('Employee with this email or ID already exists');

    const employee = await this.prisma.employee.create({
      data: dto as any,
      include: EMPLOYEE_INCLUDE,
    });

    // Update department headcount
    if (dto.departmentId) {
      await this.prisma.department.update({
        where: { id: dto.departmentId },
        data: { headCount: { increment: 1 } },
      });
    }

    return { message: 'Employee created successfully', data: employee };
  }

  async update(id: string, dto: UpdateEmployeeDto) {
    const existing = await this.prisma.employee.findUnique({ where: { id } });
    if (!existing) throw new NotFoundException(`Employee with ID ${id} not found`);

    const employee = await this.prisma.employee.update({
      where: { id },
      data: dto as any,
      include: EMPLOYEE_INCLUDE,
    });

    return { message: 'Employee updated successfully', data: employee };
  }

  async remove(id: string) {
    const employee = await this.prisma.employee.findUnique({ where: { id } });
    if (!employee) throw new NotFoundException(`Employee with ID ${id} not found`);

    await this.prisma.employee.delete({ where: { id } });

    // Update department headcount
    if (employee.departmentId) {
      await this.prisma.department.update({
        where: { id: employee.departmentId },
        data: { headCount: { decrement: 1 } },
      });
    }

    return { message: 'Employee deleted successfully', data: null };
  }

  async updateStatus(id: string, status: string) {
    await this.findOne(id);
    const employee = await this.prisma.employee.update({
      where: { id },
      data: { status: status as any },
    });
    return { message: `Employee status updated to ${status}`, data: employee };
  }

  async getStats(companyId?: string) {
    const where = companyId ? { companyId } : {};

    const [total, active, onLeave, terminated, byDept, byType] = await Promise.all([
      this.prisma.employee.count({ where }),
      this.prisma.employee.count({ where: { ...where, status: 'ACTIVE' } }),
      this.prisma.employee.count({ where: { ...where, status: 'ON_LEAVE' } }),
      this.prisma.employee.count({ where: { ...where, status: 'TERMINATED' } }),
      this.prisma.employee.groupBy({
        by: ['departmentId'],
        where: { ...where, status: 'ACTIVE' },
        _count: { id: true },
      }),
      this.prisma.employee.groupBy({
        by: ['employmentType'],
        where,
        _count: { id: true },
      }),
    ]);

    return {
      message: 'Employee statistics',
      data: { total, active, onLeave, terminated, byDepartment: byDept, byEmploymentType: byType },
    };
  }

  async getSubordinates(managerId: string) {
    const subordinates = await this.prisma.employee.findMany({
      where: { managerId },
      include: { department: true },
    });
    return { message: 'Subordinates retrieved', data: subordinates };
  }
}
