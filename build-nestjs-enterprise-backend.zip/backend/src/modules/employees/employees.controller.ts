import { Controller, Get, Post, Put, Patch, Delete, Body, Param, Query, UseGuards, ParseUUIDPipe } from '@nestjs/common';
import { ApiTags, ApiBearerAuth, ApiOperation } from '@nestjs/swagger';
import { EmployeesService } from './employees.service';
import { CreateEmployeeDto } from './dto/create-employee.dto';
import { UpdateEmployeeDto } from './dto/update-employee.dto';
import { PaginationDto } from '../../common/dto/pagination.dto';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Roles } from '../../common/decorators/roles.decorator';

@ApiTags('employees')
@ApiBearerAuth('JWT-auth')
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'employees', version: '1' })
export class EmployeesController {
  constructor(private readonly employeesService: EmployeesService) {}

  @Get()
  @ApiOperation({ summary: 'Get all employees with filters, pagination, search, sorting' })
  findAll(
    @Query() query: PaginationDto & {
      status?: string;
      departmentId?: string;
      companyId?: string;
      employmentType?: string;
    },
  ) {
    return this.employeesService.findAll(query);
  }

  @Get('stats')
  @ApiOperation({ summary: 'Get employee statistics' })
  getStats(@Query('companyId') companyId?: string) {
    return this.employeesService.getStats(companyId);
  }

  @Get('by-employee-id/:employeeId')
  @ApiOperation({ summary: 'Get employee by employee ID (e.g. EMP-0001)' })
  findByEmployeeId(@Param('employeeId') employeeId: string) {
    return this.employeesService.findByEmployeeId(employeeId);
  }

  @Get(':id')
  @ApiOperation({ summary: 'Get employee by UUID' })
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.employeesService.findOne(id);
  }

  @Get(':id/subordinates')
  @ApiOperation({ summary: 'Get employee subordinates' })
  getSubordinates(@Param('id', ParseUUIDPipe) id: string) {
    return this.employeesService.getSubordinates(id);
  }

  @Post()
  @Roles('super-admin', 'hr-manager')
  @ApiOperation({ summary: 'Create new employee' })
  create(@Body() dto: CreateEmployeeDto) {
    return this.employeesService.create(dto);
  }

  @Put(':id')
  @Roles('super-admin', 'hr-manager')
  @ApiOperation({ summary: 'Update employee' })
  update(@Param('id', ParseUUIDPipe) id: string, @Body() dto: UpdateEmployeeDto) {
    return this.employeesService.update(id, dto);
  }

  @Patch(':id/status')
  @Roles('super-admin', 'hr-manager')
  @ApiOperation({ summary: 'Update employee status' })
  updateStatus(@Param('id', ParseUUIDPipe) id: string, @Body('status') status: string) {
    return this.employeesService.updateStatus(id, status);
  }

  @Delete(':id')
  @Roles('super-admin', 'hr-manager')
  @ApiOperation({ summary: 'Delete employee' })
  remove(@Param('id', ParseUUIDPipe) id: string) {
    return this.employeesService.remove(id);
  }
}
