import { PartialType, OmitType } from '@nestjs/swagger';
import { CreateEmployeeDto } from './create-employee.dto';

export class UpdateEmployeeDto extends PartialType(OmitType(CreateEmployeeDto, ['userId', 'companyId', 'employeeId'] as const)) {}
