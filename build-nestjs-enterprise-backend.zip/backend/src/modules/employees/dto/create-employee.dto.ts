import { IsString, IsEmail, IsOptional, IsUUID, IsEnum, IsDateString, IsNumber } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateEmployeeDto {
  @ApiProperty({ example: 'EMP-0099' }) @IsString() employeeId: string;
  @ApiProperty() @IsUUID() userId: string;
  @ApiProperty() @IsUUID() companyId: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() departmentId?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() shiftId?: string;
  @ApiProperty() @IsString() firstName: string;
  @ApiProperty() @IsString() lastName: string;
  @ApiProperty() @IsEmail() email: string;
  @ApiPropertyOptional() @IsOptional() @IsString() phone?: string;
  @ApiPropertyOptional() @IsOptional() @IsDateString() dateOfBirth?: string;
  @ApiPropertyOptional() @IsOptional() @IsEnum(['MALE', 'FEMALE', 'OTHER', 'PREFER_NOT_TO_SAY']) gender?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() nationality?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() address?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() city?: string;
  @ApiPropertyOptional() @IsOptional() @IsString() country?: string;
  @ApiProperty({ example: 'Software Engineer' }) @IsString() jobTitle: string;
  @ApiPropertyOptional() @IsOptional() @IsEnum(['FULL_TIME', 'PART_TIME', 'CONTRACT', 'INTERN', 'FREELANCE']) employmentType?: string;
  @ApiProperty() @IsDateString() hireDate: string;
  @ApiPropertyOptional() @IsOptional() @Type(() => Number) @IsNumber() salary?: number;
  @ApiPropertyOptional() @IsOptional() @IsString() currency?: string;
  @ApiPropertyOptional() @IsOptional() @IsUUID() managerId?: string;
}
