// =============================================================
// ENTERPRISE HR BACKEND — MAIN ENTRY POINT
// =============================================================

import { NestFactory, Reflector } from '@nestjs/core';
import { ValidationPipe, ClassSerializerInterceptor, VersioningType, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SwaggerModule, DocumentBuilder } from '@nestjs/swagger';
import * as compression from 'compression';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { GlobalExceptionFilter } from './common/filters/global-exception.filter';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';
import { TransformInterceptor } from './common/interceptors/transform.interceptor';
import { TimeoutInterceptor } from './common/interceptors/timeout.interceptor';

async function bootstrap() {
  const logger = new Logger('Bootstrap');

  const app = await NestFactory.create(AppModule, {
    logger: ['error', 'warn', 'log', 'debug', 'verbose'],
  });

  const configService = app.get(ConfigService);
  const port = configService.get<number>('PORT', 3001);
  const apiVersion = configService.get<string>('API_VERSION', 'v1');
  const apiPrefix = configService.get<string>('API_PREFIX', 'api');

  // ─── Security Middleware ────────────────────────────────────
  app.use(helmet({
    crossOriginEmbedderPolicy: false,
    contentSecurityPolicy: false,
  }));
  app.use(compression());

  // ─── CORS ──────────────────────────────────────────────────
  app.enableCors({
    origin: ['http://localhost:5173', 'http://localhost:3000', 'http://localhost:4173'],
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Request-ID', 'X-Company-ID'],
    credentials: true,
  });

  // ─── API Versioning ────────────────────────────────────────
  app.setGlobalPrefix(apiPrefix);
  app.enableVersioning({
    type: VersioningType.URI,
    defaultVersion: apiVersion,
  });

  // ─── Global Pipes ──────────────────────────────────────────
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
      stopAtFirstError: false,
    }),
  );

  // ─── Global Interceptors ───────────────────────────────────
  const reflector = app.get(Reflector);
  app.useGlobalInterceptors(
    new ClassSerializerInterceptor(reflector),
    new LoggingInterceptor(),
    new TransformInterceptor(),
    new TimeoutInterceptor(),
  );

  // ─── Global Filters ────────────────────────────────────────
  app.useGlobalFilters(new GlobalExceptionFilter());

  // ─── Swagger API Documentation ─────────────────────────────
  const swaggerConfig = new DocumentBuilder()
    .setTitle('Enterprise HR Management API')
    .setDescription('Production-grade REST API for Enterprise HR Management System')
    .setVersion('1.0.0')
    .addTag('auth', 'Authentication & Authorization')
    .addTag('users', 'User Management')
    .addTag('companies', 'Company Management')
    .addTag('employees', 'Employee Management')
    .addTag('departments', 'Department Management')
    .addTag('attendance', 'Attendance Tracking')
    .addTag('leaves', 'Leave Management')
    .addTag('shifts', 'Shift Management')
    .addTag('roles', 'Role & Permission Management')
    .addTag('notifications', 'Notification System')
    .addTag('activity-logs', 'Activity Logging')
    .addTag('audit-logs', 'Audit Trail')
    .addTag('dashboard', 'Dashboard Analytics')
    .addBearerAuth(
      { type: 'http', scheme: 'bearer', bearerFormat: 'JWT', name: 'JWT', in: 'header' },
      'JWT-auth',
    )
    .build();

  const document = SwaggerModule.createDocument(app, swaggerConfig);
  SwaggerModule.setup(`${apiPrefix}/docs`, app, document, {
    swaggerOptions: { persistAuthorization: true },
  });

  await app.listen(port);

  logger.log(`🚀 Enterprise HR Backend running on: http://localhost:${port}`);
  logger.log(`📚 API Documentation: http://localhost:${port}/${apiPrefix}/docs`);
  logger.log(`🌐 REST API Base: http://localhost:${port}/${apiPrefix}/${apiVersion}`);
  logger.log(`🗄️  Database: Neon PostgreSQL (Connected)`);
  logger.log(`⚡ Environment: ${configService.get('NODE_ENV', 'development')}`);
}

bootstrap();
