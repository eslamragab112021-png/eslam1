// =============================================================
// ENTERPRISE HR — DATABASE SEED
// =============================================================

import { PrismaClient, UserStatus, EmploymentType, EmployeeStatus, AttendanceStatus, LeaveType, LeaveStatus, NotificationType, AuditAction, PermissionAction, ShiftType, Gender } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Starting database seed...');

  // ─── Cleanup ────────────────────────────────────────────────
  await prisma.auditLog.deleteMany();
  await prisma.activityLog.deleteMany();
  await prisma.notification.deleteMany();
  await prisma.leaveRequest.deleteMany();
  await prisma.attendanceRecord.deleteMany();
  await prisma.rolePermission.deleteMany();
  await prisma.permission.deleteMany();
  await prisma.employee.deleteMany();
  await prisma.department.deleteMany();
  await prisma.shift.deleteMany();
  await prisma.user.deleteMany();
  await prisma.role.deleteMany();
  await prisma.company.deleteMany();

  console.log('✅ Cleaned existing data');

  // ─── Company ────────────────────────────────────────────────
  const company = await prisma.company.create({
    data: {
      name: 'TechCorp Enterprise',
      slug: 'techcorp-enterprise',
      email: 'hr@techcorp.io',
      phone: '+1-555-0100',
      website: 'https://techcorp.io',
      address: '1 Infinite Loop',
      city: 'San Francisco',
      state: 'CA',
      country: 'US',
      postalCode: '94105',
      industry: 'Technology',
      size: '201-500',
      timezone: 'America/New_York',
      currency: 'USD',
      isActive: true,
    },
  });

  console.log(`✅ Company created: ${company.name}`);

  // ─── Permissions ────────────────────────────────────────────
  const resources = ['users', 'employees', 'departments', 'attendance', 'leaves', 'roles', 'companies', 'reports', 'shifts', 'notifications'];
  const actions: PermissionAction[] = ['CREATE', 'READ', 'UPDATE', 'DELETE', 'MANAGE'];

  const permissions = [];
  for (const resource of resources) {
    for (const action of actions) {
      const p = await prisma.permission.create({
        data: { resource, action, description: `${action} ${resource}` },
      });
      permissions.push(p);
    }
  }

  console.log(`✅ Created ${permissions.length} permissions`);

  // ─── Roles ──────────────────────────────────────────────────
  const superAdminRole = await prisma.role.create({
    data: {
      name: 'Super Admin',
      slug: 'super-admin',
      description: 'Full system access',
      isSystem: true,
      companyId: company.id,
    },
  });

  const hrManagerRole = await prisma.role.create({
    data: {
      name: 'HR Manager',
      slug: 'hr-manager',
      description: 'Manage HR operations',
      isSystem: false,
      companyId: company.id,
    },
  });

  const employeeRole = await prisma.role.create({
    data: {
      name: 'Employee',
      slug: 'employee',
      description: 'Basic employee access',
      isSystem: false,
      companyId: company.id,
    },
  });

  const managerRole = await prisma.role.create({
    data: {
      name: 'Department Manager',
      slug: 'dept-manager',
      description: 'Manage department employees',
      isSystem: false,
      companyId: company.id,
    },
  });

  // Assign all permissions to superAdmin
  for (const perm of permissions) {
    await prisma.rolePermission.create({
      data: { roleId: superAdminRole.id, permissionId: perm.id },
    });
  }

  // HR Manager: manage users, employees, departments, attendance, leaves
  const hrPerms = permissions.filter(p =>
    ['users', 'employees', 'departments', 'attendance', 'leaves'].includes(p.resource)
  );
  for (const perm of hrPerms) {
    await prisma.rolePermission.create({
      data: { roleId: hrManagerRole.id, permissionId: perm.id },
    });
  }

  // Employee: read own data
  const empPerms = permissions.filter(p =>
    ['attendance', 'leaves', 'notifications'].includes(p.resource) &&
    ['READ', 'CREATE'].includes(p.action)
  );
  for (const perm of empPerms) {
    await prisma.rolePermission.create({
      data: { roleId: employeeRole.id, permissionId: perm.id },
    });
  }

  console.log('✅ Roles and permissions created');

  // ─── Shifts ──────────────────────────────────────────────────
  const morningShift = await prisma.shift.create({
    data: {
      name: 'Morning Shift',
      type: ShiftType.MORNING,
      startTime: '08:00',
      endTime: '16:00',
      breakDuration: 60,
      workingDays: [1, 2, 3, 4, 5],
      companyId: company.id,
    },
  });

  const afternoonShift = await prisma.shift.create({
    data: {
      name: 'Afternoon Shift',
      type: ShiftType.AFTERNOON,
      startTime: '12:00',
      endTime: '20:00',
      breakDuration: 60,
      workingDays: [1, 2, 3, 4, 5],
      companyId: company.id,
    },
  });

  const nightShift = await prisma.shift.create({
    data: {
      name: 'Night Shift',
      type: ShiftType.NIGHT,
      startTime: '20:00',
      endTime: '04:00',
      breakDuration: 30,
      workingDays: [1, 2, 3, 4, 5],
      companyId: company.id,
    },
  });

  const flexShift = await prisma.shift.create({
    data: {
      name: 'Flexible Hours',
      type: ShiftType.FLEXIBLE,
      startTime: '09:00',
      endTime: '18:00',
      breakDuration: 60,
      workingDays: [1, 2, 3, 4, 5],
      companyId: company.id,
    },
  });

  console.log('✅ Shifts created');

  // ─── Departments ─────────────────────────────────────────────
  const engineeringDept = await prisma.department.create({
    data: {
      name: 'Engineering',
      code: 'ENG',
      description: 'Software Engineering & Architecture',
      budget: 2500000,
      companyId: company.id,
    },
  });

  const hrDept = await prisma.department.create({
    data: {
      name: 'Human Resources',
      code: 'HR',
      description: 'People Operations & Talent',
      budget: 800000,
      companyId: company.id,
    },
  });

  const financeDept = await prisma.department.create({
    data: {
      name: 'Finance',
      code: 'FIN',
      description: 'Financial Operations & Accounting',
      budget: 1200000,
      companyId: company.id,
    },
  });

  const marketingDept = await prisma.department.create({
    data: {
      name: 'Marketing',
      code: 'MKT',
      description: 'Growth & Brand Marketing',
      budget: 950000,
      companyId: company.id,
    },
  });

  const productDept = await prisma.department.create({
    data: {
      name: 'Product',
      code: 'PRD',
      description: 'Product Management & Design',
      budget: 1100000,
      companyId: company.id,
    },
  });

  const salesDept = await prisma.department.create({
    data: {
      name: 'Sales',
      code: 'SLS',
      description: 'Revenue & Business Development',
      budget: 1500000,
      companyId: company.id,
    },
  });

  console.log('✅ Departments created');

  // ─── Users & Employees ───────────────────────────────────────
  const hashedPassword = await bcrypt.hash('Admin@123456', 12);

  const usersData = [
    {
      email: 'admin@techcorp.io',
      firstName: 'Alex',
      lastName: 'Morrison',
      roleId: superAdminRole.id,
      jobTitle: 'CTO & System Administrator',
      departmentId: engineeringDept.id,
      shiftId: flexShift.id,
      salary: 180000,
      employeeId: 'EMP-0001',
      hireDate: new Date('2020-01-15'),
      gender: Gender.MALE,
    },
    {
      email: 'sarah.hr@techcorp.io',
      firstName: 'Sarah',
      lastName: 'Williams',
      roleId: hrManagerRole.id,
      jobTitle: 'HR Director',
      departmentId: hrDept.id,
      shiftId: morningShift.id,
      salary: 120000,
      employeeId: 'EMP-0002',
      hireDate: new Date('2020-03-01'),
      gender: Gender.FEMALE,
    },
    {
      email: 'james.eng@techcorp.io',
      firstName: 'James',
      lastName: 'Chen',
      roleId: managerRole.id,
      jobTitle: 'Engineering Manager',
      departmentId: engineeringDept.id,
      shiftId: flexShift.id,
      salary: 155000,
      employeeId: 'EMP-0003',
      hireDate: new Date('2020-06-15'),
      gender: Gender.MALE,
    },
    {
      email: 'emily.fin@techcorp.io',
      firstName: 'Emily',
      lastName: 'Johnson',
      roleId: managerRole.id,
      jobTitle: 'Finance Manager',
      departmentId: financeDept.id,
      shiftId: morningShift.id,
      salary: 130000,
      employeeId: 'EMP-0004',
      hireDate: new Date('2021-01-10'),
      gender: Gender.FEMALE,
    },
    {
      email: 'david.dev@techcorp.io',
      firstName: 'David',
      lastName: 'Kim',
      roleId: employeeRole.id,
      jobTitle: 'Senior Software Engineer',
      departmentId: engineeringDept.id,
      shiftId: flexShift.id,
      salary: 130000,
      employeeId: 'EMP-0005',
      hireDate: new Date('2021-04-01'),
      gender: Gender.MALE,
    },
    {
      email: 'maria.mkt@techcorp.io',
      firstName: 'Maria',
      lastName: 'Garcia',
      roleId: employeeRole.id,
      jobTitle: 'Marketing Specialist',
      departmentId: marketingDept.id,
      shiftId: morningShift.id,
      salary: 85000,
      employeeId: 'EMP-0006',
      hireDate: new Date('2021-07-15'),
      gender: Gender.FEMALE,
    },
    {
      email: 'robert.prd@techcorp.io',
      firstName: 'Robert',
      lastName: 'Taylor',
      roleId: employeeRole.id,
      jobTitle: 'Product Manager',
      departmentId: productDept.id,
      shiftId: flexShift.id,
      salary: 115000,
      employeeId: 'EMP-0007',
      hireDate: new Date('2021-09-01'),
      gender: Gender.MALE,
    },
    {
      email: 'jennifer.sls@techcorp.io',
      firstName: 'Jennifer',
      lastName: 'Brown',
      roleId: employeeRole.id,
      jobTitle: 'Sales Executive',
      departmentId: salesDept.id,
      shiftId: morningShift.id,
      salary: 90000,
      employeeId: 'EMP-0008',
      hireDate: new Date('2022-01-15'),
      gender: Gender.FEMALE,
    },
    {
      email: 'michael.dev@techcorp.io',
      firstName: 'Michael',
      lastName: 'Davis',
      roleId: employeeRole.id,
      jobTitle: 'Full Stack Developer',
      departmentId: engineeringDept.id,
      shiftId: afternoonShift.id,
      salary: 105000,
      employeeId: 'EMP-0009',
      hireDate: new Date('2022-03-01'),
      gender: Gender.MALE,
    },
    {
      email: 'lisa.hr@techcorp.io',
      firstName: 'Lisa',
      lastName: 'Anderson',
      roleId: employeeRole.id,
      jobTitle: 'HR Business Partner',
      departmentId: hrDept.id,
      shiftId: morningShift.id,
      salary: 80000,
      employeeId: 'EMP-0010',
      hireDate: new Date('2022-05-15'),
      gender: Gender.FEMALE,
    },
    {
      email: 'thomas.fin@techcorp.io',
      firstName: 'Thomas',
      lastName: 'Wilson',
      roleId: employeeRole.id,
      jobTitle: 'Financial Analyst',
      departmentId: financeDept.id,
      shiftId: morningShift.id,
      salary: 88000,
      employeeId: 'EMP-0011',
      hireDate: new Date('2022-08-01'),
      gender: Gender.MALE,
    },
    {
      email: 'ashley.dev@techcorp.io',
      firstName: 'Ashley',
      lastName: 'Martinez',
      roleId: employeeRole.id,
      jobTitle: 'DevOps Engineer',
      departmentId: engineeringDept.id,
      shiftId: nightShift.id,
      salary: 125000,
      employeeId: 'EMP-0012',
      hireDate: new Date('2022-10-15'),
      gender: Gender.FEMALE,
    },
  ];

  const createdUsers: any[] = [];
  const createdEmployees: any[] = [];

  for (const ud of usersData) {
    const user = await prisma.user.create({
      data: {
        email: ud.email,
        password: hashedPassword,
        firstName: ud.firstName,
        lastName: ud.lastName,
        status: UserStatus.ACTIVE,
        emailVerified: true,
        roleId: ud.roleId,
        companyId: company.id,
      },
    });

    const employee = await prisma.employee.create({
      data: {
        employeeId: ud.employeeId,
        userId: user.id,
        companyId: company.id,
        departmentId: ud.departmentId,
        shiftId: ud.shiftId,
        firstName: ud.firstName,
        lastName: ud.lastName,
        email: ud.email,
        jobTitle: ud.jobTitle,
        employmentType: EmploymentType.FULL_TIME,
        status: EmployeeStatus.ACTIVE,
        hireDate: ud.hireDate,
        salary: ud.salary,
        currency: 'USD',
        gender: ud.gender,
        country: 'US',
        emergencyContact: {
          name: 'Emergency Contact',
          phone: '+1-555-0199',
          relation: 'Spouse',
        },
      },
    });

    createdUsers.push(user);
    createdEmployees.push(employee);
  }

  // Set department managers
  await prisma.department.update({ where: { id: engineeringDept.id }, data: { managerId: createdEmployees[2].id } });
  await prisma.department.update({ where: { id: hrDept.id }, data: { managerId: createdEmployees[1].id } });
  await prisma.department.update({ where: { id: financeDept.id }, data: { managerId: createdEmployees[3].id } });

  // Set manager relationships
  for (let i = 4; i < createdEmployees.length; i++) {
    const deptId = createdEmployees[i].departmentId;
    let managerId = createdEmployees[0].id; // default to admin
    if (deptId === engineeringDept.id) managerId = createdEmployees[2].id;
    if (deptId === hrDept.id) managerId = createdEmployees[1].id;
    if (deptId === financeDept.id) managerId = createdEmployees[3].id;

    await prisma.employee.update({
      where: { id: createdEmployees[i].id },
      data: { managerId },
    });
  }

  console.log(`✅ Created ${createdUsers.length} users and employees`);

  // ─── Attendance Records (last 30 days) ──────────────────────
  const statuses: AttendanceStatus[] = ['PRESENT', 'PRESENT', 'PRESENT', 'PRESENT', 'LATE', 'ABSENT'];
  let attendanceCount = 0;

  for (const employee of createdEmployees) {
    for (let d = 30; d >= 1; d--) {
      const date = new Date();
      date.setDate(date.getDate() - d);
      date.setHours(0, 0, 0, 0);
      const dayOfWeek = date.getDay();
      if (dayOfWeek === 0 || dayOfWeek === 6) continue;

      const status = statuses[Math.floor(Math.random() * statuses.length)];
      const checkInHour = status === 'LATE' ? 9 + Math.floor(Math.random() * 2) : 8;
      const checkInMinute = Math.floor(Math.random() * 30);

      const checkIn = new Date(date);
      checkIn.setHours(checkInHour, checkInMinute, 0);
      const checkOut = new Date(checkIn);
      checkOut.setHours(checkInHour + 8, Math.floor(Math.random() * 60), 0);
      const workHours = parseFloat(((checkOut.getTime() - checkIn.getTime()) / 3600000 - 1).toFixed(2));

      try {
        await prisma.attendanceRecord.create({
          data: {
            employeeId: employee.id,
            date,
            checkIn: status !== 'ABSENT' ? checkIn : null,
            checkOut: status !== 'ABSENT' ? checkOut : null,
            status,
            workHours: status !== 'ABSENT' ? workHours : null,
            overtimeHours: workHours > 8 ? parseFloat((workHours - 8).toFixed(2)) : 0,
          },
        });
        attendanceCount++;
      } catch (e) {
        // skip duplicates
      }
    }
  }

  console.log(`✅ Created ${attendanceCount} attendance records`);

  // ─── Leave Requests ──────────────────────────────────────────
  const leaveTypes: LeaveType[] = ['ANNUAL', 'SICK', 'EMERGENCY', 'ANNUAL'];
  const leaveStatuses: LeaveStatus[] = ['APPROVED', 'PENDING', 'REJECTED'];

  for (let i = 0; i < 20; i++) {
    const employee = createdEmployees[Math.floor(Math.random() * createdEmployees.length)];
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - Math.floor(Math.random() * 60));
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + Math.floor(Math.random() * 5) + 1);

    await prisma.leaveRequest.create({
      data: {
        employeeId: employee.id,
        companyId: company.id,
        type: leaveTypes[Math.floor(Math.random() * leaveTypes.length)],
        status: leaveStatuses[Math.floor(Math.random() * leaveStatuses.length)],
        startDate,
        endDate,
        totalDays: Math.ceil((endDate.getTime() - startDate.getTime()) / 86400000),
        reason: 'Personal leave request',
      },
    });
  }

  console.log('✅ Created 20 leave requests');

  // ─── Notifications ───────────────────────────────────────────
  const notifMessages = [
    { title: 'New Employee Onboarded', message: 'Michael Davis has joined the Engineering team', type: NotificationType.INFO },
    { title: 'Leave Request Approved', message: 'Your annual leave for Dec 25-27 has been approved', type: NotificationType.SUCCESS },
    { title: 'Attendance Alert', message: 'You have 3 late check-ins this month', type: NotificationType.WARNING },
    { title: 'Payroll Processed', message: 'December payroll has been successfully processed', type: NotificationType.SUCCESS },
    { title: 'System Maintenance', message: 'Scheduled maintenance on Sunday 2:00 AM - 4:00 AM', type: NotificationType.SYSTEM },
    { title: 'Leave Request Pending', message: 'Jennifer Brown has submitted a leave request', type: NotificationType.INFO },
    { title: 'Performance Review Due', message: 'Q4 performance reviews are due by Dec 31', type: NotificationType.WARNING },
  ];

  for (const user of createdUsers.slice(0, 5)) {
    for (const msg of notifMessages.slice(0, 4)) {
      await prisma.notification.create({
        data: {
          userId: user.id,
          title: msg.title,
          message: msg.message,
          type: msg.type,
          isRead: Math.random() > 0.5,
        },
      });
    }
  }

  console.log('✅ Created notifications');

  // ─── Activity Logs ───────────────────────────────────────────
  const activities = [
    { action: 'LOGIN', module: 'auth', description: 'User logged in successfully' },
    { action: 'VIEW_DASHBOARD', module: 'dashboard', description: 'Viewed main dashboard' },
    { action: 'UPDATE_EMPLOYEE', module: 'employees', description: 'Updated employee profile' },
    { action: 'APPROVE_LEAVE', module: 'leaves', description: 'Approved leave request' },
    { action: 'EXPORT_REPORT', module: 'reports', description: 'Exported attendance report' },
  ];

  for (const user of createdUsers.slice(0, 5)) {
    for (const act of activities) {
      await prisma.activityLog.create({
        data: {
          userId: user.id,
          action: act.action,
          module: act.module,
          description: act.description,
          ipAddress: '192.168.1.' + Math.floor(Math.random() * 255),
          metadata: { timestamp: new Date().toISOString() },
        },
      });
    }
  }

  console.log('✅ Created activity logs');

  // ─── Audit Logs ──────────────────────────────────────────────
  const auditEntries = [
    { action: AuditAction.CREATE, resource: 'employee', resourceId: createdEmployees[0].id },
    { action: AuditAction.UPDATE, resource: 'department', resourceId: engineeringDept.id },
    { action: AuditAction.LOGIN, resource: 'auth', resourceId: createdUsers[0].id },
    { action: AuditAction.EXPORT, resource: 'reports', resourceId: null },
    { action: AuditAction.DELETE, resource: 'notification', resourceId: null },
  ];

  for (const user of createdUsers.slice(0, 3)) {
    for (const entry of auditEntries) {
      await prisma.auditLog.create({
        data: {
          userId: user.id,
          action: entry.action,
          resource: entry.resource,
          resourceId: entry.resourceId,
          status: 'success',
          ipAddress: '10.0.0.' + Math.floor(Math.random() * 255),
        },
      });
    }
  }

  console.log('✅ Created audit logs');
  console.log('');
  console.log('🎉 Database seeded successfully!');
  console.log('');
  console.log('📋 Seed Summary:');
  console.log(`   Company:     1`);
  console.log(`   Roles:       4`);
  console.log(`   Permissions: ${permissions.length}`);
  console.log(`   Shifts:      4`);
  console.log(`   Departments: 6`);
  console.log(`   Users:       ${createdUsers.length}`);
  console.log(`   Employees:   ${createdEmployees.length}`);
  console.log(`   Attendance:  ~${attendanceCount}`);
  console.log(`   Leaves:      20`);
  console.log('');
  console.log('🔑 Default Login Credentials:');
  console.log('   Admin:    admin@techcorp.io  / Admin@123456');
  console.log('   HR:       sarah.hr@techcorp.io / Admin@123456');
  console.log('   Employee: david.dev@techcorp.io / Admin@123456');
}

main()
  .catch((e) => {
    console.error('❌ Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
