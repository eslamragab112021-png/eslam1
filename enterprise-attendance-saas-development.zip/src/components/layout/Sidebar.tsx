import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  LayoutDashboard, Users, Clock, Calendar, DollarSign, Building2,
  Settings, LogOut, ChevronLeft, ChevronRight, Bell, FileText,
  BarChart3, Shield, Briefcase, Menu, X
} from 'lucide-react';
import { cn } from '../../utils/cn';
import { useAuthStore } from '../../store/auth.store';
import { useAppStore } from '../../store/app.store';
import { hasPermission } from '../../types';

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: number;
  resource?: string;
  children?: NavItem[];
}

const NAV_ITEMS: NavItem[] = [
  { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard size={18} />, resource: 'attendance' },
  { id: 'attendance', label: 'Attendance', icon: <Clock size={18} />, resource: 'attendance' },
  { id: 'employees', label: 'Employees', icon: <Users size={18} />, resource: 'employees' },
  { id: 'leave', label: 'Leave Management', icon: <Calendar size={18} />, resource: 'leave' },
  { id: 'payroll', label: 'Payroll', icon: <DollarSign size={18} />, resource: 'payroll' },
  { id: 'departments', label: 'Departments', icon: <Building2 size={18} />, resource: 'departments' },
  { id: 'shifts', label: 'Shifts', icon: <Briefcase size={18} />, resource: 'shifts' },
  { id: 'reports', label: 'Reports', icon: <BarChart3 size={18} />, resource: 'reports' },
  { id: 'notifications', label: 'Notifications', icon: <Bell size={18} />, resource: 'attendance' },
  { id: 'audit', label: 'Audit Logs', icon: <Shield size={18} />, resource: 'audit_logs' },
  { id: 'settings', label: 'Settings', icon: <Settings size={18} />, resource: 'settings' },
];

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  unreadNotifications?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentPage, onNavigate, unreadNotifications = 0 }) => {
  const { user, logout } = useAuthStore();
  const { sidebarState, toggleSidebar, setSidebarState } = useAppStore();
  const collapsed = sidebarState === 'collapsed';
  const mobileOpen = sidebarState === 'mobile-open';

  const filteredNav = NAV_ITEMS.filter(item => {
    if (!item.resource || !user?.role) return true;
    return hasPermission(user.role, item.resource, 'read');
  });

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className={cn('flex items-center gap-3 px-4 py-5 border-b border-slate-800/50', collapsed && 'justify-center px-3')}>
        <div className="flex-shrink-0 w-9 h-9 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl flex items-center justify-center shadow-lg">
          <Clock size={18} className="text-white" />
        </div>
        {!collapsed && (
          <div>
            <h1 className="text-white font-bold text-lg leading-none">AttendX</h1>
            <p className="text-slate-400 text-xs mt-0.5">Enterprise</p>
          </div>
        )}
      </div>

      {/* Company Info */}
      {!collapsed && user?.company && (
        <div className="px-4 py-3 border-b border-slate-800/50">
          <div className="bg-slate-800/40 rounded-xl px-3 py-2.5">
            <p className="text-white text-sm font-medium truncate">{user.company.name}</p>
            <div className="flex items-center gap-1.5 mt-1">
              <div className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs text-slate-400 capitalize">{user.company.subscriptionPlan} Plan</span>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {filteredNav.map(item => (
          <button
            key={item.id}
            onClick={() => { onNavigate(item.id); setSidebarState('expanded'); }}
            className={cn(
              'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-150 group relative',
              currentPage === item.id
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-900/50'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/60',
              collapsed && 'justify-center px-0'
            )}
            title={collapsed ? item.label : undefined}
          >
            <span className="flex-shrink-0">{item.icon}</span>
            {!collapsed && (
              <span className="flex-1 text-left">{item.label}</span>
            )}
            {!collapsed && item.id === 'notifications' && unreadNotifications > 0 && (
              <span className="bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center font-medium">
                {unreadNotifications > 9 ? '9+' : unreadNotifications}
              </span>
            )}
            {collapsed && item.id === 'notifications' && unreadNotifications > 0 && (
              <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-red-500 rounded-full" />
            )}
          </button>
        ))}
      </nav>

      {/* User & Logout */}
      <div className="p-3 border-t border-slate-800/50">
        {!collapsed && (
          <div className="flex items-center gap-3 px-3 py-2.5 mb-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center flex-shrink-0">
              <span className="text-white text-xs font-bold">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-white text-sm font-medium truncate">{user?.firstName} {user?.lastName}</p>
              <p className="text-slate-400 text-xs capitalize truncate">{user?.role?.replace(/_/g, ' ')}</p>
            </div>
          </div>
        )}
        <button
          onClick={() => logout()}
          className={cn(
            'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/10 transition-all text-sm',
            collapsed && 'justify-center'
          )}
          title={collapsed ? 'Logout' : undefined}
        >
          <LogOut size={18} />
          {!collapsed && <span>Sign Out</span>}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 72 : 256 }}
        transition={{ duration: 0.2, ease: 'easeInOut' }}
        className="hidden lg:flex flex-col fixed left-0 top-0 bottom-0 bg-slate-900 z-30 overflow-hidden"
      >
        <SidebarContent />
        {/* Collapse Toggle */}
        <button
          onClick={toggleSidebar}
          className="absolute right-0 top-20 translate-x-1/2 bg-slate-900 border border-slate-700 rounded-full p-1.5 text-slate-400 hover:text-white transition-colors shadow-lg"
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </motion.aside>

      {/* Mobile Sidebar */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/60 z-40 lg:hidden"
              onClick={() => setSidebarState('expanded')}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed left-0 top-0 bottom-0 w-64 bg-slate-900 z-50 lg:hidden"
            >
              <button
                onClick={() => setSidebarState('expanded')}
                className="absolute top-4 right-4 text-slate-400 hover:text-white"
              >
                <X size={20} />
              </button>
              <SidebarContent />
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
};

export const MobileMenuButton: React.FC = () => {
  const { setSidebarState } = useAppStore();
  return (
    <button
      onClick={() => setSidebarState('mobile-open')}
      className="lg:hidden p-2 rounded-lg hover:bg-slate-100 text-slate-600"
    >
      <Menu size={20} />
    </button>
  );
};
