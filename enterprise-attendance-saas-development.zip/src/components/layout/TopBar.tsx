import React, { useState } from 'react';
import { Bell, Search, ChevronDown, RefreshCw } from 'lucide-react';
import { useAuthStore } from '../../store/auth.store';
import { useAppStore } from '../../store/app.store';
import { MobileMenuButton } from './Sidebar';
import { cn } from '../../utils/cn';

const PAGE_TITLES: Record<string, string> = {
  dashboard: 'Dashboard',
  attendance: 'Attendance Tracking',
  employees: 'Employee Management',
  leave: 'Leave Management',
  payroll: 'Payroll',
  departments: 'Departments',
  shifts: 'Shift Management',
  reports: 'Reports & Analytics',
  notifications: 'Notifications',
  audit: 'Audit Logs',
  settings: 'Settings',
  profile: 'My Profile',
};

interface TopBarProps {
  onNavigate: (page: string) => void;
  unreadNotifications?: number;
}

export const TopBar: React.FC<TopBarProps> = ({ onNavigate, unreadNotifications = 0 }) => {
  const { user } = useAuthStore();
  const { currentPage, dbStatus } = useAppStore();
  const [showUserMenu, setShowUserMenu] = useState(false);

  return (
    <header className="sticky top-0 z-20 bg-white/90 backdrop-blur-md border-b border-slate-100 px-4 py-3.5">
      <div className="flex items-center gap-4">
        <MobileMenuButton />

        {/* Page Title */}
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-semibold text-slate-900">
              {PAGE_TITLES[currentPage] || 'AttendX'}
            </h2>
            <div className={cn(
              'hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium',
              dbStatus === 'connected' && 'bg-emerald-50 text-emerald-700',
              dbStatus === 'connecting' && 'bg-amber-50 text-amber-700',
              dbStatus === 'initializing' && 'bg-blue-50 text-blue-700',
              dbStatus === 'error' && 'bg-red-50 text-red-700',
            )}>
              <div className={cn(
                'h-1.5 w-1.5 rounded-full',
                dbStatus === 'connected' && 'bg-emerald-500 animate-pulse',
                dbStatus === 'connecting' && 'bg-amber-500 animate-pulse',
                dbStatus === 'initializing' && 'bg-blue-500 animate-pulse',
                dbStatus === 'error' && 'bg-red-500',
              )} />
              {dbStatus === 'connected' && 'Live DB'}
              {dbStatus === 'connecting' && 'Connecting...'}
              {dbStatus === 'initializing' && 'Initializing...'}
              {dbStatus === 'error' && 'DB Error'}
            </div>
          </div>
          <p className="text-xs text-slate-400 hidden sm:block">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </p>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <button className="hidden md:flex items-center gap-2 px-3 py-2 text-sm text-slate-400 bg-slate-50 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200">
            <Search size={14} />
            <span>Search...</span>
            <kbd className="text-xs bg-white border border-slate-200 rounded px-1.5 py-0.5">⌘K</kbd>
          </button>

          {/* Notifications */}
          <button
            onClick={() => onNavigate('notifications')}
            className="relative p-2.5 hover:bg-slate-100 rounded-xl transition-colors text-slate-500"
          >
            <Bell size={18} />
            {unreadNotifications > 0 && (
              <span className="absolute top-1.5 right-1.5 h-2 w-2 bg-red-500 rounded-full ring-2 ring-white" />
            )}
          </button>

          {/* Refresh/Sync indicator */}
          {(dbStatus === 'connecting' || dbStatus === 'initializing') && (
            <div className="p-2.5">
              <RefreshCw size={18} className="text-indigo-500 animate-spin" />
            </div>
          )}

          {/* User Menu */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2.5 pl-2 pr-3 py-2 hover:bg-slate-100 rounded-xl transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-400 to-violet-500 flex items-center justify-center">
                <span className="text-white text-xs font-bold">
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </span>
              </div>
              <div className="hidden sm:block text-left">
                <p className="text-sm font-medium text-slate-700 leading-none">{user?.firstName}</p>
                <p className="text-xs text-slate-400 mt-0.5 capitalize">{user?.role?.replace(/_/g, ' ')}</p>
              </div>
              <ChevronDown size={14} className="text-slate-400 hidden sm:block" />
            </button>

            {showUserMenu && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowUserMenu(false)} />
                <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-lg border border-slate-100 py-1 z-20">
                  <div className="px-4 py-3 border-b border-slate-100">
                    <p className="text-sm font-medium text-slate-800">{user?.firstName} {user?.lastName}</p>
                    <p className="text-xs text-slate-500 truncate">{user?.email}</p>
                  </div>
                  <button
                    onClick={() => { onNavigate('profile'); setShowUserMenu(false); }}
                    className="w-full text-left px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 transition-colors"
                  >
                    My Profile
                  </button>
                  <button
                    onClick={() => { onNavigate('settings'); setShowUserMenu(false); }}
                    className="w-full text-left px-4 py-2.5 text-sm text-slate-600 hover:bg-slate-50 transition-colors"
                  >
                    Settings
                  </button>
                  <div className="border-t border-slate-100 mt-1">
                    <button
                      onClick={() => { useAuthStore.getState().logout(); setShowUserMenu(false); }}
                      className="w-full text-left px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 transition-colors"
                    >
                      Sign Out
                    </button>
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
