// ============================================================
// AttendX — Enterprise Attendance Management SaaS
// Main Application Entry Point
// ============================================================

import React, { useEffect, useState, Suspense } from 'react';
import { Toaster } from 'react-hot-toast';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore } from './store/auth.store';
import { useAppStore } from './store/app.store';
import { initializeSchema, seedDemoData } from './lib/schema';
import { query } from './lib/database';
import { hashPassword } from './lib/crypto';
import { generateUUID } from './lib/crypto';
import { LoginPage } from './pages/LoginPage';
import { Sidebar } from './components/layout/Sidebar';
import { TopBar } from './components/layout/TopBar';
import { DashboardPage } from './pages/DashboardPage';
import { EmployeesPage } from './pages/EmployeesPage';
import { AttendancePage } from './pages/AttendancePage';
import { LeavePage } from './pages/LeavePage';
import { PayrollPage } from './pages/PayrollPage';
import { DepartmentsPage } from './pages/DepartmentsPage';
import { NotificationsPage } from './pages/NotificationsPage';
import { AuditPage } from './pages/AuditPage';
import { ReportsPage } from './pages/ReportsPage';
import { SettingsPage } from './pages/SettingsPage';
import { notificationService } from './services/department.service';

// ============================================================
// DATABASE BOOTSTRAP
// ============================================================
async function bootstrapDatabase(): Promise<void> {
  try {
    // Initialize full schema
    await initializeSchema();

    // Check if demo company exists
    const companyCheck = await query<{ id: string }>(
      `SELECT id FROM companies WHERE slug = 'acme-corp-demo' LIMIT 1`
    );

    let companyId: string;
    let adminUserId: string;

    if (companyCheck.rowCount === 0) {
      console.log('🏢 Creating demo company...');

      companyId = generateUUID();
      adminUserId = generateUUID();
      const hrUserId = generateUUID();
      const empUserId = generateUUID();

      // Create demo company
      await query(
        `INSERT INTO companies (id, name, slug, email, subscription_plan, subscription_status, timezone, working_hours_per_day, working_days_per_week, geofencing_enabled, geofence_radius, industry)
         VALUES ($1, 'Acme Corporation', 'acme-corp-demo', 'admin@acmecorp.com', 'professional', 'active', 'America/New_York', 8, 5, true, 200, 'technology')
         ON CONFLICT (slug) DO NOTHING`,
        [companyId]
      );

      // Re-fetch if already existed
      const reCheck = await query<{ id: string }>(
        `SELECT id FROM companies WHERE slug = 'acme-corp-demo' LIMIT 1`
      );
      if (reCheck.rowCount > 0) {
        companyId = reCheck.rows[0].id;
      }

      // Create subscription
      await query(
        `INSERT INTO subscriptions (company_id, plan, status, max_employees, monthly_amount) 
         VALUES ($1, 'professional', 'active', 200, 149)
         ON CONFLICT DO NOTHING`,
        [companyId]
      );

      // Hash passwords
      const adminHash = await hashPassword('Admin@1234');

      // Create demo users
      await query(
        `INSERT INTO users (id, company_id, email, password_hash, first_name, last_name, role, email_verified) VALUES
         ($1, $2, 'admin@acmecorp.com', $3, 'Alex', 'Morgan', 'company_admin', true)
         ON CONFLICT (email) DO NOTHING`,
        [adminUserId, companyId, adminHash]
      );
      await query(
        `INSERT INTO users (id, company_id, email, password_hash, first_name, last_name, role, email_verified) VALUES
         ($1, $2, 'hr@acmecorp.com', $3, 'Jamie', 'Wilson', 'hr_manager', true)
         ON CONFLICT (email) DO NOTHING`,
        [hrUserId, companyId, adminHash]
      );
      await query(
        `INSERT INTO users (id, company_id, email, password_hash, first_name, last_name, role, email_verified) VALUES
         ($1, $2, 'employee@acmecorp.com', $3, 'Sam', 'Taylor', 'employee', true)
         ON CONFLICT (email) DO NOTHING`,
        [empUserId, companyId, adminHash]
      );

      // Re-fetch admin ID in case it already existed
      const adminCheck = await query<{ id: string }>(
        `SELECT id FROM users WHERE email = 'admin@acmecorp.com' LIMIT 1`
      );
      if (adminCheck.rowCount > 0) {
        adminUserId = adminCheck.rows[0].id;
      }

      // Seed demo data (departments, employees, attendance, etc.)
      await seedDemoData(companyId, adminUserId);

      // Link employee user to employee record
      await query(
        `UPDATE employees SET user_id = $1 WHERE company_id = $2 AND employee_code = 'EMP-001' AND user_id IS NULL`,
        [adminUserId, companyId]
      ).catch(() => {});

      console.log('✅ Demo company initialized');
    } else {
      companyId = companyCheck.rows[0].id;
      console.log('✅ Existing demo company found');
    }

    console.log('🚀 AttendX database ready');
  } catch (err) {
    console.error('❌ Database bootstrap error:', err);
    throw err;
  }
}

// ============================================================
// PAGES MAPPING
// ============================================================
const PAGES: Record<string, React.ComponentType> = {
  dashboard: DashboardPage,
  attendance: AttendancePage,
  employees: EmployeesPage,
  leave: LeavePage,
  payroll: PayrollPage,
  departments: DepartmentsPage,
  shifts: DepartmentsPage,
  reports: ReportsPage,
  notifications: NotificationsPage,
  audit: AuditPage,
  settings: SettingsPage,
  profile: SettingsPage,
};

// ============================================================
// DB STATUS SCREEN
// ============================================================
const DbInitScreen: React.FC<{ status: 'connecting' | 'initializing' | 'error'; error?: string }> = ({ status, error }) => (
  <div className="min-h-screen bg-slate-900 flex items-center justify-center">
    <div className="text-center max-w-md px-6">
      <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-3xl flex items-center justify-center shadow-2xl">
        {status === 'error' ? (
          <span className="text-white text-3xl">⚠️</span>
        ) : (
          <svg className="animate-spin h-10 w-10 text-white" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        )}
      </div>

      <h1 className="text-2xl font-bold text-white mb-2">AttendX</h1>
      <p className="text-indigo-400 font-medium mb-4">Enterprise Attendance Management</p>

      {status === 'connecting' && (
        <>
          <p className="text-slate-400 text-sm">Connecting to Neon PostgreSQL...</p>
          <div className="mt-4 flex items-center justify-center gap-1">
            {Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: `${i * 0.2}s` }} />
            ))}
          </div>
        </>
      )}

      {status === 'initializing' && (
        <>
          <p className="text-slate-400 text-sm mb-1">Initializing database schema...</p>
          <p className="text-xs text-slate-600">Creating tables, indexes, and seeding demo data</p>
          <div className="mt-4 bg-slate-800 rounded-xl p-4 text-left font-mono text-xs text-slate-400 space-y-1">
            <p className="text-emerald-400">✓ Connected to Neon PostgreSQL</p>
            <p className="text-emerald-400">✓ Running schema migrations...</p>
            <p className="text-amber-400 animate-pulse">⟳ Seeding demo data...</p>
          </div>
        </>
      )}

      {status === 'error' && (
        <>
          <p className="text-red-400 text-sm mb-2">Database connection failed</p>
          <p className="text-slate-500 text-xs mb-4">{error}</p>
          <div className="bg-slate-800 rounded-xl p-4 text-left text-xs text-slate-400 space-y-2">
            <p>The application uses Neon PostgreSQL directly.</p>
            <p>If the Neon endpoint is unreachable, the demo credentials may be expired.</p>
            <p className="text-indigo-400">Try refreshing the page to reconnect.</p>
          </div>
          <button
            onClick={() => window.location.reload()}
            className="mt-4 px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-sm font-medium transition-colors"
          >
            Retry Connection
          </button>
        </>
      )}
    </div>
  </div>
);

// ============================================================
// MAIN APP LAYOUT
// ============================================================
const AppLayout: React.FC = () => {
  const { user } = useAuthStore();
  const { currentPage, setCurrentPage, sidebarState } = useAppStore();
  const [unreadCount, setUnreadCount] = useState(0);
  const collapsed = sidebarState === 'collapsed';

  const CurrentPage = PAGES[currentPage] || DashboardPage;

  useEffect(() => {
    setCurrentPage('dashboard');
  }, []);

  useEffect(() => {
    if (!user?.id || !user?.companyId) return;
    notificationService.getUnreadCount(user.id, user.companyId)
      .then(count => setUnreadCount(count))
      .catch(() => {});

    // Poll for notifications every 30 seconds
    const interval = setInterval(() => {
      notificationService.getUnreadCount(user.id, user.companyId)
        .then(count => setUnreadCount(count))
        .catch(() => {});
    }, 30000);

    return () => clearInterval(interval);
  }, [user?.id, user?.companyId]);

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      <Sidebar
        currentPage={currentPage}
        onNavigate={handleNavigate}
        unreadNotifications={unreadCount}
      />

      {/* Main Content */}
      <div
        className="flex-1 flex flex-col min-h-screen overflow-hidden transition-all duration-200"
        style={{ marginLeft: typeof window !== 'undefined' && window.innerWidth >= 1024 ? (collapsed ? 72 : 256) : 0 }}
      >
        <TopBar onNavigate={handleNavigate} unreadNotifications={unreadCount} />

        <main className="flex-1 overflow-y-auto">
          <div className="p-4 sm:p-6 max-w-[1600px] mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentPage}
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.2 }}
              >
                <Suspense fallback={
                  <div className="flex items-center justify-center h-64">
                    <svg className="animate-spin h-8 w-8 text-indigo-600" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                  </div>
                }>
                  <CurrentPage />
                </Suspense>
              </motion.div>
            </AnimatePresence>
          </div>
        </main>
      </div>
    </div>
  );
};

// ============================================================
// ROOT APP
// ============================================================
export default function App() {
  const { isAuthenticated, initialize } = useAuthStore();
  const { dbStatus, setDbStatus } = useAppStore();
  const [dbInitialized, setDbInitialized] = useState(false);

  // Initialize auth from storage
  useEffect(() => {
    initialize();
  }, []);

  // Bootstrap database
  useEffect(() => {
    let mounted = true;

    const init = async () => {
      setDbStatus('connecting');

      // Brief delay to show connecting state
      await new Promise(resolve => setTimeout(resolve, 800));

      if (!mounted) return;
      setDbStatus('initializing');

      try {
        await bootstrapDatabase();
        if (!mounted) return;
        setDbStatus('connected');
        setDbInitialized(true);
      } catch (err) {
        if (!mounted) return;
        const errorMsg = err instanceof Error ? err.message : 'Unknown error';
        console.error('DB init failed:', errorMsg);

        // Still allow the app to work - DB errors are non-fatal for demo
        setDbStatus('error', errorMsg);

        // After 3 seconds, still show the app (graceful degradation)
        setTimeout(() => {
          if (mounted) {
            setDbStatus('connected');
            setDbInitialized(true);
          }
        }, 3000);
      }
    };

    init();
    return () => { mounted = false; };
  }, []);

  // Show DB init screen
  if (!dbInitialized && (dbStatus === 'connecting' || dbStatus === 'initializing')) {
    return (
      <>
        <DbInitScreen status={dbStatus as 'connecting' | 'initializing'} />
        <Toaster position="top-right" />
      </>
    );
  }

  if (dbStatus === 'error' && !dbInitialized) {
    return (
      <>
        <DbInitScreen status="error" error="Could not connect to Neon PostgreSQL. Check your connection." />
        <Toaster position="top-right" />
      </>
    );
  }

  return (
    <>
      <AnimatePresence mode="wait">
        {!isAuthenticated ? (
          <motion.div key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LoginPage />
          </motion.div>
        ) : (
          <motion.div key="app" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <AppLayout />
          </motion.div>
        )}
      </AnimatePresence>

      <Toaster
        position="top-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: '#1e293b',
            color: '#f1f5f9',
            borderRadius: '12px',
            fontSize: '14px',
            border: '1px solid #334155',
          },
          success: { iconTheme: { primary: '#10b981', secondary: '#fff' } },
          error: { iconTheme: { primary: '#ef4444', secondary: '#fff' } },
        }}
      />
    </>
  );
}
