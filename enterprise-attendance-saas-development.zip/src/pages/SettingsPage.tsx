import React, { useState, useEffect } from 'react';
import { Settings, Building2, Lock, Globe, MapPin, Save } from 'lucide-react';
import { useAuthStore } from '../store/auth.store';
import { query } from '../lib/database';
import { authService } from '../services/auth.service';
import { Card } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Input, Select } from '../components/ui/Input';
import toast from 'react-hot-toast';

const TIMEZONES = [
  { value: 'UTC', label: 'UTC' },
  { value: 'America/New_York', label: 'Eastern Time (ET)' },
  { value: 'America/Chicago', label: 'Central Time (CT)' },
  { value: 'America/Denver', label: 'Mountain Time (MT)' },
  { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
  { value: 'Europe/London', label: 'London (GMT)' },
  { value: 'Europe/Paris', label: 'Central European (CET)' },
  { value: 'Asia/Dubai', label: 'Dubai (GST)' },
  { value: 'Asia/Kolkata', label: 'India Standard Time (IST)' },
  { value: 'Asia/Singapore', label: 'Singapore Time (SGT)' },
  { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' },
  { value: 'Australia/Sydney', label: 'Sydney (AEST)' },
];

export const SettingsPage: React.FC = () => {
  const { user, setUser } = useAuthStore();
  const companyId = user?.companyId || '';
  const userId = user?.id || '';

  const [activeTab, setActiveTab] = useState<'company' | 'security' | 'geofencing' | 'subscription'>('company');
  const [saving, setSaving] = useState(false);

  const [companyForm, setCompanyForm] = useState({
    name: user?.company?.name || '',
    email: user?.company?.email || '',
    phone: '',
    website: '',
    industry: '',
    timezone: user?.company?.timezone || 'UTC',
    workingHoursPerDay: user?.company?.workingHoursPerDay || 8,
    workingDaysPerWeek: user?.company?.workingDaysPerWeek || 5,
    overtimeThreshold: user?.company?.overtimeThreshold || 8,
  });

  const [geoForm, setGeoForm] = useState({
    enabled: false,
    radius: 100,
    lat: '',
    lng: '',
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '', newPassword: '', confirmPassword: '',
  });

  useEffect(() => {
    if (!companyId) return;
    query<{
      phone: string; website: string; industry: string; geofencing_enabled: boolean;
      geofence_radius: number; geofence_lat: number; geofence_lng: number;
    }>(
      'SELECT phone, website, industry, geofencing_enabled, geofence_radius, geofence_lat, geofence_lng FROM companies WHERE id = $1',
      [companyId]
    ).then(result => {
      if (result.rows[0]) {
        const c = result.rows[0];
        setCompanyForm(prev => ({ ...prev, phone: c.phone || '', website: c.website || '', industry: c.industry || '' }));
        setGeoForm({
          enabled: c.geofencing_enabled || false,
          radius: c.geofence_radius || 100,
          lat: c.geofence_lat?.toString() || '',
          lng: c.geofence_lng?.toString() || '',
        });
      }
    }).catch(console.error);
  }, [companyId]);

  const handleSaveCompany = async () => {
    setSaving(true);
    try {
      await query(
        `UPDATE companies SET name=$1, email=$2, phone=$3, website=$4, industry=$5, timezone=$6,
         working_hours_per_day=$7, working_days_per_week=$8, overtime_threshold=$9, updated_at=NOW()
         WHERE id=$10`,
        [companyForm.name, companyForm.email, companyForm.phone, companyForm.website,
         companyForm.industry, companyForm.timezone, companyForm.workingHoursPerDay,
         companyForm.workingDaysPerWeek, companyForm.overtimeThreshold, companyId]
      );

      if (user?.company) {
        setUser({ ...user, company: { ...user.company, name: companyForm.name, timezone: companyForm.timezone } });
      }
      toast.success('Company settings saved successfully');
    } catch (err) {
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveGeofence = async () => {
    setSaving(true);
    try {
      await query(
        `UPDATE companies SET geofencing_enabled=$1, geofence_radius=$2, geofence_lat=$3, geofence_lng=$4 WHERE id=$5`,
        [geoForm.enabled, geoForm.radius, geoForm.lat ? parseFloat(geoForm.lat) : null, geoForm.lng ? parseFloat(geoForm.lng) : null, companyId]
      );
      toast.success('Geofencing settings saved');
    } catch (err) {
      toast.error('Failed to save geofencing settings');
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async () => {
    if (!passwordForm.newPassword || !passwordForm.currentPassword) {
      toast.error('Please fill in all password fields');
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    if (passwordForm.newPassword.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    setSaving(true);
    try {
      await authService.changePassword(userId, passwordForm.currentPassword, passwordForm.newPassword);
      toast.success('Password changed successfully');
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to change password');
    } finally {
      setSaving(false);
    }
  };

  const tabs = [
    { id: 'company', label: 'Company', icon: <Building2 size={16} /> },
    { id: 'geofencing', label: 'Geofencing', icon: <MapPin size={16} /> },
    { id: 'security', label: 'Security', icon: <Lock size={16} /> },
    { id: 'subscription', label: 'Subscription', icon: <Globe size={16} /> },
  ] as const;

  const PLAN_FEATURES: Record<string, { features: string[]; price: string; employees: string }> = {
    trial: { features: ['10 employees', '14-day trial', 'Basic attendance', 'Core reports'], price: 'Free', employees: '10' },
    starter: { features: ['50 employees', 'Full attendance', 'Leave management', 'Basic payroll', 'Email support'], price: '$49/mo', employees: '50' },
    professional: { features: ['200 employees', 'All starter features', 'GPS geofencing', 'Advanced payroll', 'API access', 'Priority support'], price: '$149/mo', employees: '200' },
    enterprise: { features: ['Unlimited employees', 'All pro features', 'Custom integrations', 'SSO/SAML', 'Dedicated support', 'SLA guarantee'], price: 'Custom', employees: 'Unlimited' },
  };

  const currentPlan = user?.company?.subscriptionPlan || 'trial';

  return (
    <div className="max-w-3xl space-y-6">
      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-5 py-3 text-sm font-medium transition-colors border-b-2 ${
              activeTab === tab.id
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-700'
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Company Settings */}
      {activeTab === 'company' && (
        <Card>
          <h3 className="font-semibold text-slate-800 mb-6 flex items-center gap-2">
            <Building2 size={18} className="text-indigo-600" />
            Company Information
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Company Name" value={companyForm.name} onChange={e => setCompanyForm(p => ({ ...p, name: e.target.value }))} required />
            <Input label="Company Email" type="email" value={companyForm.email} onChange={e => setCompanyForm(p => ({ ...p, email: e.target.value }))} />
            <Input label="Phone" value={companyForm.phone} onChange={e => setCompanyForm(p => ({ ...p, phone: e.target.value }))} />
            <Input label="Website" value={companyForm.website} onChange={e => setCompanyForm(p => ({ ...p, website: e.target.value }))} placeholder="https://yourcompany.com" />
            <Input label="Industry" value={companyForm.industry} onChange={e => setCompanyForm(p => ({ ...p, industry: e.target.value }))} />
            <Select label="Timezone" value={companyForm.timezone} onChange={e => setCompanyForm(p => ({ ...p, timezone: e.target.value }))} options={TIMEZONES} />
          </div>

          <div className="border-t border-slate-100 mt-6 pt-6">
            <h4 className="font-medium text-slate-700 mb-4">Work Schedule</h4>
            <div className="grid grid-cols-3 gap-4">
              <Input
                label="Working Hours/Day"
                type="number"
                value={companyForm.workingHoursPerDay}
                onChange={e => setCompanyForm(p => ({ ...p, workingHoursPerDay: Number(e.target.value) }))}
                min="1" max="24"
              />
              <Input
                label="Working Days/Week"
                type="number"
                value={companyForm.workingDaysPerWeek}
                onChange={e => setCompanyForm(p => ({ ...p, workingDaysPerWeek: Number(e.target.value) }))}
                min="1" max="7"
              />
              <Input
                label="Overtime After (hours)"
                type="number"
                value={companyForm.overtimeThreshold}
                onChange={e => setCompanyForm(p => ({ ...p, overtimeThreshold: Number(e.target.value) }))}
                min="1"
              />
            </div>
          </div>

          <div className="flex justify-end mt-6">
            <Button onClick={handleSaveCompany} loading={saving} leftIcon={<Save size={14} />}>
              Save Company Settings
            </Button>
          </div>
        </Card>
      )}

      {/* Geofencing */}
      {activeTab === 'geofencing' && (
        <Card>
          <h3 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
            <MapPin size={18} className="text-indigo-600" />
            GPS Geofencing
          </h3>
          <p className="text-sm text-slate-400 mb-6">Define a geofence zone to validate employee clock-in/out locations.</p>

          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div
                onClick={() => setGeoForm(p => ({ ...p, enabled: !p.enabled }))}
                className={`relative w-12 h-6 rounded-full cursor-pointer transition-colors ${geoForm.enabled ? 'bg-indigo-600' : 'bg-slate-200'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-transform ${geoForm.enabled ? 'translate-x-7' : 'translate-x-1'}`} />
              </div>
              <label className="text-sm font-medium text-slate-700">Enable Geofencing</label>
            </div>

            {geoForm.enabled && (
              <div className="space-y-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
                <div className="grid grid-cols-2 gap-4">
                  <Input
                    label="Office Latitude"
                    value={geoForm.lat}
                    onChange={e => setGeoForm(p => ({ ...p, lat: e.target.value }))}
                    placeholder="40.7128"
                    hint="e.g., 40.7128 for New York"
                  />
                  <Input
                    label="Office Longitude"
                    value={geoForm.lng}
                    onChange={e => setGeoForm(p => ({ ...p, lng: e.target.value }))}
                    placeholder="-74.0060"
                    hint="e.g., -74.0060 for New York"
                  />
                </div>
                <Input
                  label="Geofence Radius (meters)"
                  type="number"
                  value={geoForm.radius}
                  onChange={e => setGeoForm(p => ({ ...p, radius: Number(e.target.value) }))}
                  min="50" max="5000"
                  hint="Employees must be within this radius to clock in/out"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (navigator.geolocation) {
                      navigator.geolocation.getCurrentPosition(pos => {
                        setGeoForm(p => ({
                          ...p,
                          lat: pos.coords.latitude.toFixed(6),
                          lng: pos.coords.longitude.toFixed(6),
                        }));
                        toast.success('Current location detected');
                      });
                    }
                  }}
                  className="text-sm text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1.5"
                >
                  <MapPin size={14} />
                  Use My Current Location
                </button>
              </div>
            )}
          </div>

          <div className="flex justify-end mt-6">
            <Button onClick={handleSaveGeofence} loading={saving} leftIcon={<Save size={14} />}>
              Save Geofencing Settings
            </Button>
          </div>
        </Card>
      )}

      {/* Security */}
      {activeTab === 'security' && (
        <Card>
          <h3 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
            <Lock size={18} className="text-indigo-600" />
            Change Password
          </h3>
          <p className="text-sm text-slate-400 mb-6">Keep your account secure with a strong password.</p>

          <div className="space-y-4">
            <Input
              label="Current Password"
              type="password"
              value={passwordForm.currentPassword}
              onChange={e => setPasswordForm(p => ({ ...p, currentPassword: e.target.value }))}
              required
            />
            <Input
              label="New Password"
              type="password"
              value={passwordForm.newPassword}
              onChange={e => setPasswordForm(p => ({ ...p, newPassword: e.target.value }))}
              required
              hint="Minimum 8 characters"
            />
            <Input
              label="Confirm New Password"
              type="password"
              value={passwordForm.confirmPassword}
              onChange={e => setPasswordForm(p => ({ ...p, confirmPassword: e.target.value }))}
              required
              error={passwordForm.confirmPassword && passwordForm.newPassword !== passwordForm.confirmPassword ? 'Passwords do not match' : undefined}
            />
          </div>

          <div className="flex justify-end mt-6">
            <Button onClick={handleChangePassword} loading={saving} leftIcon={<Save size={14} />}>
              Update Password
            </Button>
          </div>

          {/* Security Info */}
          <div className="mt-6 pt-6 border-t border-slate-100">
            <h4 className="font-medium text-slate-700 mb-3">Security Information</h4>
            <div className="space-y-3">
              {[
                { label: 'Authentication', value: 'PBKDF2-SHA256 with 100,000 iterations', icon: '🔐' },
                { label: 'Session Tokens', value: 'JWT with 1-hour expiry + refresh tokens', icon: '🎟️' },
                { label: 'Rate Limiting', value: 'Max 5 failed attempts → 30-min lockout', icon: '🛡️' },
                { label: 'Database', value: 'Neon PostgreSQL with TLS/SSL encryption', icon: '🗄️' },
              ].map(item => (
                <div key={item.label} className="flex items-start gap-3 p-3 bg-slate-50 rounded-xl">
                  <span className="text-lg">{item.icon}</span>
                  <div>
                    <p className="text-sm font-medium text-slate-700">{item.label}</p>
                    <p className="text-xs text-slate-500">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </Card>
      )}

      {/* Subscription */}
      {activeTab === 'subscription' && (
        <div className="space-y-4">
          <Card>
            <h3 className="font-semibold text-slate-800 mb-2">Current Plan</h3>
            <div className="flex items-center gap-3 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
              <div className="p-3 bg-indigo-600 rounded-xl">
                <Globe size={20} className="text-white" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-slate-900 text-lg capitalize">{currentPlan} Plan</p>
                <p className="text-sm text-slate-500">
                  {PLAN_FEATURES[currentPlan]?.employees} employees · {PLAN_FEATURES[currentPlan]?.price}
                </p>
              </div>
              <span className="px-3 py-1.5 bg-emerald-100 text-emerald-700 text-sm font-medium rounded-full">
                Active
              </span>
            </div>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {(['starter', 'professional', 'enterprise'] as const).map(plan => {
              const p = PLAN_FEATURES[plan];
              const isCurrentPlan = plan === currentPlan;
              return (
                <Card key={plan} className={isCurrentPlan ? 'ring-2 ring-indigo-600' : ''}>
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-semibold text-slate-800 capitalize">{plan}</h4>
                    <span className="text-lg font-bold text-indigo-600">{p.price}</span>
                  </div>
                  <ul className="space-y-1.5 mb-4">
                    {p.features.map(f => (
                      <li key={f} className="flex items-center gap-2 text-sm text-slate-600">
                        <span className="text-emerald-500">✓</span>
                        {f}
                      </li>
                    ))}
                  </ul>
                  <Button
                    variant={isCurrentPlan ? 'secondary' : 'primary'}
                    className="w-full"
                    disabled={isCurrentPlan}
                    size="sm"
                  >
                    {isCurrentPlan ? 'Current Plan' : `Upgrade to ${plan.charAt(0).toUpperCase() + plan.slice(1)}`}
                  </Button>
                </Card>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
