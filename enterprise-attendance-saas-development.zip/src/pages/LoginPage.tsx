import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Eye, EyeOff, Mail, Lock, ArrowRight, Building2, User, Phone } from 'lucide-react';
import { useAuthStore } from '../store/auth.store';
import { Button } from '../components/ui/Button';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import toast from 'react-hot-toast';

const DEMO_ACCOUNTS = [
  { email: 'admin@acmecorp.com', password: 'Admin@1234', role: 'Company Admin', color: 'bg-indigo-600' },
  { email: 'hr@acmecorp.com', password: 'Admin@1234', role: 'HR Manager', color: 'bg-violet-600' },
  { email: 'employee@acmecorp.com', password: 'Admin@1234', role: 'Employee', color: 'bg-emerald-600' },
];

const INDUSTRIES = [
  { value: 'technology', label: 'Technology' },
  { value: 'healthcare', label: 'Healthcare' },
  { value: 'finance', label: 'Finance & Banking' },
  { value: 'retail', label: 'Retail & E-commerce' },
  { value: 'manufacturing', label: 'Manufacturing' },
  { value: 'education', label: 'Education' },
  { value: 'hospitality', label: 'Hospitality' },
  { value: 'construction', label: 'Construction' },
  { value: 'other', label: 'Other' },
];

export const LoginPage: React.FC = () => {
  const { login, register, isLoading, error, clearError } = useAuthStore();
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [showPassword, setShowPassword] = useState(false);

  const [loginForm, setLoginForm] = useState({ email: '', password: '' });
  const [regForm, setRegForm] = useState({
    companyName: '', email: '', password: '', firstName: '', lastName: '',
    phone: '', industry: '',
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    try {
      await login(loginForm.email, loginForm.password);
      toast.success('Welcome back!');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Login failed');
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    clearError();
    if (regForm.password.length < 8) {
      toast.error('Password must be at least 8 characters');
      return;
    }
    try {
      await register({
        companyName: regForm.companyName,
        email: regForm.email,
        password: regForm.password,
        firstName: regForm.firstName,
        lastName: regForm.lastName,
        phone: regForm.phone,
        industry: regForm.industry,
      });
      toast.success('Account created! Initializing your workspace...');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Registration failed');
    }
  };

  const handleDemoLogin = async (demo: typeof DEMO_ACCOUNTS[0]) => {
    clearError();
    try {
      await login(demo.email, demo.password);
      toast.success(`Logged in as ${demo.role}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Demo login failed');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 flex">
      {/* Left Panel */}
      <div className="hidden lg:flex lg:flex-1 relative overflow-hidden">
        {/* Background effects */}
        <div className="absolute inset-0">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-violet-500/20 rounded-full blur-3xl" />
        </div>

        <div className="relative z-10 flex flex-col justify-between p-12 text-white">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-2xl flex items-center justify-center shadow-2xl">
              <Clock size={24} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">AttendX</h1>
              <p className="text-indigo-300 text-sm">Enterprise Platform</p>
            </div>
          </div>

          {/* Main Content */}
          <div className="space-y-8">
            <div>
              <h2 className="text-5xl font-bold leading-tight">
                Enterprise<br />Attendance<br />
                <span className="text-indigo-400">Management</span>
              </h2>
              <p className="text-slate-400 text-lg mt-4 max-w-md">
                Real-time workforce tracking with GPS geofencing, automated payroll, and deep analytics — all in one platform.
              </p>
            </div>

            {/* Features */}
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: '🗄️', label: 'Live PostgreSQL', desc: 'Neon production DB' },
                { icon: '🔐', label: 'Enterprise Security', desc: 'PBKDF2 + JWT auth' },
                { icon: '📍', label: 'GPS Geofencing', desc: 'Real location tracking' },
                { icon: '💰', label: 'Auto Payroll', desc: 'Overtime calculations' },
                { icon: '📊', label: 'Analytics', desc: 'Deep insights' },
                { icon: '🏢', label: 'Multi-tenant', desc: 'Company isolation' },
              ].map(f => (
                <div key={f.label} className="flex items-start gap-3 bg-white/5 backdrop-blur rounded-xl p-3 border border-white/10">
                  <span className="text-2xl">{f.icon}</span>
                  <div>
                    <p className="text-sm font-semibold text-white">{f.label}</p>
                    <p className="text-xs text-slate-400">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Tech Stack */}
          <div className="flex items-center gap-3 text-slate-500 text-sm">
            <span>Powered by</span>
            <div className="flex gap-2">
              {['React 19', 'TypeScript', 'Neon PG', 'Zustand'].map(t => (
                <span key={t} className="px-2 py-1 bg-white/5 border border-white/10 rounded-lg text-xs text-slate-400">{t}</span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Auth Form */}
      <div className="flex-1 lg:max-w-lg flex items-center justify-center p-6 lg:p-12">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md space-y-6"
        >
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-xl flex items-center justify-center">
              <Clock size={20} className="text-white" />
            </div>
            <h1 className="text-xl font-bold text-white">AttendX</h1>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8">
            {/* Tabs */}
            <div className="flex bg-white/5 rounded-xl p-1 mb-6">
              {(['login', 'register'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setMode(tab)}
                  className={`flex-1 py-2.5 text-sm font-medium rounded-lg transition-all ${
                    mode === tab
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {tab === 'login' ? 'Sign In' : 'Create Account'}
                </button>
              ))}
            </div>

            {mode === 'login' ? (
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-300">Email Address</label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="email"
                      value={loginForm.email}
                      onChange={e => setLoginForm(p => ({ ...p, email: e.target.value }))}
                      placeholder="you@company.com"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-300">Password</label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={loginForm.password}
                      onChange={e => setLoginForm(p => ({ ...p, password: e.target.value }))}
                      placeholder="••••••••"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-10 pr-10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                    >
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-red-400 text-sm">
                    {error}
                  </div>
                )}

                <Button type="submit" loading={isLoading} className="w-full" rightIcon={<ArrowRight size={16} />}>
                  Sign In
                </Button>

                {/* Demo Accounts */}
                <div className="space-y-2 pt-2">
                  <p className="text-xs text-slate-500 text-center font-medium">— Quick Demo Access —</p>
                  {DEMO_ACCOUNTS.map(demo => (
                    <button
                      key={demo.email}
                      type="button"
                      onClick={() => handleDemoLogin(demo)}
                      disabled={isLoading}
                      className="w-full flex items-center gap-3 px-4 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-sm text-slate-300 hover:text-white transition-all"
                    >
                      <div className={`w-2 h-2 rounded-full ${demo.color}`} />
                      <span className="flex-1 text-left">{demo.role}</span>
                      <span className="text-xs text-slate-500">{demo.email}</span>
                    </button>
                  ))}
                </div>
              </form>
            ) : (
              <form onSubmit={handleRegister} className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-300">Company Name <span className="text-red-400">*</span></label>
                  <div className="relative">
                    <Building2 size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="text"
                      value={regForm.companyName}
                      onChange={e => setRegForm(p => ({ ...p, companyName: e.target.value }))}
                      placeholder="Acme Corporation"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-300">First Name <span className="text-red-400">*</span></label>
                    <div className="relative">
                      <User size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        type="text"
                        value={regForm.firstName}
                        onChange={e => setRegForm(p => ({ ...p, firstName: e.target.value }))}
                        placeholder="John"
                        required
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-9 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-300">Last Name <span className="text-red-400">*</span></label>
                    <input
                      type="text"
                      value={regForm.lastName}
                      onChange={e => setRegForm(p => ({ ...p, lastName: e.target.value }))}
                      placeholder="Doe"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-300">Work Email <span className="text-red-400">*</span></label>
                  <div className="relative">
                    <Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type="email"
                      value={regForm.email}
                      onChange={e => setRegForm(p => ({ ...p, email: e.target.value }))}
                      placeholder="john@company.com"
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label className="text-sm font-medium text-slate-300">Password <span className="text-red-400">*</span></label>
                  <div className="relative">
                    <Lock size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={regForm.password}
                      onChange={e => setRegForm(p => ({ ...p, password: e.target.value }))}
                      placeholder="Min 8 characters"
                      required
                      minLength={8}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-10 pr-10 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
                      {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-300">Phone</label>
                    <div className="relative">
                      <Phone size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
                      <input
                        type="tel"
                        value={regForm.phone}
                        onChange={e => setRegForm(p => ({ ...p, phone: e.target.value }))}
                        placeholder="+1 (555) 000-0000"
                        className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 pl-9 text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-sm font-medium text-slate-300">Industry</label>
                    <select
                      value={regForm.industry}
                      onChange={e => setRegForm(p => ({ ...p, industry: e.target.value }))}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-3.5 py-2.5 text-white text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 appearance-none"
                    >
                      <option value="">Select...</option>
                      {INDUSTRIES.map(i => <option key={i.value} value={i.value} className="bg-slate-800">{i.label}</option>)}
                    </select>
                  </div>
                </div>

                {error && (
                  <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 text-red-400 text-sm">{error}</div>
                )}

                <Button type="submit" loading={isLoading} className="w-full" rightIcon={<ArrowRight size={16} />}>
                  Create Free Account
                </Button>

                <p className="text-xs text-slate-500 text-center">
                  14-day free trial. No credit card required. Includes demo data & 10 employees.
                </p>
              </form>
            )}
          </div>
        </motion.div>
      </div>
    </div>
  );
};
