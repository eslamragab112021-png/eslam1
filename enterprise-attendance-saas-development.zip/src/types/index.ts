// ============================================================
// ENTERPRISE TYPES — AttendX SaaS Platform
// ============================================================

export type SubscriptionPlan = 'starter' | 'professional' | 'enterprise';
export type SubscriptionStatus = 'active' | 'inactive' | 'trial' | 'cancelled' | 'past_due';
export type UserRole = 'super_admin' | 'company_admin' | 'hr_manager' | 'department_manager' | 'employee';
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'half_day' | 'on_leave' | 'holiday' | 'weekend';
export type LeaveType = 'annual' | 'sick' | 'personal' | 'maternity' | 'paternity' | 'unpaid' | 'other';
export type LeaveStatus = 'pending' | 'approved' | 'rejected' | 'cancelled';
export type ShiftType = 'day' | 'night' | 'rotating' | 'flexible';
export type Gender = 'male' | 'female' | 'other' | 'prefer_not_to_say';
export type EmploymentType = 'full_time' | 'part_time' | 'contract' | 'intern';
export type PayrollStatus = 'draft' | 'processing' | 'paid' | 'failed';

export interface Company {
  id: string;
  name: string;
  slug: string;
  email: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
  logo?: string;
  website?: string;
  industry?: string;
  employeeCount: number;
  subscriptionPlan: SubscriptionPlan;
  subscriptionStatus: SubscriptionStatus;
  trialEndsAt?: string;
  timezone: string;
  workingHoursPerDay: number;
  workingDaysPerWeek: number;
  overtimeThreshold: number;
  geofencingEnabled: boolean;
  geofenceRadius: number;
  geofenceLat?: number;
  geofenceLng?: number;
  createdAt: string;
  updatedAt: string;
}

export interface User {
  id: string;
  companyId: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  isActive: boolean;
  lastLoginAt?: string;
  createdAt: string;
  company?: Company;
  employee?: Employee;
}

export interface Department {
  id: string;
  companyId: string;
  name: string;
  code: string;
  description?: string;
  managerId?: string;
  manager?: Employee;
  employeeCount?: number;
  createdAt: string;
}

export interface Shift {
  id: string;
  companyId: string;
  name: string;
  type: ShiftType;
  startTime: string;
  endTime: string;
  breakDuration: number;
  workingDays: number[];
  isActive: boolean;
  gracePeriodMinutes: number;
  overtimeStartMinutes: number;
  createdAt: string;
}

export interface Employee {
  id: string;
  companyId: string;
  userId: string;
  employeeCode: string;
  firstName: string;
  lastName: string;
  email: string;
  phone?: string;
  avatar?: string;
  gender: Gender;
  dateOfBirth?: string;
  nationality?: string;
  address?: string;
  city?: string;
  country?: string;
  departmentId?: string;
  department?: Department;
  shiftId?: string;
  shift?: Shift;
  jobTitle: string;
  employmentType: EmploymentType;
  salary: number;
  currency: string;
  hireDate: string;
  terminationDate?: string;
  managerId?: string;
  manager?: Partial<Employee>;
  isActive: boolean;
  annualLeaveBalance: number;
  sickLeaveBalance: number;
  personalLeaveBalance: number;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  createdAt: string;
  updatedAt: string;
}

export interface AttendanceRecord {
  id: string;
  companyId: string;
  employeeId: string;
  employee?: Employee;
  date: string;
  clockIn?: string;
  clockOut?: string;
  clockInLat?: number;
  clockInLng?: number;
  clockOutLat?: number;
  clockOutLng?: number;
  clockInAddress?: string;
  clockOutAddress?: string;
  isWithinGeofence?: boolean;
  status: AttendanceStatus;
  regularHours: number;
  overtimeHours: number;
  totalHours: number;
  lateMinutes: number;
  earlyLeaveMinutes: number;
  breakMinutes: number;
  notes?: string;
  approvedBy?: string;
  createdAt: string;
  updatedAt: string;
}

export interface LeaveRequest {
  id: string;
  companyId: string;
  employeeId: string;
  employee?: Employee;
  leaveType: LeaveType;
  startDate: string;
  endDate: string;
  totalDays: number;
  reason: string;
  status: LeaveStatus;
  approvedById?: string;
  approvedBy?: Partial<Employee>;
  approvedAt?: string;
  rejectionReason?: string;
  attachmentUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PayrollRecord {
  id: string;
  companyId: string;
  employeeId: string;
  employee?: Employee;
  period: string;
  periodStart: string;
  periodEnd: string;
  baseSalary: number;
  overtimePay: number;
  deductions: number;
  bonuses: number;
  grossPay: number;
  taxAmount: number;
  netPay: number;
  currency: string;
  status: PayrollStatus;
  paidAt?: string;
  workingDays: number;
  presentDays: number;
  absentDays: number;
  leaveDays: number;
  overtimeHours: number;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  companyId: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error' | 'attendance' | 'leave' | 'payroll';
  isRead: boolean;
  actionUrl?: string;
  createdAt: string;
}

export interface AuditLog {
  id: string;
  companyId: string;
  userId: string;
  user?: Partial<User>;
  action: string;
  resource: string;
  resourceId?: string;
  oldValues?: Record<string, unknown>;
  newValues?: Record<string, unknown>;
  ipAddress?: string;
  userAgent?: string;
  createdAt: string;
}

export interface Subscription {
  id: string;
  companyId: string;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  trialStart?: string;
  trialEnd?: string;
  monthlyAmount: number;
  currency: string;
  maxEmployees: number;
  features: string[];
}

export interface DashboardStats {
  totalEmployees: number;
  presentToday: number;
  absentToday: number;
  onLeaveToday: number;
  lateToday: number;
  attendanceRate: number;
  pendingLeaveRequests: number;
  overtimeHoursThisMonth: number;
  newHiresThisMonth: number;
  departmentBreakdown: Array<{ department: string; present: number; absent: number; total: number }>;
  weeklyTrend: Array<{ date: string; present: number; absent: number; late: number }>;
  topDepartments: Array<{ name: string; attendanceRate: number }>;
  recentActivity: Array<{ employeeName: string; action: string; time: string; avatar?: string }>;
}

export interface ClockEventPayload {
  type: 'clock_in' | 'clock_out';
  latitude?: number;
  longitude?: number;
  address?: string;
  notes?: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface LoginResponse {
  user: User;
  tokens: AuthTokens;
}

export interface ApiResponse<T> {
  data: T;
  message?: string;
  success: boolean;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface Permission {
  resource: string;
  actions: string[];
}

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  super_admin: [{ resource: '*', actions: ['*'] }],
  company_admin: [
    { resource: 'employees', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'attendance', actions: ['create', 'read', 'update', 'delete', 'approve'] },
    { resource: 'leave', actions: ['create', 'read', 'update', 'delete', 'approve'] },
    { resource: 'payroll', actions: ['create', 'read', 'update', 'delete', 'process'] },
    { resource: 'departments', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'shifts', actions: ['create', 'read', 'update', 'delete'] },
    { resource: 'reports', actions: ['read', 'export'] },
    { resource: 'settings', actions: ['read', 'update'] },
    { resource: 'audit_logs', actions: ['read'] },
  ],
  hr_manager: [
    { resource: 'employees', actions: ['create', 'read', 'update'] },
    { resource: 'attendance', actions: ['create', 'read', 'update', 'approve'] },
    { resource: 'leave', actions: ['read', 'approve'] },
    { resource: 'payroll', actions: ['read', 'process'] },
    { resource: 'departments', actions: ['read'] },
    { resource: 'shifts', actions: ['read'] },
    { resource: 'reports', actions: ['read', 'export'] },
  ],
  department_manager: [
    { resource: 'employees', actions: ['read'] },
    { resource: 'attendance', actions: ['read', 'approve'] },
    { resource: 'leave', actions: ['read', 'approve'] },
    { resource: 'departments', actions: ['read'] },
    { resource: 'reports', actions: ['read'] },
  ],
  employee: [
    { resource: 'attendance', actions: ['create', 'read'] },
    { resource: 'leave', actions: ['create', 'read'] },
    { resource: 'payroll', actions: ['read'] },
  ],
};

export function hasPermission(role: UserRole, resource: string, action: string): boolean {
  const perms = ROLE_PERMISSIONS[role];
  if (!perms) return false;
  for (const perm of perms) {
    if ((perm.resource === '*' || perm.resource === resource) &&
        (perm.actions.includes('*') || perm.actions.includes(action))) {
      return true;
    }
  }
  return false;
}
