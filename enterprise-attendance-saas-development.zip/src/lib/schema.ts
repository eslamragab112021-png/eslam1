// ============================================================
// DATABASE SCHEMA INITIALIZATION
// Real PostgreSQL schema for AttendX SaaS Platform
// ============================================================

import { query } from './database';

export const SCHEMA_SQL = `
-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ============================================================
-- COMPANIES (Multi-tenant root)
-- ============================================================
CREATE TABLE IF NOT EXISTS companies (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  phone VARCHAR(50),
  address TEXT,
  city VARCHAR(100),
  country VARCHAR(100) DEFAULT 'US',
  logo_url TEXT,
  website VARCHAR(255),
  industry VARCHAR(100),
  employee_count INTEGER DEFAULT 0,
  subscription_plan VARCHAR(50) DEFAULT 'trial' CHECK (subscription_plan IN ('starter','professional','enterprise','trial')),
  subscription_status VARCHAR(50) DEFAULT 'trial' CHECK (subscription_status IN ('active','inactive','trial','cancelled','past_due')),
  trial_ends_at TIMESTAMPTZ DEFAULT NOW() + INTERVAL '14 days',
  timezone VARCHAR(100) DEFAULT 'UTC',
  working_hours_per_day DECIMAL(4,2) DEFAULT 8.0,
  working_days_per_week INTEGER DEFAULT 5,
  overtime_threshold DECIMAL(4,2) DEFAULT 8.0,
  geofencing_enabled BOOLEAN DEFAULT false,
  geofence_radius INTEGER DEFAULT 100,
  geofence_lat DECIMAL(10,8),
  geofence_lng DECIMAL(11,8),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SUBSCRIPTIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS subscriptions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  plan VARCHAR(50) NOT NULL,
  status VARCHAR(50) NOT NULL DEFAULT 'active',
  current_period_start TIMESTAMPTZ DEFAULT NOW(),
  current_period_end TIMESTAMPTZ DEFAULT NOW() + INTERVAL '30 days',
  cancel_at_period_end BOOLEAN DEFAULT false,
  trial_start TIMESTAMPTZ,
  trial_end TIMESTAMPTZ,
  monthly_amount DECIMAL(10,2) DEFAULT 0,
  currency VARCHAR(10) DEFAULT 'USD',
  max_employees INTEGER DEFAULT 10,
  features JSONB DEFAULT '[]',
  stripe_subscription_id VARCHAR(255),
  stripe_customer_id VARCHAR(255),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- USERS (Authentication)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  role VARCHAR(50) NOT NULL DEFAULT 'employee' CHECK (role IN ('super_admin','company_admin','hr_manager','department_manager','employee')),
  is_active BOOLEAN DEFAULT true,
  email_verified BOOLEAN DEFAULT false,
  email_verification_token TEXT,
  password_reset_token TEXT,
  password_reset_expires TIMESTAMPTZ,
  last_login_at TIMESTAMPTZ,
  failed_login_attempts INTEGER DEFAULT 0,
  locked_until TIMESTAMPTZ,
  refresh_token TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- DEPARTMENTS
-- ============================================================
CREATE TABLE IF NOT EXISTS departments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(50) NOT NULL,
  description TEXT,
  manager_id UUID,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, code)
);

-- ============================================================
-- SHIFTS
-- ============================================================
CREATE TABLE IF NOT EXISTS shifts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(50) DEFAULT 'day' CHECK (type IN ('day','night','rotating','flexible')),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  break_duration INTEGER DEFAULT 60,
  working_days INTEGER[] DEFAULT '{1,2,3,4,5}',
  grace_period_minutes INTEGER DEFAULT 15,
  overtime_start_minutes INTEGER DEFAULT 30,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- EMPLOYEES
-- ============================================================
CREATE TABLE IF NOT EXISTS employees (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID UNIQUE REFERENCES users(id) ON DELETE SET NULL,
  employee_code VARCHAR(50) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  avatar_url TEXT,
  gender VARCHAR(50) DEFAULT 'prefer_not_to_say',
  date_of_birth DATE,
  nationality VARCHAR(100),
  address TEXT,
  city VARCHAR(100),
  country VARCHAR(100),
  department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
  shift_id UUID REFERENCES shifts(id) ON DELETE SET NULL,
  job_title VARCHAR(255) NOT NULL,
  employment_type VARCHAR(50) DEFAULT 'full_time' CHECK (employment_type IN ('full_time','part_time','contract','intern')),
  salary DECIMAL(12,2) DEFAULT 0,
  currency VARCHAR(10) DEFAULT 'USD',
  hire_date DATE NOT NULL,
  termination_date DATE,
  manager_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  is_active BOOLEAN DEFAULT true,
  annual_leave_balance DECIMAL(5,2) DEFAULT 21,
  sick_leave_balance DECIMAL(5,2) DEFAULT 10,
  personal_leave_balance DECIMAL(5,2) DEFAULT 5,
  emergency_contact_name VARCHAR(255),
  emergency_contact_phone VARCHAR(50),
  bank_account_number VARCHAR(100),
  bank_name VARCHAR(255),
  tax_id VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, employee_code)
);

-- ============================================================
-- ATTENDANCE RECORDS
-- ============================================================
CREATE TABLE IF NOT EXISTS attendance_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  clock_in TIMESTAMPTZ,
  clock_out TIMESTAMPTZ,
  clock_in_lat DECIMAL(10,8),
  clock_in_lng DECIMAL(11,8),
  clock_out_lat DECIMAL(10,8),
  clock_out_lng DECIMAL(11,8),
  clock_in_address TEXT,
  clock_out_address TEXT,
  is_within_geofence BOOLEAN,
  status VARCHAR(50) DEFAULT 'absent' CHECK (status IN ('present','absent','late','half_day','on_leave','holiday','weekend')),
  regular_hours DECIMAL(5,2) DEFAULT 0,
  overtime_hours DECIMAL(5,2) DEFAULT 0,
  total_hours DECIMAL(5,2) DEFAULT 0,
  late_minutes INTEGER DEFAULT 0,
  early_leave_minutes INTEGER DEFAULT 0,
  break_minutes INTEGER DEFAULT 0,
  notes TEXT,
  approved_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, employee_id, date)
);

-- ============================================================
-- LEAVE REQUESTS
-- ============================================================
CREATE TABLE IF NOT EXISTS leave_requests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  leave_type VARCHAR(50) NOT NULL CHECK (leave_type IN ('annual','sick','personal','maternity','paternity','unpaid','other')),
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  total_days DECIMAL(5,2) NOT NULL,
  reason TEXT NOT NULL,
  status VARCHAR(50) DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','cancelled')),
  approved_by_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  approved_at TIMESTAMPTZ,
  rejection_reason TEXT,
  attachment_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- PAYROLL RECORDS
-- ============================================================
CREATE TABLE IF NOT EXISTS payroll_records (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  employee_id UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
  period VARCHAR(20) NOT NULL,
  period_start DATE NOT NULL,
  period_end DATE NOT NULL,
  base_salary DECIMAL(12,2) DEFAULT 0,
  overtime_pay DECIMAL(12,2) DEFAULT 0,
  deductions DECIMAL(12,2) DEFAULT 0,
  bonuses DECIMAL(12,2) DEFAULT 0,
  gross_pay DECIMAL(12,2) DEFAULT 0,
  tax_amount DECIMAL(12,2) DEFAULT 0,
  net_pay DECIMAL(12,2) DEFAULT 0,
  currency VARCHAR(10) DEFAULT 'USD',
  status VARCHAR(50) DEFAULT 'draft' CHECK (status IN ('draft','processing','paid','failed')),
  paid_at TIMESTAMPTZ,
  working_days INTEGER DEFAULT 0,
  present_days INTEGER DEFAULT 0,
  absent_days INTEGER DEFAULT 0,
  leave_days INTEGER DEFAULT 0,
  overtime_hours DECIMAL(5,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(company_id, employee_id, period)
);

-- ============================================================
-- NOTIFICATIONS
-- ============================================================
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(50) DEFAULT 'info' CHECK (type IN ('info','success','warning','error','attendance','leave','payroll')),
  is_read BOOLEAN DEFAULT false,
  action_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- AUDIT LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  user_id UUID REFERENCES users(id) ON DELETE SET NULL,
  action VARCHAR(100) NOT NULL,
  resource VARCHAR(100) NOT NULL,
  resource_id UUID,
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- ACTIVITY LOGS
-- ============================================================
CREATE TABLE IF NOT EXISTS activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  company_id UUID REFERENCES companies(id) ON DELETE CASCADE,
  employee_id UUID REFERENCES employees(id) ON DELETE SET NULL,
  action VARCHAR(255) NOT NULL,
  details JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES FOR PERFORMANCE
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_company ON users(company_id);
CREATE INDEX IF NOT EXISTS idx_employees_company ON employees(company_id);
CREATE INDEX IF NOT EXISTS idx_employees_department ON employees(department_id);
CREATE INDEX IF NOT EXISTS idx_employees_email ON employees(email);
CREATE INDEX IF NOT EXISTS idx_attendance_employee_date ON attendance_records(employee_id, date);
CREATE INDEX IF NOT EXISTS idx_attendance_company_date ON attendance_records(company_id, date);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance_records(date);
CREATE INDEX IF NOT EXISTS idx_attendance_status ON attendance_records(status);
CREATE INDEX IF NOT EXISTS idx_leave_requests_employee ON leave_requests(employee_id);
CREATE INDEX IF NOT EXISTS idx_leave_requests_status ON leave_requests(status);
CREATE INDEX IF NOT EXISTS idx_leave_requests_company ON leave_requests(company_id);
CREATE INDEX IF NOT EXISTS idx_payroll_company_period ON payroll_records(company_id, period);
CREATE INDEX IF NOT EXISTS idx_payroll_employee ON payroll_records(employee_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id, is_read);
CREATE INDEX IF NOT EXISTS idx_audit_logs_company ON audit_logs(company_id, created_at);
CREATE INDEX IF NOT EXISTS idx_activity_logs_company ON activity_logs(company_id, created_at);

-- ============================================================
-- UPDATED_AT TRIGGER
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_companies_updated_at') THEN
    CREATE TRIGGER update_companies_updated_at BEFORE UPDATE ON companies FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_users_updated_at') THEN
    CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_employees_updated_at') THEN
    CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON employees FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_attendance_updated_at') THEN
    CREATE TRIGGER update_attendance_updated_at BEFORE UPDATE ON attendance_records FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_leave_updated_at') THEN
    CREATE TRIGGER update_leave_updated_at BEFORE UPDATE ON leave_requests FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;
`;

export async function initializeSchema(): Promise<void> {
  console.log('🗄️  Initializing AttendX database schema...');
  
  // Split and execute each statement
  const statements = SCHEMA_SQL
    .split(';')
    .map(s => s.trim())
    .filter(s => s.length > 0 && !s.startsWith('--'));

  for (const stmt of statements) {
    if (stmt.trim()) {
      try {
        await query(stmt);
      } catch (err) {
        // Log but continue — some statements may already exist
        console.warn('Schema statement warning:', err);
      }
    }
  }
  
  console.log('✅ Database schema initialized');
}

export async function seedDemoData(companyId: string, adminUserId: string): Promise<void> {
  console.log('🌱 Seeding demo data...');
  
  // Check if already seeded
  const existing = await query(
    'SELECT id FROM employees WHERE company_id = $1 LIMIT 1',
    [companyId]
  );
  
  if (existing.rowCount > 0) {
    console.log('✅ Demo data already exists');
    return;
  }

  // Create departments
  const deptResult = await query(`
    INSERT INTO departments (company_id, name, code, description) VALUES
    ($1, 'Engineering', 'ENG', 'Software Engineering & Development'),
    ($1, 'Human Resources', 'HR', 'People & Culture Management'),
    ($1, 'Sales & Marketing', 'SALES', 'Revenue Generation & Brand'),
    ($1, 'Finance', 'FIN', 'Financial Operations & Accounting'),
    ($1, 'Operations', 'OPS', 'Business Operations & Administration')
    RETURNING id, name
  `, [companyId]);

  const depts = deptResult.rows as Array<{ id: string; name: string }>;

  // Create shifts
  const shiftResult = await query(`
    INSERT INTO shifts (company_id, name, type, start_time, end_time, break_duration, working_days, grace_period_minutes) VALUES
    ($1, 'Morning Shift', 'day', '09:00', '17:00', 60, '{1,2,3,4,5}', 15),
    ($1, 'Evening Shift', 'night', '14:00', '22:00', 60, '{1,2,3,4,5}', 15),
    ($1, 'Night Shift', 'night', '22:00', '06:00', 60, '{1,2,3,4,5}', 15),
    ($1, 'Flexible Hours', 'flexible', '08:00', '18:00', 60, '{1,2,3,4,5}', 30)
    RETURNING id, name
  `, [companyId]);

  const shifts = shiftResult.rows as Array<{ id: string; name: string }>;

  // Create employees
  const employees = [
    { code: 'EMP-001', first: 'Sarah', last: 'Johnson', email: 'sarah.johnson@acmecorp.com', title: 'Senior Software Engineer', dept: depts[0]?.id, shift: shifts[0]?.id, salary: 95000, gender: 'female', hire: '2021-03-15' },
    { code: 'EMP-002', first: 'Michael', last: 'Chen', email: 'michael.chen@acmecorp.com', title: 'DevOps Engineer', dept: depts[0]?.id, shift: shifts[0]?.id, salary: 88000, gender: 'male', hire: '2020-06-01' },
    { code: 'EMP-003', first: 'Emma', last: 'Williams', email: 'emma.williams@acmecorp.com', title: 'HR Specialist', dept: depts[1]?.id, shift: shifts[0]?.id, salary: 72000, gender: 'female', hire: '2022-01-10' },
    { code: 'EMP-004', first: 'James', last: 'Brown', email: 'james.brown@acmecorp.com', title: 'Sales Manager', dept: depts[2]?.id, shift: shifts[0]?.id, salary: 82000, gender: 'male', hire: '2019-08-20' },
    { code: 'EMP-005', first: 'Olivia', last: 'Davis', email: 'olivia.davis@acmecorp.com', title: 'Financial Analyst', dept: depts[3]?.id, shift: shifts[0]?.id, salary: 79000, gender: 'female', hire: '2021-11-05' },
    { code: 'EMP-006', first: 'William', last: 'Martinez', email: 'william.martinez@acmecorp.com', title: 'Frontend Developer', dept: depts[0]?.id, shift: shifts[3]?.id, salary: 86000, gender: 'male', hire: '2022-04-18' },
    { code: 'EMP-007', first: 'Sophia', last: 'Anderson', email: 'sophia.anderson@acmecorp.com', title: 'Operations Manager', dept: depts[4]?.id, shift: shifts[0]?.id, salary: 91000, gender: 'female', hire: '2018-12-01' },
    { code: 'EMP-008', first: 'Liam', last: 'Taylor', email: 'liam.taylor@acmecorp.com', title: 'Backend Developer', dept: depts[0]?.id, shift: shifts[0]?.id, salary: 90000, gender: 'male', hire: '2020-09-14' },
    { code: 'EMP-009', first: 'Ava', last: 'Thomas', email: 'ava.thomas@acmecorp.com', title: 'Marketing Specialist', dept: depts[2]?.id, shift: shifts[3]?.id, salary: 68000, gender: 'female', hire: '2023-02-28' },
    { code: 'EMP-010', first: 'Noah', last: 'Jackson', email: 'noah.jackson@acmecorp.com', title: 'Product Manager', dept: depts[0]?.id, shift: shifts[0]?.id, salary: 105000, gender: 'male', hire: '2020-01-06' },
  ];

  const empIds: string[] = [];
  for (const emp of employees) {
    const result = await query(`
      INSERT INTO employees (company_id, employee_code, first_name, last_name, email, gender, department_id, shift_id, job_title, salary, hire_date, annual_leave_balance, sick_leave_balance, personal_leave_balance)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 21, 10, 5)
      RETURNING id
    `, [companyId, emp.code, emp.first, emp.last, emp.email, emp.gender, emp.dept, emp.shift, emp.title, emp.salary, emp.hire]);
    const row = result.rows[0] as { id: string };
    empIds.push(row.id);
  }

  // Generate attendance records for last 30 days
  const today = new Date();
  const statuses = ['present', 'present', 'present', 'present', 'late', 'absent'];
  
  for (const empId of empIds) {
    for (let d = 29; d >= 0; d--) {
      const date = new Date(today);
      date.setDate(today.getDate() - d);
      const dayOfWeek = date.getDay();
      
      if (dayOfWeek === 0 || dayOfWeek === 6) continue; // Skip weekends
      
      const dateStr = date.toISOString().split('T')[0];
      const statusIdx = Math.floor(Math.random() * statuses.length);
      const status = statuses[statusIdx];
      
      let clockIn = null;
      let clockOut = null;
      let regularHours = 0;
      let overtimeHours = 0;
      let totalHours = 0;
      let lateMinutes = 0;

      if (status === 'present') {
        const minutesLate = Math.floor(Math.random() * 5);
        const clockInHour = 9;
        const clockInMinute = minutesLate;
        const clockOutHour = 17 + Math.floor(Math.random() * 2);
        const clockOutMinute = Math.floor(Math.random() * 60);
        
        clockIn = `${dateStr}T${String(clockInHour).padStart(2,'0')}:${String(clockInMinute).padStart(2,'0')}:00Z`;
        clockOut = `${dateStr}T${String(clockOutHour).padStart(2,'0')}:${String(clockOutMinute).padStart(2,'0')}:00Z`;
        totalHours = Math.round(((clockOutHour * 60 + clockOutMinute) - (clockInHour * 60 + clockInMinute)) / 60 * 100) / 100;
        regularHours = Math.min(8, totalHours);
        overtimeHours = Math.max(0, totalHours - 8);
        lateMinutes = minutesLate;
      } else if (status === 'late') {
        const minutesLate = 20 + Math.floor(Math.random() * 40);
        const clockInHour = 9;
        const clockInMinute = minutesLate;
        const adjustedHour = clockInHour + Math.floor(clockInMinute / 60);
        const adjustedMinute = clockInMinute % 60;
        
        clockIn = `${dateStr}T${String(adjustedHour).padStart(2,'0')}:${String(adjustedMinute).padStart(2,'0')}:00Z`;
        clockOut = `${dateStr}T17:${String(Math.floor(Math.random() * 60)).padStart(2,'0')}:00Z`;
        totalHours = 8 - minutesLate / 60;
        regularHours = totalHours;
        overtimeHours = 0;
        lateMinutes = minutesLate;
      }

      await query(`
        INSERT INTO attendance_records (company_id, employee_id, date, clock_in, clock_out, status, regular_hours, overtime_hours, total_hours, late_minutes, break_minutes)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 60)
        ON CONFLICT (company_id, employee_id, date) DO NOTHING
      `, [companyId, empId, dateStr, clockIn, clockOut, status, regularHours, overtimeHours, totalHours, lateMinutes]);
    }
  }

  // Generate leave requests
  if (empIds.length >= 3) {
    await query(`
      INSERT INTO leave_requests (company_id, employee_id, leave_type, start_date, end_date, total_days, reason, status)
      VALUES 
      ($1, $2, 'annual', CURRENT_DATE + 7, CURRENT_DATE + 14, 5, 'Family vacation planned.', 'pending'),
      ($1, $3, 'sick', CURRENT_DATE - 5, CURRENT_DATE - 3, 3, 'Medical appointment and recovery.', 'approved'),
      ($1, $4, 'personal', CURRENT_DATE + 2, CURRENT_DATE + 2, 1, 'Personal matters to attend.', 'pending')
    `, [companyId, empIds[0], empIds[1], empIds[2]]);
  }

  // Generate payroll records for last 3 months
  for (const empId of empIds) {
    const emp = employees[empIds.indexOf(empId)];
    const monthlySalary = emp ? emp.salary / 12 : 5000;
    
    for (let m = 2; m >= 0; m--) {
      const periodDate = new Date(today.getFullYear(), today.getMonth() - m, 1);
      const period = `${periodDate.getFullYear()}-${String(periodDate.getMonth() + 1).padStart(2, '0')}`;
      const periodStart = `${period}-01`;
      const lastDay = new Date(periodDate.getFullYear(), periodDate.getMonth() + 1, 0).getDate();
      const periodEnd = `${period}-${lastDay}`;
      
      const overtimePay = Math.random() * 500;
      const bonuses = m === 0 ? 0 : Math.random() * 1000;
      const deductions = monthlySalary * 0.02;
      const grossPay = monthlySalary + overtimePay + bonuses - deductions;
      const taxAmount = grossPay * 0.25;
      const netPay = grossPay - taxAmount;
      
      await query(`
        INSERT INTO payroll_records (company_id, employee_id, period, period_start, period_end, base_salary, overtime_pay, deductions, bonuses, gross_pay, tax_amount, net_pay, status, working_days, present_days, absent_days, overtime_hours)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, 22, 20, 2, $14)
        ON CONFLICT (company_id, employee_id, period) DO NOTHING
      `, [companyId, empId, period, periodStart, periodEnd, monthlySalary, overtimePay, deductions, bonuses, grossPay, taxAmount, netPay, m === 0 ? 'draft' : 'paid', (overtimePay / 25).toFixed(2)]);
    }
  }

  // Create notifications
  await query(`
    INSERT INTO notifications (user_id, company_id, title, message, type)
    VALUES 
    ($1, $2, 'Welcome to AttendX!', 'Your enterprise attendance platform is ready. Start by adding your employees.', 'success'),
    ($1, $2, 'Leave Request Pending', '3 leave requests require your approval.', 'warning'),
    ($1, $2, 'Payroll Due', 'Monthly payroll processing is due in 5 days.', 'info')
  `, [adminUserId, companyId]);

  console.log('✅ Demo data seeded successfully');
}
