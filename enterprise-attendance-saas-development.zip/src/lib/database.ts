// ============================================================
// REAL DATABASE LAYER — Direct Neon PostgreSQL via HTTP API
// AttendX Enterprise SaaS Platform
// ============================================================

const NEON_HOST = 'ep-tiny-union-apswekeb-pooler.c-7.us-east-1.aws.neon.tech';
const NEON_DATABASE = 'neondb';
const NEON_USER = 'neondb_owner';
const NEON_PASSWORD = 'npg_6XAxmdh4DtCQ';

export interface QueryResult<T = Record<string, unknown>> {
  rows: T[];
  rowCount: number;
  command: string;
}

// Execute real SQL against Neon PostgreSQL via HTTP API
export async function query<T = Record<string, unknown>>(
  sql: string,
  params: unknown[] = []
): Promise<QueryResult<T>> {
  const response = await fetch(`https://${NEON_HOST}/sql`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Neon-Connection-String': `postgresql://${NEON_USER}:${NEON_PASSWORD}@${NEON_HOST}/${NEON_DATABASE}?sslmode=require`,
    },
    body: JSON.stringify({ query: sql, params }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`DB Error: ${response.status} — ${errorText}`);
  }

  const result = await response.json();
  return {
    rows: (result.rows || []) as T[],
    rowCount: result.rowCount ?? result.rows?.length ?? 0,
    command: result.command ?? 'SELECT',
  };
}

export default { query };
