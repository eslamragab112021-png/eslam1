import { cn } from '../../utils/cn';
import { STATUS_COLORS, STATUS_LABELS } from '../../utils/format';

interface BadgeProps {
  status: string;
  className?: string;
}

export function Badge({ status, className }: BadgeProps) {
  const color = STATUS_COLORS[status] || 'bg-gray-100 text-gray-600 border-gray-200';
  const label = STATUS_LABELS[status] || status;
  return (
    <span className={cn('inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold border', color, className)}>
      {label}
    </span>
  );
}
