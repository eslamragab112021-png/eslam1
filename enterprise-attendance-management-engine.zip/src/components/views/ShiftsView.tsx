import { useState } from 'react';
import { Plus, Edit2, Trash2, Users } from 'lucide-react';
import { useStore } from '../../store';
import { createShift, updateShift, deleteShift, assignShift, formatShiftTime, getShiftDayNames } from '../../engine/shifts';
import { Card, CardBody, CardHeader } from '../ui/Card';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';

import toast from 'react-hot-toast';
import type { Shift } from '../../db/schema';

const SHIFT_TYPE_COLOR: Record<string, string> = {
  fixed: 'bg-blue-100 text-blue-700',
  flexible: 'bg-emerald-100 text-emerald-700',
  rotating: 'bg-purple-100 text-purple-700',
  overnight: 'bg-gray-800 text-white',
};

const defaultForm: Omit<Shift, 'id' | 'createdAt' | 'updatedAt'> = {
  name: '',
  type: 'fixed',
  startTime: '09:00',
  endTime: '18:00',
  gracePeriodMinutes: 15,
  overtimeThresholdMinutes: 30,
  breakDurationMinutes: 60,
  workingDays: [1, 2, 3, 4, 5],
  isOvernightShift: false,
};

export function ShiftsView() {
  const { shifts, employees, loadShifts, loadEmployees } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState(defaultForm);
  const [showAssign, setShowAssign] = useState(false);
  const [assignShiftId, setAssignShiftId] = useState('');
  const [assignEmpId, setAssignEmpId] = useState('');
  const [saving, setSaving] = useState(false);

  const openCreate = () => { setEditId(null); setForm(defaultForm); setShowForm(true); };
  const openEdit = (s: Shift) => { setEditId(s.id); setForm({ ...s }); setShowForm(true); };

  const handleSave = async () => {
    if (!form.name) return toast.error('Shift name is required');
    setSaving(true);
    try {
      if (editId) {
        await updateShift(editId, form);
        toast.success('Shift updated');
      } else {
        await createShift(form);
        toast.success('Shift created');
      }
      await loadShifts();
      setShowForm(false);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this shift?')) return;
    await deleteShift(id);
    await loadShifts();
    toast.success('Shift deleted');
  };

  const handleAssign = async () => {
    if (!assignEmpId || !assignShiftId) return toast.error('Select employee and shift');
    try {
      await assignShift(assignEmpId, assignShiftId, new Date().toISOString().split('T')[0]);
      await loadShifts();
      await loadEmployees();
      setShowAssign(false);
      toast.success('Shift assigned');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const toggleDay = (day: number) => {
    setForm((f) => ({
      ...f,
      workingDays: f.workingDays.includes(day)
        ? f.workingDays.filter((d) => d !== day)
        : [...f.workingDays, day].sort(),
    }));
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Shift Configuration</h2>
          <p className="text-sm text-gray-500">{shifts.length} shifts defined</p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={() => setShowAssign(true)}>
            <Users size={16} />
            Assign Shift
          </Button>
          <Button onClick={openCreate}>
            <Plus size={16} />
            New Shift
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {shifts.map((shift) => {
          const assignedCount = employees.filter((e) => e.shiftId === shift.id).length;
          return (
            <Card key={shift.id}>
              <CardBody>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-gray-900">{shift.name}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${SHIFT_TYPE_COLOR[shift.type]}`}>
                        {shift.type}
                      </span>
                      {shift.isOvernightShift && (
                        <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-700 font-semibold">Overnight</span>
                      )}
                    </div>
                    <div className="text-2xl font-mono font-bold text-indigo-600 mt-1">
                      {formatShiftTime(shift)}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(shift)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-700">
                      <Edit2 size={14} />
                    </button>
                    <button onClick={() => handleDelete(shift.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">Working Days</span>
                    <span className="font-medium text-gray-700">{getShiftDayNames(shift)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">Grace Period</span>
                    <span className="font-medium text-gray-700">{shift.gracePeriodMinutes} min</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">OT Threshold</span>
                    <span className="font-medium text-gray-700">{shift.overtimeThresholdMinutes} min</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">Break Duration</span>
                    <span className="font-medium text-gray-700">{shift.breakDurationMinutes} min</span>
                  </div>
                  {shift.flexStartEarliest && (
                    <div className="flex items-center justify-between">
                      <span className="text-gray-500">Flex Window</span>
                      <span className="font-medium text-gray-700">{shift.flexStartEarliest} – {shift.flexStartLatest}</span>
                    </div>
                  )}
                </div>

                <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between">
                  <span className="text-xs text-gray-500">Assigned employees</span>
                  <span className="inline-flex items-center gap-1 text-sm font-bold text-indigo-600">
                    <Users size={12} /> {assignedCount}
                  </span>
                </div>
              </CardBody>
            </Card>
          );
        })}
      </div>

      {/* Employee Shift Table */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-gray-900">Employee Shift Assignments</h3>
        </CardHeader>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-100">
                {['Employee', 'Department', 'Shift', 'Hours', 'Working Days'].map((h) => (
                  <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {employees.map((emp) => {
                const shift = shifts.find((s) => s.id === emp.shiftId);
                return (
                  <tr key={emp.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <div className="font-medium text-gray-900">{emp.name}</div>
                      <div className="text-xs text-gray-400">{emp.employeeCode}</div>
                    </td>
                    <td className="px-4 py-3 text-gray-600">{emp.department}</td>
                    <td className="px-4 py-3">
                      {shift ? (
                        <span className={`text-xs px-2 py-1 rounded-full font-semibold ${SHIFT_TYPE_COLOR[shift.type]}`}>
                          {shift.name}
                        </span>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 font-mono text-gray-700">
                      {shift ? formatShiftTime(shift) : '—'}
                    </td>
                    <td className="px-4 py-3 text-gray-600 text-xs">
                      {shift ? getShiftDayNames(shift) : '—'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {/* Create/Edit Modal */}
      <Modal open={showForm} onClose={() => setShowForm(false)} title={editId ? 'Edit Shift' : 'Create Shift'} size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Shift Name *</label>
              <input
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Morning Shift"
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Shift Type</label>
              <select
                value={form.type}
                onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as Shift['type'] }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                <option value="fixed">Fixed</option>
                <option value="flexible">Flexible</option>
                <option value="rotating">Rotating</option>
                <option value="overnight">Overnight</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Time</label>
              <input type="time" value={form.startTime} onChange={(e) => setForm((f) => ({ ...f, startTime: e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Time</label>
              <input type="time" value={form.endTime} onChange={(e) => setForm((f) => ({ ...f, endTime: e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Grace Period (min)</label>
              <input type="number" value={form.gracePeriodMinutes} onChange={(e) => setForm((f) => ({ ...f, gracePeriodMinutes: +e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">OT Threshold (min)</label>
              <input type="number" value={form.overtimeThresholdMinutes} onChange={(e) => setForm((f) => ({ ...f, overtimeThresholdMinutes: +e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Break Duration (min)</label>
              <input type="number" value={form.breakDurationMinutes} onChange={(e) => setForm((f) => ({ ...f, breakDurationMinutes: +e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Working Days</label>
            <div className="flex gap-2">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((name, i) => (
                <button
                  key={name}
                  onClick={() => toggleDay(i)}
                  className={`w-10 h-10 rounded-xl text-xs font-bold transition-all ${form.workingDays.includes(i) ? 'bg-indigo-600 text-white' : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}`}
                >
                  {name}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="overnight"
              checked={form.isOvernightShift}
              onChange={(e) => setForm((f) => ({ ...f, isOvernightShift: e.target.checked }))}
              className="w-4 h-4 text-indigo-600 rounded"
            />
            <label htmlFor="overnight" className="text-sm font-medium text-gray-700">Overnight shift (end time is next day)</label>
          </div>

          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={handleSave} loading={saving}>{editId ? 'Update' : 'Create'} Shift</Button>
          </div>
        </div>
      </Modal>

      {/* Assign Modal */}
      <Modal open={showAssign} onClose={() => setShowAssign(false)} title="Assign Shift to Employee" size="sm">
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Employee</label>
            <select
              value={assignEmpId}
              onChange={(e) => setAssignEmpId(e.target.value)}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Select employee…</option>
              {employees.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Shift</label>
            <select
              value={assignShiftId}
              onChange={(e) => setAssignShiftId(e.target.value)}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="">Select shift…</option>
              {shifts.map((s) => <option key={s.id} value={s.id}>{s.name} ({formatShiftTime(s)})</option>)}
            </select>
          </div>
          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowAssign(false)}>Cancel</Button>
            <Button onClick={handleAssign}>Assign</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
