import { useState } from 'react';
import { Plus, MapPin, Edit2, Trash2, Navigation } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import { useStore } from '../../store';
import { dbPut, dbDelete } from '../../db/database';
import { haversineDistance } from '../../engine/attendance';
import { Card, CardBody } from '../ui/Card';
import { Button } from '../ui/Button';
import { Modal } from '../ui/Modal';
import toast from 'react-hot-toast';
import type { WorkLocation } from '../../db/schema';

export function LocationsView() {
  const { locations, employees, loadLocations } = useStore();
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [gettingGPS, setGettingGPS] = useState(false);
  const [userPos, setUserPos] = useState<{ lat: number; lng: number } | null>(null);
  const [form, setForm] = useState({
    name: '',
    address: '',
    latitude: 0,
    longitude: 0,
    radiusMeters: 150,
    isActive: true,
  });

  const openCreate = () => {
    setEditId(null);
    setForm({ name: '', address: '', latitude: 0, longitude: 0, radiusMeters: 150, isActive: true });
    setShowForm(true);
  };

  const openEdit = (loc: WorkLocation) => {
    setEditId(loc.id);
    setForm({ name: loc.name, address: loc.address, latitude: loc.latitude, longitude: loc.longitude, radiusMeters: loc.radiusMeters, isActive: loc.isActive });
    setShowForm(true);
  };

  const handleSave = async () => {
    if (!form.name || !form.latitude || !form.longitude) return toast.error('Name and coordinates required');
    setSaving(true);
    try {
      const loc: WorkLocation = {
        id: editId || uuidv4(),
        ...form,
        createdAt: new Date().toISOString(),
      };
      await dbPut('work_locations', loc);
      await loadLocations();
      setShowForm(false);
      toast.success(editId ? 'Location updated' : 'Location created');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm('Delete this location?')) return;
    await dbDelete('work_locations', id);
    await loadLocations();
    toast.success('Location deleted');
  };

  const getGPS = async () => {
    setGettingGPS(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setForm((f) => ({ ...f, latitude: pos.coords.latitude, longitude: pos.coords.longitude }));
        setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setGettingGPS(false);
        toast.success('GPS location captured');
      },
      (err) => { toast.error(err.message); setGettingGPS(false); },
      { enableHighAccuracy: true }
    );
  };

  const getUserLocation = async () => {
    navigator.geolocation.getCurrentPosition(
      (pos) => setUserPos({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => {}
    );
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Work Locations & Geofencing</h2>
          <p className="text-sm text-gray-500">{locations.length} locations configured</p>
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={getUserLocation}>
            <Navigation size={16} />
            Get My Location
          </Button>
          <Button onClick={openCreate}>
            <Plus size={16} />
            Add Location
          </Button>
        </div>
      </div>

      {userPos && (
        <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex items-center gap-3">
          <Navigation size={16} className="text-blue-600" />
          <div className="text-sm text-blue-700">
            Your location: <span className="font-mono font-semibold">{userPos.lat.toFixed(6)}, {userPos.lng.toFixed(6)}</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {locations.map((loc) => {
          const assignedEmps = employees.filter((e) => e.workLocationId === loc.id);
          const distanceToUser = userPos
            ? Math.round(haversineDistance(userPos.lat, userPos.lng, loc.latitude, loc.longitude))
            : null;
          const withinRadius = distanceToUser !== null && distanceToUser <= loc.radiusMeters;

          return (
            <Card key={loc.id}>
              <CardBody>
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${loc.isActive ? 'bg-emerald-500' : 'bg-gray-400'}`} />
                      <h3 className="font-bold text-gray-900">{loc.name}</h3>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">{loc.address}</p>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(loc)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-700">
                      <Edit2 size={14} />
                    </button>
                    <button onClick={() => handleDelete(loc.id)} className="p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-600">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>

                <div className="space-y-2 text-sm">
                  <div className="bg-gray-50 rounded-xl p-3">
                    <div className="text-xs text-gray-500 mb-1">Coordinates</div>
                    <div className="font-mono text-xs text-gray-700">{loc.latitude.toFixed(6)}, {loc.longitude.toFixed(6)}</div>
                  </div>

                  <div className="flex items-center justify-between">
                    <span className="text-gray-500">Geofence Radius</span>
                    <span className="font-semibold text-gray-900">{loc.radiusMeters}m</span>
                  </div>

                  {distanceToUser !== null && (
                    <div className={`flex items-center justify-between rounded-xl px-3 py-2 ${withinRadius ? 'bg-emerald-50' : 'bg-red-50'}`}>
                      <span className={withinRadius ? 'text-emerald-700' : 'text-red-700'}>
                        {withinRadius ? '✓ You are inside' : '✗ You are outside'}
                      </span>
                      <span className={`font-bold ${withinRadius ? 'text-emerald-700' : 'text-red-700'}`}>{distanceToUser}m</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-gray-100">
                    <span className="text-gray-500 text-xs">Assigned employees</span>
                    <span className="text-sm font-bold text-indigo-600">{assignedEmps.length}</span>
                  </div>
                </div>

                {/* Visual geofence indicator */}
                <div className="mt-3 relative h-20 bg-gray-100 rounded-xl overflow-hidden">
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div
                      className="rounded-full border-2 border-indigo-300 bg-indigo-100/50 flex items-center justify-center"
                      style={{ width: '60px', height: '60px' }}
                    >
                      <MapPin size={16} className="text-indigo-600" />
                    </div>
                  </div>
                  <div className="absolute top-2 right-2 text-xs text-gray-400 font-mono">r={loc.radiusMeters}m</div>
                  {withinRadius && userPos && (
                    <div className="absolute bottom-2 right-2">
                      <div className="w-3 h-3 rounded-full bg-blue-500 border-2 border-white shadow-sm animate-pulse" title="You" />
                    </div>
                  )}
                </div>
              </CardBody>
            </Card>
          );
        })}
      </div>

      {/* Location Modal */}
      <Modal open={showForm} onClose={() => setShowForm(false)} title={editId ? 'Edit Location' : 'Add Work Location'} size="lg">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Location Name *</label>
              <input
                value={form.name}
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                placeholder="e.g. Headquarters"
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Geofence Radius (meters)</label>
              <input
                type="number"
                value={form.radiusMeters}
                onChange={(e) => setForm((f) => ({ ...f, radiusMeters: +e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
            <input
              value={form.address}
              onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))}
              placeholder="Full address"
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Latitude *</label>
              <input
                type="number"
                step="0.000001"
                value={form.latitude}
                onChange={(e) => setForm((f) => ({ ...f, latitude: +e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Longitude *</label>
              <input
                type="number"
                step="0.000001"
                value={form.longitude}
                onChange={(e) => setForm((f) => ({ ...f, longitude: +e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          <Button variant="secondary" onClick={getGPS} loading={gettingGPS} className="w-full justify-center">
            <Navigation size={14} />
            Use My Current GPS Location
          </Button>

          <div className="flex items-center gap-3">
            <input
              type="checkbox"
              id="isActive"
              checked={form.isActive}
              onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))}
              className="w-4 h-4 text-indigo-600 rounded"
            />
            <label htmlFor="isActive" className="text-sm font-medium text-gray-700">Location is active</label>
          </div>

          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowForm(false)}>Cancel</Button>
            <Button onClick={handleSave} loading={saving}>{editId ? 'Update' : 'Create'}</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
