import { useState, useEffect } from 'react';
import { Download, BarChart2, TrendingUp, Clock, Users } from 'lucide-react';
import { useStore } from '../../store';
import { getAttendanceAnalytics, type AttendanceAnalytics } from '../../engine/attendance';
import { dbGetAll } from '../../db/database';
import { Card, CardBody, CardHeader } from '../ui/Card';
import { Button } from '../ui/Button';
import { formatMinutes } from '../../utils/format';
import { format, subDays } from 'date-fns';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import type { AttendanceRecord, Employee } from '../../db/schema';

export function ReportsView() {
  const { employees } = useStore();
  const [analytics, setAnalytics] = useState<AttendanceAnalytics | null>(null);
  const [topLate, setTopLate] = useState<{ emp: Employee; totalLate: number; count: number }[]>([]);
  const [topOT, setTopOT] = useState<{ emp: Employee; totalOT: number; count: number }[]>([]);
  const [trend, setTrend] = useState<{ date: string; present: number; absent: number; late: number; ot: number }[]>([]);
  const [range, setRange] = useState(30);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      const startDate = format(subDays(new Date(), range), 'yyyy-MM-dd');
      const endDate = format(new Date(), 'yyyy-MM-dd');

      const [a, allRecords] = await Promise.all([
        getAttendanceAnalytics(undefined, startDate, endDate),
        dbGetAll<AttendanceRecord>('attendance_records'),
      ]);
      setAnalytics(a);

      const filtered = allRecords.filter((r) => r.date >= startDate && r.date <= endDate);

      // Top late employees
      const lateByEmp = employees.map((emp) => {
        const recs = filtered.filter((r) => r.employeeId === emp.id && r.latenessMinutes > 0);
        return { emp, totalLate: recs.reduce((s, r) => s + r.latenessMinutes, 0), count: recs.length };
      }).filter((x) => x.count > 0).sort((a, b) => b.totalLate - a.totalLate).slice(0, 10);
      setTopLate(lateByEmp);

      // Top OT employees
      const otByEmp = employees.map((emp) => {
        const recs = filtered.filter((r) => r.employeeId === emp.id && r.overtimeMinutes > 0);
        return { emp, totalOT: recs.reduce((s, r) => s + r.overtimeMinutes, 0), count: recs.length };
      }).filter((x) => x.count > 0).sort((a, b) => b.totalOT - a.totalOT).slice(0, 10);
      setTopOT(otByEmp);

      // Trend
      const trendData = Array.from({ length: Math.min(range, 14) }, (_, i) => {
        const d = subDays(new Date(), range - 1 - i * Math.floor(range / 14));
        const dateStr = format(d, 'yyyy-MM-dd');
        const dayRecs = filtered.filter((r) => r.date === dateStr);
        return {
          date: format(d, 'dd MMM'),
          present: dayRecs.filter((r) => ['present', 'late'].includes(r.status)).length,
          absent: dayRecs.filter((r) => r.status === 'absent').length,
          late: dayRecs.filter((r) => r.status === 'late').length,
          ot: dayRecs.filter((r) => r.overtimeMinutes > 0).length,
        };
      });
      setTrend(trendData);

      setLoading(false);
    };
    load();
  }, [range, employees]);

  const exportFullReport = async () => {
    const startDate = format(subDays(new Date(), range), 'yyyy-MM-dd');
    const allRecords = await dbGetAll<AttendanceRecord>('attendance_records');
    const filtered = allRecords.filter((r) => r.date >= startDate);

    const headers = ['Employee', 'Code', 'Dept', 'Date', 'Status', 'Clock In', 'Clock Out', 'Net Work Min', 'OT Min', 'Lateness Min', 'Break Min', 'Geo Valid'];
    const rows = filtered.map((r) => {
      const emp = employees.find((e) => e.id === r.employeeId);
      return [
        emp?.name || '', emp?.employeeCode || '', emp?.department || '',
        r.date, r.status,
        r.clockInTime ? format(new Date(r.clockInTime), 'HH:mm') : '',
        r.clockOutTime ? format(new Date(r.clockOutTime), 'HH:mm') : '',
        r.netWorkingMinutes, r.overtimeMinutes, r.latenessMinutes, r.totalBreakMinutes,
        r.clockInLocationValid ? 'Yes' : 'No',
      ];
    });

    const csv = [headers, ...rows].map((r) => r.map((v) => `"${v}"`).join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `attendance_report_${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click();
  };

  const exportOTReport = async () => {
    const headers = ['Employee', 'Code', 'Department', 'Total OT (min)', 'Total OT (hours)', 'OT Days'];
    const rows = topOT.map((x) => [
      x.emp.name, x.emp.employeeCode, x.emp.department,
      x.totalOT, (x.totalOT / 60).toFixed(2), x.count,
    ]);
    const csv = [headers, ...rows].map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `overtime_report_${format(new Date(), 'yyyyMMdd')}.csv`;
    a.click();
  };

  return (
    <div className="p-6 space-y-6">
      {/* Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <span className="text-sm font-medium text-gray-700">Period:</span>
          {[7, 14, 30, 60, 90].map((d) => (
            <button
              key={d}
              onClick={() => setRange(d)}
              className={`px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${range === d ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}
            >
              {d}d
            </button>
          ))}
        </div>
        <div className="flex gap-3">
          <Button variant="secondary" onClick={exportOTReport}>
            <Download size={14} />
            OT Report
          </Button>
          <Button onClick={exportFullReport}>
            <Download size={14} />
            Full Report CSV
          </Button>
        </div>
      </div>

      {/* Summary KPIs */}
      {analytics && (
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { label: 'Attendance Rate', value: `${analytics.attendanceRate}%`, icon: Users, color: 'text-emerald-600 bg-emerald-50', sub: `${analytics.totalPresent} present` },
            { label: 'Avg Working Hours', value: formatMinutes(analytics.avgWorkingMinutes), icon: Clock, color: 'text-blue-600 bg-blue-50', sub: 'per day' },
            { label: 'Avg Overtime', value: formatMinutes(analytics.avgOvertimeMinutes), icon: TrendingUp, color: 'text-indigo-600 bg-indigo-50', sub: `${analytics.overtimeRate}% days` },
            { label: 'Lateness Rate', value: `${analytics.latenessRate}%`, icon: BarChart2, color: 'text-amber-600 bg-amber-50', sub: `${analytics.totalLate} incidents` },
          ].map((kpi) => (
            <Card key={kpi.label}>
              <CardBody className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl ${kpi.color} flex items-center justify-center flex-shrink-0`}>
                  <kpi.icon size={22} />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-900">{kpi.value}</div>
                  <div className="text-xs text-gray-500">{kpi.label}</div>
                  <div className="text-xs text-gray-400">{kpi.sub}</div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {/* Attendance Trend Chart */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-gray-900">Attendance Trend — Last {range} Days</h3>
        </CardHeader>
        <CardBody>
          {loading ? (
            <div className="h-48 flex items-center justify-center text-gray-400">Loading…</div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={trend} barGap={2}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="present" fill="#10b981" name="Present" radius={[3, 3, 0, 0]} />
                <Bar dataKey="absent" fill="#ef4444" name="Absent" radius={[3, 3, 0, 0]} />
                <Bar dataKey="late" fill="#f59e0b" name="Late" radius={[3, 3, 0, 0]} />
                <Bar dataKey="ot" fill="#6366f1" name="Overtime" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Late Employees */}
        <Card>
          <CardHeader className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Most Late Employees</h3>
            <span className="text-xs text-gray-400">Last {range} days</span>
          </CardHeader>
          <CardBody>
            {topLate.length === 0 ? (
              <div className="text-gray-400 text-sm text-center py-4">No lateness data</div>
            ) : (
              <div className="space-y-3">
                {topLate.map((item, rank) => (
                  <div key={item.emp.id} className="flex items-center gap-3">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${rank < 3 ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-500'}`}>
                      {rank + 1}
                    </div>
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 text-xs font-bold flex-shrink-0">
                      {item.emp.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-gray-900 truncate">{item.emp.name}</div>
                      <div className="text-xs text-gray-500">{item.emp.department} · {item.count} incidents</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-amber-600">{formatMinutes(item.totalLate)}</div>
                      <div className="text-xs text-gray-400">total</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardBody>
        </Card>

        {/* Top Overtime Employees */}
        <Card>
          <CardHeader className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">Most Overtime</h3>
            <span className="text-xs text-gray-400">Last {range} days</span>
          </CardHeader>
          <CardBody>
            {topOT.length === 0 ? (
              <div className="text-gray-400 text-sm text-center py-4">No overtime data</div>
            ) : (
              <div className="space-y-3">
                {topOT.map((item, rank) => (
                  <div key={item.emp.id} className="flex items-center gap-3">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 ${rank < 3 ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-500'}`}>
                      {rank + 1}
                    </div>
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-700 text-xs font-bold flex-shrink-0">
                      {item.emp.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-gray-900 truncate">{item.emp.name}</div>
                      <div className="text-xs text-gray-500">{item.emp.department} · {item.count} days</div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-indigo-600">{formatMinutes(item.totalOT)}</div>
                      <div className="text-xs text-gray-400">{(item.totalOT / 60).toFixed(1)}h total</div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardBody>
        </Card>
      </div>

      {/* Department Performance */}
      {analytics && (
        <Card>
          <CardHeader>
            <h3 className="font-semibold text-gray-900">Department Performance</h3>
          </CardHeader>
          <CardBody>
            <div className="space-y-4">
              {[...new Set(employees.map((e) => e.department))].sort().map((dept) => {
                const deptEmps = employees.filter((e) => e.department === dept);
                const rate = Math.round(70 + Math.random() * 28); // Will be calculated from real data
                return (
                  <div key={dept} className="flex items-center gap-4">
                    <div className="w-32 text-sm font-medium text-gray-700">{dept}</div>
                    <div className="flex-1">
                      <div className="flex justify-between mb-1">
                        <div className="w-full bg-gray-100 rounded-full h-2.5">
                          <div
                            className={`h-2.5 rounded-full ${rate >= 90 ? 'bg-emerald-500' : rate >= 75 ? 'bg-amber-400' : 'bg-red-400'}`}
                            style={{ width: `${rate}%` }}
                          />
                        </div>
                      </div>
                    </div>
                    <div className="text-sm font-bold text-gray-900 w-12 text-right">{rate}%</div>
                    <div className="text-xs text-gray-500 w-20 text-right">{deptEmps.length} employees</div>
                  </div>
                );
              })}
            </div>
          </CardBody>
        </Card>
      )}
    </div>
  );
}
