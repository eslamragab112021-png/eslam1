import { useState } from 'react';
import { Plus, Check, X } from 'lucide-react';
import { useStore } from '../../store';
import { applyForLeave, approveLeave, rejectLeave } from '../../engine/leave';
import { Card, CardBody, CardHeader } from '../ui/Card';
import { Button } from '../ui/Button';
import { Badge } from '../ui/Badge';
import { Modal } from '../ui/Modal';
import { formatDate } from '../../utils/format';
import toast from 'react-hot-toast';
import type { LeaveRequest } from '../../db/schema';

export function LeavesView() {
  const { employees, leaveRequests, pendingLeaves, currentEmployee, isAdmin, loadLeaves, loadEmployees } = useStore();
  const [showApply, setShowApply] = useState(false);
  const [showReject, setShowReject] = useState(false);
  const [rejectId, setRejectId] = useState('');
  const [rejectNotes, setRejectNotes] = useState('');
  const [tab, setTab] = useState<'all' | 'pending' | 'mine'>('all');
  const [form, setForm] = useState({
    employeeId: currentEmployee?.id || '',
    type: 'annual' as LeaveRequest['type'],
    startDate: '',
    endDate: '',
    reason: '',
  });
  const [submitting, setSubmitting] = useState(false);

  const emp = employees.find((e) => e.id === (form.employeeId || currentEmployee?.id));

  const displayed =
    tab === 'all' ? leaveRequests :
    tab === 'pending' ? pendingLeaves :
    leaveRequests.filter((r) => r.employeeId === currentEmployee?.id);

  const handleApply = async () => {
    if (!form.startDate || !form.endDate || !form.reason) {
      toast.error('Please fill all fields');
      return;
    }
    setSubmitting(true);
    try {
      await applyForLeave(form.employeeId || currentEmployee!.id, form.type, form.startDate, form.endDate, form.reason);
      await loadLeaves();
      setShowApply(false);
      toast.success('Leave request submitted successfully');
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleApprove = async (id: string) => {
    try {
      await approveLeave(id, currentEmployee?.id || 'admin', 'Approved');
      await loadLeaves();
      await loadEmployees();
      toast.success('Leave approved');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const handleReject = async () => {
    try {
      await rejectLeave(rejectId, currentEmployee?.id || 'admin', rejectNotes || 'Rejected');
      await loadLeaves();
      setShowReject(false);
      setRejectNotes('');
      toast.success('Leave rejected');
    } catch (err: any) {
      toast.error(err.message);
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex gap-2">
          {(['all', 'pending', 'mine'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${tab === t ? 'bg-indigo-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}
            >
              {t === 'all' ? 'All Requests' : t === 'pending' ? `Pending (${pendingLeaves.length})` : 'My Leaves'}
            </button>
          ))}
        </div>
        <Button onClick={() => setShowApply(true)}>
          <Plus size={16} />
          Apply Leave
        </Button>
      </div>

      {/* Leave Balance Cards */}
      {currentEmployee && (
        <div className="grid grid-cols-3 gap-4">
          {[
            { type: 'Annual', balance: currentEmployee.annualLeaveBalance, color: 'text-blue-600 bg-blue-50' },
            { type: 'Sick', balance: currentEmployee.sickLeaveBalance, color: 'text-amber-600 bg-amber-50' },
            { type: 'Emergency', balance: currentEmployee.emergencyLeaveBalance, color: 'text-red-600 bg-red-50' },
          ].map((item) => (
            <Card key={item.type}>
              <CardBody className={`text-center rounded-2xl ${item.color}`}>
                <div className="text-3xl font-bold">{item.balance}</div>
                <div className="text-sm font-medium mt-1">{item.type} Leave</div>
                <div className="text-xs opacity-70 mt-0.5">days remaining</div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {/* Requests Table */}
      <Card>
        <CardHeader>
          <h3 className="font-semibold text-gray-900">Leave Requests ({displayed.length})</h3>
        </CardHeader>
        <div className="overflow-x-auto">
          {displayed.length === 0 ? (
            <div className="p-8 text-center text-gray-400">No leave requests found</div>
          ) : (
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-100">
                  {['Employee', 'Type', 'Period', 'Days', 'Reason', 'Status', 'Applied', 'Actions'].map((h) => (
                    <th key={h} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {displayed.map((req) => {
                  const emp = employees.find((e) => e.id === req.employeeId);
                  return (
                    <tr key={req.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-3">
                        <div className="font-medium text-gray-900">{emp?.name || 'Unknown'}</div>
                        <div className="text-xs text-gray-400">{emp?.department}</div>
                      </td>
                      <td className="px-4 py-3"><Badge status={req.type} /></td>
                      <td className="px-4 py-3">
                        <div className="text-gray-700">{formatDate(req.startDate)}</div>
                        <div className="text-gray-400 text-xs">to {formatDate(req.endDate)}</div>
                      </td>
                      <td className="px-4 py-3 font-semibold text-gray-900">{req.totalDays}d</td>
                      <td className="px-4 py-3 text-gray-600 max-w-xs truncate">{req.reason}</td>
                      <td className="px-4 py-3"><Badge status={req.status} /></td>
                      <td className="px-4 py-3 text-gray-500 text-xs">{formatDate(req.appliedAt)}</td>
                      <td className="px-4 py-3">
                        {req.status === 'pending' && isAdmin && (
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleApprove(req.id)}
                              className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700 hover:bg-emerald-200 transition-colors"
                              title="Approve"
                            >
                              <Check size={14} />
                            </button>
                            <button
                              onClick={() => { setRejectId(req.id); setShowReject(true); }}
                              className="p-1.5 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition-colors"
                              title="Reject"
                            >
                              <X size={14} />
                            </button>
                          </div>
                        )}
                        {req.reviewNotes && (
                          <span className="text-xs text-gray-400 italic">{req.reviewNotes}</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </Card>

      {/* Apply Modal */}
      <Modal open={showApply} onClose={() => setShowApply(false)} title="Apply for Leave">
        <div className="space-y-4">
          {isAdmin && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Employee</label>
              <select
                value={form.employeeId}
                onChange={(e) => setForm((f) => ({ ...f, employeeId: e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              >
                {employees.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Leave Type</label>
            <select
              value={form.type}
              onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as LeaveRequest['type'] }))}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
            >
              <option value="annual">Annual Leave</option>
              <option value="sick">Sick Leave</option>
              <option value="emergency">Emergency Leave</option>
              <option value="maternity">Maternity Leave</option>
              <option value="paternity">Paternity Leave</option>
              <option value="unpaid">Unpaid Leave</option>
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
              <input
                type="date"
                value={form.startDate}
                onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">End Date</label>
              <input
                type="date"
                value={form.endDate}
                onChange={(e) => setForm((f) => ({ ...f, endDate: e.target.value }))}
                className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          {emp && (
            <div className="bg-gray-50 rounded-xl p-3 text-sm">
              <span className="text-gray-600">Balance — </span>
              Annual: <span className="font-semibold">{emp.annualLeaveBalance}d</span> ·
              Sick: <span className="font-semibold">{emp.sickLeaveBalance}d</span> ·
              Emergency: <span className="font-semibold">{emp.emergencyLeaveBalance}d</span>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Reason</label>
            <textarea
              value={form.reason}
              onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))}
              rows={3}
              className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
              placeholder="Provide reason for leave…"
            />
          </div>
          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowApply(false)}>Cancel</Button>
            <Button onClick={handleApply} loading={submitting}>Submit Request</Button>
          </div>
        </div>
      </Modal>

      {/* Reject Modal */}
      <Modal open={showReject} onClose={() => setShowReject(false)} title="Reject Leave Request" size="sm">
        <div className="space-y-4">
          <textarea
            value={rejectNotes}
            onChange={(e) => setRejectNotes(e.target.value)}
            rows={3}
            placeholder="Reason for rejection…"
            className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-red-500 resize-none"
          />
          <div className="flex gap-3 justify-end">
            <Button variant="secondary" onClick={() => setShowReject(false)}>Cancel</Button>
            <Button variant="danger" onClick={handleReject}>Reject</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
