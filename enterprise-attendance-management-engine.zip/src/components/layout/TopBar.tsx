import { AlignLeft, RefreshCw, Bell, Search } from 'lucide-react';
import { useStore } from '../../store';
import { format } from 'date-fns';

const VIEW_TITLES: Record<string, string> = {
  dashboard: 'Dashboard',
  clock: 'Clock In / Out',
  attendance: 'My Attendance',
  shifts: 'Shift Management',
  leaves: 'Leave Management',
  locations: 'Work Locations',
  reports: 'Reports & Analytics',
  employees: 'Employees',
  notifications: 'Notifications',
};

export function TopBar() {
  const { activeView, toggleSidebar, loadAll, notifications } = useStore();
  const unread = notifications.filter((n) => !n.read).length;
  const now = new Date();

  return (
    <header className="h-14 bg-white border-b border-gray-100 flex items-center px-4 gap-4 flex-shrink-0">
      <button
        onClick={toggleSidebar}
        className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 hover:text-gray-700 transition-colors"
      >
        <AlignLeft size={18} />
      </button>

      <div className="flex-1">
        <h1 className="text-base font-semibold text-gray-900">{VIEW_TITLES[activeView]}</h1>
        <p className="text-xs text-gray-400">{format(now, 'EEEE, dd MMMM yyyy')}</p>
      </div>

      <div className="hidden md:flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-3 py-1.5">
        <Search size={14} className="text-gray-400" />
        <input
          placeholder="Search…"
          className="bg-transparent text-sm text-gray-700 placeholder-gray-400 outline-none w-40"
          readOnly
        />
      </div>

      <button
        onClick={loadAll}
        className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 hover:text-gray-700 transition-colors"
        title="Refresh data"
      >
        <RefreshCw size={16} />
      </button>

      <div className="relative">
        <button
          className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 hover:text-gray-700 transition-colors"
        >
          <Bell size={16} />
          {unread > 0 && (
            <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
          )}
        </button>
      </div>
    </header>
  );
}
