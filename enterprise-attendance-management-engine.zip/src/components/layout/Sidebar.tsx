import {
  LayoutDashboard, Clock, Users, Calendar, MapPin,
  BarChart3, Bell, AlignLeft, Shield, Layers,
  ChevronRight,
} from 'lucide-react';
import { useStore } from '../../store';
import { cn } from '../../utils/cn';
import type { View } from '../../store';

const NAV_ITEMS: { icon: typeof LayoutDashboard; label: string; view: View; adminOnly?: boolean }[] = [
  { icon: LayoutDashboard, label: 'Dashboard', view: 'dashboard' },
  { icon: Clock, label: 'Clock In/Out', view: 'clock' },
  { icon: Calendar, label: 'My Attendance', view: 'attendance' },
  { icon: Layers, label: 'Leaves', view: 'leaves' },
  { icon: Users, label: 'Employees', view: 'employees', adminOnly: true },
  { icon: AlignLeft, label: 'Shifts', view: 'shifts', adminOnly: true },
  { icon: MapPin, label: 'Locations', view: 'locations', adminOnly: true },
  { icon: BarChart3, label: 'Reports', view: 'reports', adminOnly: true },
  { icon: Bell, label: 'Notifications', view: 'notifications' },
];

export function Sidebar() {
  const { activeView, setView, sidebarOpen, isAdmin, currentEmployee, notifications, toggleAdmin } = useStore();
  const unread = notifications.filter((n) => !n.read).length;

  return (
    <aside
      className={cn(
        'h-screen bg-gray-950 flex flex-col transition-all duration-300 flex-shrink-0',
        sidebarOpen ? 'w-64' : 'w-16'
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5 border-b border-gray-800">
        <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
          <Clock size={16} className="text-white" />
        </div>
        {sidebarOpen && (
          <div>
            <div className="text-white font-bold text-sm leading-none">AttendanceIQ</div>
            <div className="text-gray-500 text-xs mt-0.5">Enterprise Edition</div>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-2 py-4 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.filter((item) => !item.adminOnly || isAdmin).map((item) => {
          const Icon = item.icon;
          const active = activeView === item.view;
          const isNotif = item.view === 'notifications';
          return (
            <button
              key={item.view}
              onClick={() => setView(item.view)}
              className={cn(
                'w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 group',
                active
                  ? 'bg-indigo-600 text-white'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800'
              )}
            >
              <div className="relative flex-shrink-0">
                <Icon size={18} />
                {isNotif && unread > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-red-500 rounded-full text-white text-[9px] flex items-center justify-center font-bold">
                    {unread > 9 ? '9+' : unread}
                  </span>
                )}
              </div>
              {sidebarOpen && <span className="flex-1 text-left">{item.label}</span>}
              {sidebarOpen && active && <ChevronRight size={14} className="opacity-60" />}
            </button>
          );
        })}
      </nav>

      {/* Role Toggle & User */}
      <div className="border-t border-gray-800 p-3 space-y-2">
        {sidebarOpen && (
          <button
            onClick={toggleAdmin}
            className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-gray-400 hover:text-white hover:bg-gray-800 transition-all"
          >
            <Shield size={14} className={isAdmin ? 'text-amber-400' : 'text-gray-600'} />
            <span>{isAdmin ? 'Admin Mode' : 'Employee Mode'}</span>
            <div className={cn(
              'ml-auto w-8 h-4 rounded-full transition-all',
              isAdmin ? 'bg-amber-500' : 'bg-gray-700'
            )}>
              <div className={cn(
                'w-4 h-4 rounded-full bg-white shadow transition-transform',
                isAdmin ? 'translate-x-4' : 'translate-x-0'
              )} />
            </div>
          </button>
        )}
        {currentEmployee && (
          <div className={cn(
            'flex items-center gap-3 px-2 py-2',
            !sidebarOpen && 'justify-center'
          )}>
            <div className="w-8 h-8 rounded-full bg-indigo-600 flex items-center justify-center text-white text-xs font-bold flex-shrink-0">
              {currentEmployee.name.split(' ').map((n) => n[0]).join('').slice(0, 2)}
            </div>
            {sidebarOpen && (
              <div className="flex-1 min-w-0">
                <div className="text-white text-xs font-semibold truncate">{currentEmployee.name}</div>
                <div className="text-gray-500 text-xs truncate">{currentEmployee.designation}</div>
              </div>
            )}
          </div>
        )}
      </div>
    </aside>
  );
}
