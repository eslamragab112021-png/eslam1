import { cn } from '../../utils/cn';
import { getPasswordStrength } from '../../lib/validation';

interface PasswordStrengthMeterProps {
  password: string;
  className?: string;
}

export default function PasswordStrengthMeter({ password, className }: PasswordStrengthMeterProps) {
  if (!password) return null;

  const strength = getPasswordStrength(password);

  return (
    <div className={cn('space-y-2', className)}>
      <div className="flex gap-1">
        {[0, 1, 2, 3, 4].map(i => (
          <div
            key={i}
            className={cn(
              'h-1 flex-1 rounded-full transition-all duration-300',
              i <= strength.score ? strength.color : 'bg-slate-200'
            )}
          />
        ))}
      </div>
      <div className="flex items-center justify-between">
        <span className={cn(
          'text-xs font-medium',
          strength.score <= 1 ? 'text-red-600' :
          strength.score === 2 ? 'text-yellow-600' :
          strength.score === 3 ? 'text-blue-600' : 'text-emerald-600'
        )}>
          {strength.label}
        </span>
        {strength.feedback.length > 0 && (
          <span className="text-xs text-slate-500">{strength.feedback[0]}</span>
        )}
      </div>
    </div>
  );
}
