import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore, useIsAuthenticated, useIsInitialized } from '../../store/authStore';
import type { Role, Permission } from '../../types/auth';
import { hasPermission, hasAnyPermission } from '../../config/roles';

interface ProtectedRouteProps {
  children: React.ReactNode;
  requiredRoles?: Role[];
  requiredPermissions?: Permission[];
  requireAll?: boolean; // true = need ALL permissions, false = need ANY
}

export default function ProtectedRoute({
  children,
  requiredRoles,
  requiredPermissions,
  requireAll = false,
}: ProtectedRouteProps) {
  const location = useLocation();
  const isAuthenticated = useIsAuthenticated();
  const isInitialized = useIsInitialized();
  const user = useAuthStore(s => s.user);

  // Loading state while tokens are being validated
  if (!isInitialized) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-10 h-10 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto" />
          <p className="text-slate-500 text-sm">Validating session...</p>
        </div>
      </div>
    );
  }

  // Not authenticated — redirect to login
  if (!isAuthenticated || !user) {
    return <Navigate to="/auth/login" state={{ from: location.pathname }} replace />;
  }

  // Role-based access check
  if (requiredRoles && requiredRoles.length > 0) {
    if (!requiredRoles.includes(user.role)) {
      return <Navigate to="/unauthorized" replace />;
    }
  }

  // Permission-based access check
  if (requiredPermissions && requiredPermissions.length > 0) {
    const hasAccess = requireAll
      ? requiredPermissions.every(p => hasPermission(user.permissions, p))
      : hasAnyPermission(user.permissions, requiredPermissions);

    if (!hasAccess) {
      return <Navigate to="/unauthorized" replace />;
    }
  }

  return <>{children}</>;
}

// Role gate component for inline use
interface RoleGateProps {
  children: React.ReactNode;
  roles?: Role[];
  permissions?: Permission[];
  fallback?: React.ReactNode;
}

export function RoleGate({ children, roles, permissions, fallback = null }: RoleGateProps) {
  const user = useAuthStore(s => s.user);
  if (!user) return <>{fallback}</>;

  if (roles && !roles.includes(user.role)) return <>{fallback}</>;
  if (permissions && !hasAnyPermission(user.permissions, permissions)) return <>{fallback}</>;

  return <>{children}</>;
}
