import { Shield, Lock, Zap } from 'lucide-react';

interface AuthLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle: string;
}

export default function AuthLayout({ children, title, subtitle }: AuthLayoutProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-900 flex">
      {/* Left Panel */}
      <div className="hidden lg:flex lg:w-[45%] relative flex-col justify-between p-12 overflow-hidden">
        {/* Background decoration */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute -top-40 -left-40 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl" />
          <div className="absolute top-1/2 -right-20 w-96 h-96 bg-violet-500/10 rounded-full blur-3xl" />
          <div className="absolute -bottom-20 left-20 w-72 h-72 bg-blue-500/10 rounded-full blur-3xl" />
          {/* Grid pattern */}
          <div className="absolute inset-0 opacity-[0.02]"
            style={{
              backgroundImage: `linear-gradient(rgba(255,255,255,.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.1) 1px, transparent 1px)`,
              backgroundSize: '40px 40px'
            }}
          />
        </div>

        {/* Logo */}
        <div className="relative">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-indigo-400 to-violet-500 rounded-xl flex items-center justify-center shadow-lg">
              <Shield size={20} className="text-white" />
            </div>
            <div>
              <span className="text-white font-bold text-lg">EnterpriseAuth</span>
              <span className="text-indigo-400 text-xs block -mt-0.5">Security Platform</span>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="relative space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-white leading-tight">
              Enterprise-Grade
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-violet-400">
                Authentication
              </span>
            </h1>
            <p className="mt-4 text-slate-400 text-lg leading-relaxed">
              Bank-level security for your organization. JWT tokens, RBAC, audit logs, and real-time threat detection.
            </p>
          </div>

          {/* Feature list */}
          <div className="space-y-4">
            {[
              {
                icon: <Lock size={16} className="text-indigo-400" />,
                title: 'Zero-Trust Security',
                desc: 'JWT + refresh token rotation, bcrypt hashing, rate limiting',
              },
              {
                icon: <Shield size={16} className="text-violet-400" />,
                title: 'Role-Based Access Control',
                desc: 'Granular permissions across Super Admin, Company Admin, Manager, Employee',
              },
              {
                icon: <Zap size={16} className="text-blue-400" />,
                title: 'Real-Time Audit Logs',
                desc: 'Complete activity tracking, session management, login history',
              },
            ].map((feature, i) => (
              <div key={i} className="flex items-start gap-3 p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm">
                <div className="w-8 h-8 bg-white/10 rounded-lg flex items-center justify-center shrink-0 mt-0.5">
                  {feature.icon}
                </div>
                <div>
                  <div className="text-white font-medium text-sm">{feature.title}</div>
                  <div className="text-slate-400 text-xs mt-0.5">{feature.desc}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Demo credentials */}
          <div className="p-4 rounded-xl bg-indigo-500/10 border border-indigo-500/20">
            <p className="text-indigo-300 text-xs font-semibold mb-2 uppercase tracking-wider">Demo Credentials</p>
            <div className="space-y-1.5 text-xs">
              {[
                { role: 'Super Admin', email: 'admin@enterprise.io', pwd: 'Admin@123456' },
                { role: 'Company Admin', email: 'company@enterprise.io', pwd: 'Company@123456' },
                { role: 'Manager', email: 'manager@enterprise.io', pwd: 'Manager@123456' },
                { role: 'Employee', email: 'employee@enterprise.io', pwd: 'Employee@123456' },
              ].map(c => (
                <div key={c.role} className="flex items-center gap-2">
                  <span className="text-slate-500 w-24 shrink-0">{c.role}:</span>
                  <span className="text-slate-300 font-mono">{c.email}</span>
                  <span className="text-slate-500">·</span>
                  <span className="text-slate-400 font-mono">{c.pwd}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="relative text-slate-600 text-xs">
          © 2024 EnterpriseAuth · SOC2 Compliant · GDPR Ready
        </div>
      </div>

      {/* Right Panel — Form */}
      <div className="flex-1 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-2 mb-8">
            <div className="w-8 h-8 bg-gradient-to-br from-indigo-400 to-violet-500 rounded-lg flex items-center justify-center">
              <Shield size={16} className="text-white" />
            </div>
            <span className="text-white font-bold">EnterpriseAuth</span>
          </div>

          <div className="bg-white/[0.03] backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
            <div className="mb-8">
              <h2 className="text-2xl font-bold text-white">{title}</h2>
              <p className="mt-1.5 text-slate-400 text-sm">{subtitle}</p>
            </div>
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}
