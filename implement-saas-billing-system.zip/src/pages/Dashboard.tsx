import { useMemo } from 'react';
import {
  AlertTriangle, CheckCircle2,
  XCircle, Timer, MapPin, ArrowUpRight, Activity
} from 'lucide-react';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import { format, subDays, parseISO } from 'date-fns';
import { useAppStore } from '../store/appStore';
import { db } from '../data/mockDatabase';
import { StatCard, Card } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

export function Dashboard() {
  const { currentCompany, currentUser, currentPlan, setActiveView, setShowUpgradeModal } = useAppStore();

  const employees = db.getUsers(currentCompany?.id || '');
  const attendance = db.getAttendance(currentCompany?.id || '');
  const today = format(new Date(), 'yyyy-MM-dd');
  const todayRecords = attendance.filter(a => a.date === today);
  const todayPresent = todayRecords.filter(a => a.status === 'present' || a.status === 'remote').length;
  const todayLate = todayRecords.filter(a => a.status === 'late').length;
  const todayAbsent = todayRecords.filter(a => a.status === 'absent').length;
  const todayRemote = todayRecords.filter(a => a.status === 'remote').length;
  const totalEmployees = employees.filter(u => u.role === 'employee' || u.role === 'hr_manager').length;
  const attendanceRate = totalEmployees > 0 ? Math.round((todayPresent / totalEmployees) * 100) : 0;

  // Weekly trend
  const weeklyData = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) => {
      const d = subDays(new Date(), 6 - i);
      const dateStr = format(d, 'yyyy-MM-dd');
      const dayRecords = attendance.filter(a => a.date === dateStr);
      const present = dayRecords.filter(a => a.status === 'present' || a.status === 'remote').length;
      const absent = dayRecords.filter(a => a.status === 'absent').length;
      const late = dayRecords.filter(a => a.status === 'late').length;
      return {
        day: format(d, 'EEE'),
        present,
        absent,
        late,
        rate: totalEmployees > 0 ? Math.round((present / Math.max(totalEmployees, 1)) * 100) : 0,
      };
    });
  }, [attendance, totalEmployees]);

  // Status distribution
  const statusDist = useMemo(() => {
    const last7 = attendance.filter(a => {
      const d = parseISO(a.date);
      return d >= subDays(new Date(), 7);
    });
    const counts: Record<string, number> = { present: 0, late: 0, absent: 0, remote: 0, on_leave: 0 };
    last7.forEach(r => { counts[r.status] = (counts[r.status] || 0) + 1; });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [attendance]);

  // Recent activity
  const recentActivity = attendance
    .filter(a => a.checkIn)
    .sort((a, b) => (b.checkIn || '').localeCompare(a.checkIn || ''))
    .slice(0, 6);

  const getUser = (userId: string) => employees.find(u => u.id === userId);

  const isAtLimit = currentPlan?.limits.employees !== 'unlimited' &&
    typeof currentPlan?.limits.employees === 'number' &&
    employees.length >= currentPlan.limits.employees * 0.9;

  return (
    <div className="p-6 space-y-6">
      {/* Limit Warning Banner */}
      {isAtLimit && (
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-amber-500 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-amber-800">Approaching Employee Limit</p>
              <p className="text-xs text-amber-600">You're at {employees.length}/{currentPlan?.limits.employees} employees on your {currentPlan?.name} plan.</p>
            </div>
          </div>
          <Button size="sm" onClick={() => setShowUpgradeModal(true)}>
            Upgrade Plan
          </Button>
        </div>
      )}

      {/* Welcome */}
      <div>
        <h2 className="text-xl font-bold text-slate-900">Good morning, {currentUser?.firstName}! 👋</h2>
        <p className="text-slate-500 mt-0.5">{format(new Date(), 'EEEE, MMMM do yyyy')} · {currentCompany?.name}</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Present Today"
          value={todayPresent}
          change={`${attendanceRate}% attendance rate`}
          changeType={attendanceRate >= 85 ? 'positive' : attendanceRate >= 70 ? 'neutral' : 'negative'}
          icon={<CheckCircle2 className="h-5 w-5 text-emerald-600" />}
          iconBg="bg-emerald-100"
          subtitle={`of ${totalEmployees} employees`}
        />
        <StatCard
          title="Late Today"
          value={todayLate}
          change={todayLate > 3 ? 'Above average' : 'Normal'}
          changeType={todayLate > 3 ? 'negative' : 'positive'}
          icon={<Timer className="h-5 w-5 text-amber-600" />}
          iconBg="bg-amber-100"
        />
        <StatCard
          title="Absent Today"
          value={todayAbsent}
          change={`${Math.round((todayAbsent / Math.max(totalEmployees, 1)) * 100)}% of workforce`}
          changeType={todayAbsent > 5 ? 'negative' : 'neutral'}
          icon={<XCircle className="h-5 w-5 text-red-500" />}
          iconBg="bg-red-100"
        />
        <StatCard
          title="Remote Today"
          value={todayRemote}
          change="Working remotely"
          changeType="neutral"
          icon={<MapPin className="h-5 w-5 text-indigo-600" />}
          iconBg="bg-indigo-100"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Weekly Attendance Trend */}
        <Card className="p-6 lg:col-span-2">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="font-semibold text-slate-900">Weekly Attendance Trend</h3>
              <p className="text-xs text-slate-500 mt-0.5">Last 7 working days</p>
            </div>
            <Badge variant="info">
              <Activity className="h-3 w-3 mr-1" />
              Live
            </Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="presentGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#6366f1" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <Tooltip
                contentStyle={{ background: '#fff', border: '1px solid #e2e8f0', borderRadius: '12px', fontSize: '12px' }}
              />
              <Area type="monotone" dataKey="present" stroke="#6366f1" strokeWidth={2.5} fill="url(#presentGrad)" name="Present" />
              <Area type="monotone" dataKey="late" stroke="#f59e0b" strokeWidth={2} fill="none" name="Late" strokeDasharray="4 2" />
              <Area type="monotone" dataKey="absent" stroke="#ef4444" strokeWidth={2} fill="none" name="Absent" strokeDasharray="4 2" />
            </AreaChart>
          </ResponsiveContainer>
        </Card>

        {/* Status Distribution */}
        <Card className="p-6">
          <h3 className="font-semibold text-slate-900 mb-1">Status Distribution</h3>
          <p className="text-xs text-slate-500 mb-6">Last 7 days</p>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={statusDist} cx="50%" cy="50%" innerRadius={45} outerRadius={70} paddingAngle={3} dataKey="value">
                {statusDist.map((_, i) => (
                  <Cell key={i} fill={COLORS[i % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: '12px', fontSize: '12px' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {statusDist.map((s, i) => (
              <div key={s.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                  <span className="text-slate-600 capitalize">{s.name.replace('_', ' ')}</span>
                </div>
                <span className="font-semibold text-slate-700">{s.value}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-slate-900">Recent Check-ins</h3>
            <button onClick={() => setActiveView('attendance')} className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1">
              View all <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>
          <div className="space-y-3">
            {recentActivity.map(record => {
              const user = getUser(record.userId);
              if (!user) return null;
              const statusColors = {
                present: 'success', late: 'warning', absent: 'danger', remote: 'info', half_day: 'warning', on_leave: 'purple'
              } as const;
              return (
                <div key={record.id} className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-xl bg-slate-100 flex items-center justify-center text-sm flex-shrink-0">
                    {user.avatar}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 truncate">{user.firstName} {user.lastName}</p>
                    <p className="text-xs text-slate-500">
                      {record.checkIn ? `Checked in at ${format(new Date(record.checkIn), 'h:mm a')}` : 'No check-in'} · {record.date}
                    </p>
                  </div>
                  <Badge variant={statusColors[record.status] || 'default'} className="capitalize flex-shrink-0">
                    {record.status.replace('_', ' ')}
                  </Badge>
                </div>
              );
            })}
          </div>
        </Card>

        {/* Departments Overview */}
        <Card className="p-6">
          <div className="flex items-center justify-between mb-5">
            <h3 className="font-semibold text-slate-900">Department Summary</h3>
            <button onClick={() => setActiveView('departments')} className="text-xs text-indigo-600 hover:text-indigo-700 font-medium flex items-center gap-1">
              Manage <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>
          <div className="space-y-3">
            {db.getDepartments(currentCompany?.id || '').map(dept => {
              const rate = Math.floor(Math.random() * 20 + 80);
              return (
                <div key={dept.id} className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-slate-700">{dept.name}</span>
                      <span className="text-xs text-slate-500">{dept.headcount} employees</span>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all"
                        style={{ width: `${rate}%` }}
                      />
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">{rate}% attendance today</p>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}
