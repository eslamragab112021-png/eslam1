import React from 'react';
import {
  LayoutDashboard, Users, Clock, BarChart3, Settings, Bell,
  Building2, CreditCard, ShieldCheck, ChevronLeft, ChevronRight,
  Zap, LogOut, Globe, TrendingUp, UserCheck,
  CalendarDays, AlertCircle, Package, Layers, Star
} from 'lucide-react';
import { cn } from '../../utils/cn';
import { useAppStore } from '../../store/appStore';

interface NavItem {
  id: string;
  label: string;
  icon: React.ReactNode;
  badge?: string | number;
  badgeVariant?: 'success' | 'warning' | 'danger' | 'info' | 'purple';
  dividerBefore?: boolean;
  section?: string;
}

export function Sidebar() {
  const { activeView, setActiveView, sidebarCollapsed, toggleSidebar, currentUser, currentCompany, currentPlan, unreadCount, logout } = useAppStore();

  const superAdminNav: NavItem[] = [
    { id: 'superadmin-dashboard', label: 'Platform Overview', icon: <Globe className="h-4.5 w-4.5" />, section: 'Platform' },
    { id: 'superadmin-companies', label: 'Companies', icon: <Building2 className="h-4.5 w-4.5" />, section: 'Platform' },
    { id: 'superadmin-subscriptions', label: 'Subscriptions', icon: <Package className="h-4.5 w-4.5" />, section: 'Platform' },
    { id: 'superadmin-revenue', label: 'Revenue Analytics', icon: <TrendingUp className="h-4.5 w-4.5" />, section: 'Platform' },
    { id: 'superadmin-usage', label: 'Usage Analytics', icon: <BarChart3 className="h-4.5 w-4.5" />, section: 'Platform' },
    { id: 'superadmin-notifications', label: 'Notifications', icon: <Bell className="h-4.5 w-4.5" />, dividerBefore: true, section: 'System' },
    { id: 'superadmin-settings', label: 'Platform Settings', icon: <Settings className="h-4.5 w-4.5" />, section: 'System' },
  ];

  const companyNav: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="h-4.5 w-4.5" />, section: 'Main' },
    { id: 'attendance', label: 'Attendance', icon: <Clock className="h-4.5 w-4.5" />, section: 'Main' },
    { id: 'employees', label: 'Employees', icon: <Users className="h-4.5 w-4.5" />, section: 'Main' },
    { id: 'departments', label: 'Departments', icon: <Layers className="h-4.5 w-4.5" />, section: 'Main' },
    { id: 'leaves', label: 'Leave Management', icon: <CalendarDays className="h-4.5 w-4.5" />, section: 'Main' },
    { id: 'reports', label: 'Reports', icon: <BarChart3 className="h-4.5 w-4.5" />, section: 'Analytics' },
    { id: 'analytics', label: 'Analytics', icon: <TrendingUp className="h-4.5 w-4.5" />, dividerBefore: true, section: 'Analytics' },
    { id: 'alerts', label: 'Alerts', icon: <AlertCircle className="h-4.5 w-4.5" />, section: 'Analytics' },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="h-4.5 w-4.5" />, badge: unreadCount > 0 ? unreadCount : undefined, badgeVariant: 'danger', section: 'Account' },
    { id: 'billing', label: 'Billing & Plan', icon: <CreditCard className="h-4.5 w-4.5" />, dividerBefore: true, section: 'Account' },
    { id: 'team', label: 'Team Access', icon: <UserCheck className="h-4.5 w-4.5" />, section: 'Account' },
    { id: 'integrations', label: 'Integrations', icon: <Zap className="h-4.5 w-4.5" />, section: 'Account' },
    { id: 'settings', label: 'Settings', icon: <Settings className="h-4.5 w-4.5" />, section: 'Account' },
  ];

  const navItems = currentUser?.role === 'superadmin' ? superAdminNav : companyNav;
  const isSuperAdmin = currentUser?.role === 'superadmin';

  return (
    <aside className={cn(
      'fixed left-0 top-0 h-screen bg-slate-900 flex flex-col transition-all duration-300 z-40',
      sidebarCollapsed ? 'w-16' : 'w-64'
    )}>
      {/* Logo */}
      <div className="flex items-center h-16 px-4 border-b border-slate-800 flex-shrink-0">
        <div className="flex items-center gap-3 min-w-0">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center flex-shrink-0 shadow-lg">
            <Clock className="h-4 w-4 text-white" />
          </div>
          {!sidebarCollapsed && (
            <div className="min-w-0">
              <span className="font-bold text-white text-sm tracking-tight">AttendIQ</span>
              {isSuperAdmin && (
                <div className="flex items-center gap-1 mt-0.5">
                  <ShieldCheck className="h-3 w-3 text-amber-400" />
                  <span className="text-xs text-amber-400 font-medium">Super Admin</span>
                </div>
              )}
            </div>
          )}
        </div>
        <button
          onClick={toggleSidebar}
          className="ml-auto p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors flex-shrink-0"
        >
          {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </div>

      {/* Company info */}
      {!isSuperAdmin && currentCompany && !sidebarCollapsed && (
        <div className="px-3 py-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5 bg-slate-800/60 rounded-xl px-3 py-2">
            <span className="text-xl">{currentCompany.logo}</span>
            <div className="min-w-0">
              <p className="text-sm font-medium text-white truncate">{currentCompany.name}</p>
              <p className="text-xs text-slate-400 truncate">{currentCompany.domain}</p>
            </div>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
        {(() => {
          let lastSection = '';
          return navItems.map((item) => {
            const isNewSection = item.section && item.section !== lastSection;
            lastSection = item.section || '';
            return (
              <React.Fragment key={item.id}>
                {isNewSection && !sidebarCollapsed && (
                  <div className="px-3 pt-4 pb-1">
                    <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{item.section}</p>
                  </div>
                )}
                {item.dividerBefore && sidebarCollapsed && (
                  <div className="my-2 border-t border-slate-800" />
                )}
                <button
                  onClick={() => setActiveView(item.id)}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-150 group relative',
                    activeView === item.id
                      ? 'bg-indigo-600 text-white shadow-md shadow-indigo-900/30'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800',
                    sidebarCollapsed && 'justify-center'
                  )}
                  title={sidebarCollapsed ? item.label : undefined}
                >
                  <span className={activeView === item.id ? 'text-white' : 'text-slate-400 group-hover:text-white'}>
                    {item.icon}
                  </span>
                  {!sidebarCollapsed && (
                    <>
                      <span className="truncate">{item.label}</span>
                      {item.badge !== undefined && (
                        <span className="ml-auto bg-red-500 text-white text-xs font-bold rounded-full min-w-[18px] h-[18px] flex items-center justify-center px-1">
                          {item.badge}
                        </span>
                      )}
                    </>
                  )}
                  {sidebarCollapsed && item.badge !== undefined && (
                    <span className="absolute top-1 right-1 bg-red-500 text-white text-xs font-bold rounded-full w-4 h-4 flex items-center justify-center">
                      {typeof item.badge === 'number' && item.badge > 9 ? '9+' : item.badge}
                    </span>
                  )}
                </button>
              </React.Fragment>
            );
          });
        })()}
      </nav>

      {/* Plan Badge & User */}
      <div className="flex-shrink-0 border-t border-slate-800 p-3 space-y-2">
        {!isSuperAdmin && currentPlan && !sidebarCollapsed && (
          <div className="bg-gradient-to-r from-indigo-600/20 to-violet-600/20 border border-indigo-500/30 rounded-xl px-3 py-2">
            <div className="flex items-center gap-2">
              <Star className="h-3.5 w-3.5 text-amber-400" />
              <span className="text-xs font-semibold text-indigo-300">{currentPlan.name} Plan</span>
            </div>
            {currentPlan.id !== 'enterprise' && (
              <button
                onClick={() => useAppStore.getState().setActiveView('billing')}
                className="text-xs text-indigo-400 hover:text-indigo-300 mt-0.5 underline underline-offset-2"
              >
                Upgrade →
              </button>
            )}
          </div>
        )}
        <div className="flex items-center gap-3">
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-sm flex-shrink-0">
            {currentUser?.avatar}
          </div>
          {!sidebarCollapsed && (
            <>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white truncate">{currentUser?.firstName} {currentUser?.lastName}</p>
                <p className="text-xs text-slate-400 truncate">{currentUser?.email}</p>
              </div>
              <button onClick={logout} className="p-1.5 text-slate-500 hover:text-white transition-colors rounded-lg hover:bg-slate-800">
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </>
          )}
        </div>
      </div>
    </aside>
  );
}
