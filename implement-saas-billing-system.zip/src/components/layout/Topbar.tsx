import { useState, useRef, useEffect } from 'react';
import { Bell, Search, ChevronDown, Clock, CreditCard, AlertTriangle } from 'lucide-react';
import { cn } from '../../utils/cn';
import { useAppStore } from '../../store/appStore';
import { Badge } from '../ui/Badge';
import { formatDistanceToNow } from 'date-fns';

interface TopbarProps {
  title: string;
  subtitle?: string;
}

export function Topbar({ title, subtitle }: TopbarProps) {
  const { currentUser, unreadCount, notifications, markNotificationRead, markAllRead, setActiveView, logout } = useAppStore();
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const userRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setShowNotifications(false);
      if (userRef.current && !userRef.current.contains(e.target as Node)) setShowUserMenu(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'billing': return <CreditCard className="h-3.5 w-3.5 text-indigo-500" />;
      case 'attendance': return <Clock className="h-3.5 w-3.5 text-amber-500" />;
      case 'subscription': return <AlertTriangle className="h-3.5 w-3.5 text-violet-500" />;
      default: return <Bell className="h-3.5 w-3.5 text-slate-500" />;
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center px-6 gap-4 flex-shrink-0">
      <div className="flex-1 min-w-0">
        <h1 className="text-lg font-semibold text-slate-900 truncate">{title}</h1>
        {subtitle && <p className="text-xs text-slate-500 truncate">{subtitle}</p>}
      </div>

      {/* Search */}
      <div className="hidden md:flex items-center gap-2 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 w-64">
        <Search className="h-4 w-4 text-slate-400 flex-shrink-0" />
        <input
          type="text"
          placeholder="Search..."
          className="bg-transparent text-sm text-slate-600 placeholder-slate-400 outline-none w-full"
        />
        <kbd className="hidden lg:flex items-center text-xs text-slate-400 bg-slate-200 rounded px-1 py-0.5">⌘K</kbd>
      </div>

      {/* Notifications */}
      <div className="relative" ref={notifRef}>
        <button
          onClick={() => setShowNotifications(v => !v)}
          className="relative p-2 rounded-xl text-slate-500 hover:text-slate-700 hover:bg-slate-100 transition-colors"
        >
          <Bell className="h-5 w-5" />
          {unreadCount > 0 && (
            <span className="absolute top-1 right-1 bg-red-500 text-white text-xs font-bold rounded-full min-w-[16px] h-4 flex items-center justify-center px-1">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>

        {showNotifications && (
          <div className="absolute right-0 top-12 w-96 bg-white border border-slate-200 rounded-2xl shadow-xl z-50 overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 border-b border-slate-100">
              <h3 className="font-semibold text-slate-900 text-sm">Notifications</h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button onClick={markAllRead} className="text-xs text-indigo-600 hover:text-indigo-700 font-medium">
                    Mark all read
                  </button>
                )}
                <Badge variant="info">{unreadCount} new</Badge>
              </div>
            </div>
            <div className="max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="py-8 text-center text-slate-400 text-sm">No notifications</div>
              ) : (
                notifications.slice(0, 8).map(n => (
                  <div
                    key={n.id}
                    onClick={() => {
                      markNotificationRead(n.id);
                      if (n.actionUrl) setActiveView(n.actionUrl.replace('/', ''));
                      setShowNotifications(false);
                    }}
                    className={cn(
                      'flex items-start gap-3 px-4 py-3 hover:bg-slate-50 cursor-pointer border-b border-slate-50 last:border-0 transition-colors',
                      !n.isRead && 'bg-indigo-50/50'
                    )}
                  >
                    <div className="mt-0.5 p-2 rounded-lg bg-slate-100 flex-shrink-0">
                      {getCategoryIcon(n.category)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className={cn('text-sm truncate', !n.isRead ? 'font-semibold text-slate-900' : 'font-medium text-slate-700')}>{n.title}</p>
                      <p className="text-xs text-slate-500 mt-0.5 line-clamp-2">{n.message}</p>
                      <p className="text-xs text-slate-400 mt-1">
                        {formatDistanceToNow(new Date(n.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                    {!n.isRead && (
                      <div className="w-2 h-2 bg-indigo-500 rounded-full flex-shrink-0 mt-1.5" />
                    )}
                  </div>
                ))
              )}
            </div>
            <div className="border-t border-slate-100 p-3 text-center">
              <button
                onClick={() => { setActiveView('notifications'); setShowNotifications(false); }}
                className="text-sm text-indigo-600 hover:text-indigo-700 font-medium"
              >
                View all notifications →
              </button>
            </div>
          </div>
        )}
      </div>

      {/* User menu */}
      <div className="relative" ref={userRef}>
        <button
          onClick={() => setShowUserMenu(v => !v)}
          className="flex items-center gap-2.5 p-1.5 rounded-xl hover:bg-slate-100 transition-colors"
        >
          <div className="h-8 w-8 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center text-sm">
            {currentUser?.avatar}
          </div>
          <div className="hidden md:block text-left">
            <p className="text-sm font-medium text-slate-800 leading-tight">{currentUser?.firstName} {currentUser?.lastName}</p>
            <p className="text-xs text-slate-500 leading-tight capitalize">{currentUser?.role?.replace('_', ' ')}</p>
          </div>
          <ChevronDown className="h-4 w-4 text-slate-400 hidden md:block" />
        </button>

        {showUserMenu && (
          <div className="absolute right-0 top-12 w-52 bg-white border border-slate-200 rounded-xl shadow-xl z-50 overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-100">
              <p className="text-sm font-semibold text-slate-900">{currentUser?.firstName} {currentUser?.lastName}</p>
              <p className="text-xs text-slate-500 mt-0.5">{currentUser?.email}</p>
            </div>
            <div className="py-1">
              <button onClick={() => { setActiveView('settings'); setShowUserMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Profile Settings</button>
              {currentUser?.role !== 'superadmin' && (
                <button onClick={() => { setActiveView('billing'); setShowUserMenu(false); }} className="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-slate-50">Billing & Plan</button>
              )}
              <div className="border-t border-slate-100 mt-1 pt-1">
                <button onClick={logout} className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50">Sign Out</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}
