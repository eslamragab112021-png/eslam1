import React from 'react';
import { cn } from '../../utils/cn';

interface BadgeProps {
  children: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'info' | 'purple' | 'outline';
  size?: 'sm' | 'md';
  className?: string;
}

export function Badge({ children, variant = 'default', size = 'sm', className }: BadgeProps) {
  return (
    <span className={cn(
      'inline-flex items-center font-medium rounded-full',
      size === 'sm' ? 'px-2 py-0.5 text-xs' : 'px-3 py-1 text-sm',
      variant === 'default' && 'bg-slate-100 text-slate-700',
      variant === 'success' && 'bg-emerald-50 text-emerald-700 ring-1 ring-emerald-200',
      variant === 'warning' && 'bg-amber-50 text-amber-700 ring-1 ring-amber-200',
      variant === 'danger' && 'bg-red-50 text-red-700 ring-1 ring-red-200',
      variant === 'info' && 'bg-blue-50 text-blue-700 ring-1 ring-blue-200',
      variant === 'purple' && 'bg-violet-50 text-violet-700 ring-1 ring-violet-200',
      variant === 'outline' && 'bg-transparent ring-1 ring-slate-200 text-slate-600',
      className
    )}>
      {children}
    </span>
  );
}
