// ============================================================
// ATTENDIQ SAAS PLATFORM — CORE TYPES
// ============================================================

export type PlanId = 'free' | 'pro' | 'enterprise';
export type BillingCycle = 'monthly' | 'annual';
export type SubscriptionStatus = 'active' | 'past_due' | 'cancelled' | 'trialing' | 'paused';
export type InvoiceStatus = 'paid' | 'open' | 'void' | 'uncollectible';
export type UserRole = 'superadmin' | 'company_admin' | 'hr_manager' | 'employee';
export type AttendanceStatus = 'present' | 'absent' | 'late' | 'half_day' | 'remote' | 'on_leave';
export type NotificationType = 'email' | 'in_app' | 'sms';
export type NotificationCategory = 'attendance' | 'billing' | 'subscription' | 'system' | 'hr';
export type PaymentMethod = 'card' | 'bank_transfer' | 'crypto';

// ─── PLANS ───────────────────────────────────────────────────
export interface Plan {
  id: PlanId;
  name: string;
  description: string;
  price: { monthly: number; annual: number };
  currency: string;
  features: string[];
  limits: {
    employees: number | 'unlimited';
    departments: number | 'unlimited';
    dataRetentionDays: number | 'unlimited';
    apiCallsPerMonth: number | 'unlimited';
    reportExports: number | 'unlimited';
    integrations: number | 'unlimited';
    adminUsers: number | 'unlimited';
  };
  stripeProductId: string;
  stripePriceIdMonthly: string;
  stripePriceIdAnnual: string;
  popular?: boolean;
  color: string;
  badge?: string;
}

// ─── TENANT / COMPANY ────────────────────────────────────────
export interface Company {
  id: string;
  name: string;
  slug: string;
  domain: string;
  logo?: string;
  industry: string;
  size: string;
  country: string;
  timezone: string;
  currency: string;
  address: string;
  phone: string;
  email: string;
  website?: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
  stripeCustomerId: string;
  settings: TenantSettings;
}

export interface TenantSettings {
  companyId: string;
  workingHoursStart: string;
  workingHoursEnd: string;
  workingDays: string[];
  lateThresholdMinutes: number;
  overtimeThresholdMinutes: number;
  allowRemoteWork: boolean;
  requireLocationCheckin: boolean;
  notifyOnLate: boolean;
  notifyOnAbsent: boolean;
  notifyOnOvertime: boolean;
  slackWebhook?: string;
  teamsWebhook?: string;
  customBranding: boolean;
  primaryColor: string;
  accentColor: string;
  twoFactorRequired: boolean;
  sessionTimeoutMinutes: number;
}

// ─── SUBSCRIPTION ─────────────────────────────────────────────
export interface Subscription {
  id: string;
  companyId: string;
  planId: PlanId;
  status: SubscriptionStatus;
  billingCycle: BillingCycle;
  currentPeriodStart: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
  cancelledAt?: string;
  trialStart?: string;
  trialEnd?: string;
  stripeSubscriptionId: string;
  stripePriceId: string;
  quantity: number;
  unitAmount: number;
  currency: string;
  discount?: {
    couponId: string;
    percentOff: number;
    amountOff: number;
    validUntil: string;
  };
  metadata: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

// ─── INVOICE ──────────────────────────────────────────────────
export interface Invoice {
  id: string;
  companyId: string;
  subscriptionId: string;
  stripeInvoiceId: string;
  number: string;
  status: InvoiceStatus;
  amount: number;
  amountPaid: number;
  amountDue: number;
  currency: string;
  periodStart: string;
  periodEnd: string;
  dueDate: string;
  paidAt?: string;
  items: InvoiceLineItem[];
  paymentMethodType?: PaymentMethod;
  last4?: string;
  downloadUrl: string;
  createdAt: string;
}

export interface InvoiceLineItem {
  id: string;
  description: string;
  quantity: number;
  unitAmount: number;
  amount: number;
  currency: string;
  period?: { start: string; end: string };
}

// ─── BILLING HISTORY ─────────────────────────────────────────
export interface BillingHistory {
  id: string;
  companyId: string;
  event: 'payment_succeeded' | 'payment_failed' | 'subscription_created' | 'subscription_updated' | 'subscription_cancelled' | 'refund_issued' | 'invoice_created' | 'trial_started' | 'trial_ended' | 'plan_upgraded' | 'plan_downgraded';
  amount?: number;
  currency?: string;
  description: string;
  metadata: Record<string, string>;
  createdAt: string;
}

// ─── USER ─────────────────────────────────────────────────────
export interface User {
  id: string;
  companyId: string;
  email: string;
  firstName: string;
  lastName: string;
  role: UserRole;
  departmentId?: string;
  avatar?: string;
  phone?: string;
  employeeId: string;
  jobTitle: string;
  hireDate: string;
  isActive: boolean;
  lastLoginAt?: string;
  createdAt: string;
  twoFactorEnabled: boolean;
  preferences: {
    emailNotifications: boolean;
    pushNotifications: boolean;
    weeklyReport: boolean;
    theme: 'light' | 'dark' | 'system';
    language: string;
  };
}

// ─── DEPARTMENT ───────────────────────────────────────────────
export interface Department {
  id: string;
  companyId: string;
  name: string;
  code: string;
  managerId?: string;
  parentDepartmentId?: string;
  headcount: number;
  budget?: number;
  location?: string;
  createdAt: string;
}

// ─── ATTENDANCE ───────────────────────────────────────────────
export interface AttendanceRecord {
  id: string;
  companyId: string;
  userId: string;
  date: string;
  checkIn?: string;
  checkOut?: string;
  status: AttendanceStatus;
  hoursWorked: number;
  overtimeHours: number;
  breakMinutes: number;
  location?: { lat: number; lng: number; address: string };
  notes?: string;
  approvedBy?: string;
  createdAt: string;
}

// ─── NOTIFICATION ─────────────────────────────────────────────
export interface Notification {
  id: string;
  companyId: string;
  userId: string;
  type: NotificationType;
  category: NotificationCategory;
  title: string;
  message: string;
  isRead: boolean;
  actionUrl?: string;
  actionLabel?: string;
  metadata?: Record<string, string>;
  createdAt: string;
  readAt?: string;
}

// ─── ANALYTICS ────────────────────────────────────────────────
export interface RevenueAnalytics {
  mrr: number;
  arr: number;
  mrrGrowth: number;
  churnRate: number;
  ltv: number;
  arpu: number;
  newMrr: number;
  expansionMrr: number;
  contractionMrr: number;
  churnedMrr: number;
  activeSubscriptions: number;
  trialingSubscriptions: number;
  cancelledThisMonth: number;
  totalRevenue: number;
  revenueByPlan: { planId: PlanId; revenue: number; count: number }[];
  monthlyRevenue: { month: string; revenue: number; subscriptions: number }[];
}

export interface UsageAnalytics {
  companyId: string;
  period: string;
  totalEmployees: number;
  activeEmployees: number;
  totalCheckIns: number;
  avgAttendanceRate: number;
  lateArrivals: number;
  absences: number;
  overtimeHours: number;
  remoteCheckIns: number;
  apiCallsUsed: number;
  reportsGenerated: number;
  storageUsedMb: number;
}

// ─── ONBOARDING ───────────────────────────────────────────────
export interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  completed: boolean;
  required: boolean;
  action?: string;
}

export interface OnboardingState {
  companyId: string;
  currentStep: number;
  steps: OnboardingStep[];
  completedAt?: string;
  skippedAt?: string;
}

// ─── APP STATE ────────────────────────────────────────────────
export interface AppState {
  currentUser: User | null;
  currentCompany: Company | null;
  currentSubscription: Subscription | null;
  currentPlan: Plan | null;
  isAuthenticated: boolean;
  isSuperAdmin: boolean;
  notifications: Notification[];
  unreadNotifications: number;
  onboarding: OnboardingState | null;
  sidebarCollapsed: boolean;
  activeView: string;
}
