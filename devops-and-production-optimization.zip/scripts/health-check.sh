#!/usr/bin/env bash
# ============================================================
# HEALTH CHECK SCRIPT
# Checks all services and outputs status report
# Usage: ./scripts/health-check.sh [--url http://localhost]
# ============================================================

set -euo pipefail

BASE_URL="${1:-http://localhost}"
PASS=0; FAIL=0

check() {
  local name="$1"
  local url="$2"
  local expected="${3:-200}"

  STATUS=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$url" 2>/dev/null || echo "000")
  if [[ "$STATUS" == "$expected" ]]; then
    echo -e "  ✅ ${name}: HTTP ${STATUS}"
    ((PASS++)) || true
  else
    echo -e "  ❌ ${name}: HTTP ${STATUS} (expected ${expected})"
    ((FAIL++)) || true
  fi
}

echo ""
echo "🔍 Health Check Report — $(date)"
echo "════════════════════════════════"
echo ""

echo "📡 Endpoints:"
check "Main App"     "$BASE_URL/"      "200"
check "Health API"   "$BASE_URL/health" "200"

echo ""
echo "🐳 Docker Services:"
docker-compose ps --format "  {{.Name}}\t{{.Status}}" 2>/dev/null || echo "  (docker-compose not running)"

echo ""
echo "💾 Resource Usage:"
docker stats --no-stream --format "  {{.Name}}: CPU {{.CPUPerc}} | MEM {{.MemUsage}}" 2>/dev/null || echo "  (no containers running)"

echo ""
echo "════════════════════════════════"
echo "Results: ✅ ${PASS} passed | ❌ ${FAIL} failed"

[[ $FAIL -eq 0 ]] && exit 0 || exit 1
