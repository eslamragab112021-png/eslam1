#!/usr/bin/env bash
# ============================================================
# SSL CERTIFICATE SETUP
# Options:
#   1. Let's Encrypt (production)
#   2. Self-signed (development/testing)
# Usage: ./scripts/setup-ssl.sh [--domain yourdomain.com] [--self-signed]
# ============================================================

set -euo pipefail

DOMAIN="${DOMAIN:-localhost}"
SELF_SIGNED=false
EMAIL="${SSL_EMAIL:-admin@yourdomain.com}"
SSL_DIR="./ssl"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain)      DOMAIN="$2";  shift 2 ;;
    --email)       EMAIL="$2";   shift 2 ;;
    --self-signed) SELF_SIGNED=true; shift ;;
    *) echo "Unknown: $1"; exit 1 ;;
  esac
done

mkdir -p "$SSL_DIR"

if $SELF_SIGNED; then
  echo "🔐 Generating self-signed certificate for: $DOMAIN"
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout "$SSL_DIR/privkey.pem" \
    -out "$SSL_DIR/fullchain.pem" \
    -subj "/CN=${DOMAIN}/O=DevOps Dashboard/C=US" \
    -addext "subjectAltName=DNS:${DOMAIN},DNS:www.${DOMAIN},IP:127.0.0.1"
  echo "✅ Self-signed cert created at $SSL_DIR/"
else
  echo "🔐 Obtaining Let's Encrypt certificate for: $DOMAIN"
  command -v certbot >/dev/null 2>&1 || {
    echo "Installing certbot..."
    apt-get update && apt-get install -y certbot
  }

  # Stop nginx if running (certbot needs port 80)
  docker-compose stop frontend 2>/dev/null || true

  certbot certonly --standalone \
    --non-interactive \
    --agree-tos \
    --email "$EMAIL" \
    -d "$DOMAIN" \
    -d "www.$DOMAIN"

  # Copy to our ssl directory
  cp "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" "$SSL_DIR/fullchain.pem"
  cp "/etc/letsencrypt/live/$DOMAIN/privkey.pem" "$SSL_DIR/privkey.pem"
  chmod 644 "$SSL_DIR/fullchain.pem"
  chmod 600 "$SSL_DIR/privkey.pem"

  # Setup auto-renewal cron
  (crontab -l 2>/dev/null; echo "0 12 * * * /usr/bin/certbot renew --quiet && cp /etc/letsencrypt/live/$DOMAIN/*.pem ./ssl/ && docker-compose restart frontend") | crontab -

  echo "✅ Let's Encrypt cert installed. Auto-renewal configured."

  # Restart nginx
  docker-compose start frontend
fi

echo ""
echo "📜 Certificate details:"
openssl x509 -in "$SSL_DIR/fullchain.pem" -text -noout | grep -E "(Subject:|DNS:|Not After)"
