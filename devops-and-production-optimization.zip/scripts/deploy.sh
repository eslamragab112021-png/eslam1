#!/usr/bin/env bash
# ============================================================
# PRODUCTION DEPLOYMENT SCRIPT
# Usage: ./scripts/deploy.sh [--env production|staging] [--version v1.0.0]
# ============================================================

set -euo pipefail

# ── Colors ──────────────────────────────────────────────────
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

# ── Defaults ────────────────────────────────────────────────
ENV="${DEPLOY_ENV:-production}"
VERSION="${APP_VERSION:-latest}"
COMPOSE_FILE="docker-compose.yml"
HEALTH_URL="http://localhost/health"
MAX_RETRIES=10
RETRY_DELAY=5

# ── Parse args ──────────────────────────────────────────────
while [[ $# -gt 0 ]]; do
  case "$1" in
    --env)    ENV="$2";     shift 2 ;;
    --version) VERSION="$2"; shift 2 ;;
    --help)
      echo "Usage: $0 [--env staging|production] [--version <tag>]"
      exit 0
      ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ── Logging helpers ─────────────────────────────────────────
log()     { echo -e "${BLUE}[$(date +'%H:%M:%S')]${NC} $*"; }
success() { echo -e "${GREEN}[$(date +'%H:%M:%S')] ✅ $*${NC}"; }
warn()    { echo -e "${YELLOW}[$(date +'%H:%M:%S')] ⚠️  $*${NC}"; }
error()   { echo -e "${RED}[$(date +'%H:%M:%S')] ❌ $*${NC}" >&2; }
header()  { echo -e "\n${BOLD}${CYAN}══════════════════════════════════════${NC}"; echo -e "${BOLD}${CYAN}  $*${NC}"; echo -e "${BOLD}${CYAN}══════════════════════════════════════${NC}\n"; }

# ── Pre-flight checks ───────────────────────────────────────
preflight() {
  header "Pre-flight Checks"

  command -v docker      >/dev/null 2>&1 || { error "Docker not installed"; exit 1; }
  command -v docker-compose >/dev/null 2>&1 || { error "docker-compose not installed"; exit 1; }

  if [[ ! -f ".env" ]]; then
    warn ".env file not found, copying from .env.example"
    cp .env.example .env
    warn "⚠️  Please update .env with real values before production deploy!"
  fi

  success "Pre-flight checks passed"
}

# ── Backup current state ─────────────────────────────────────
backup() {
  header "Creating Backup"
  BACKUP_DIR="./backups/$(date +%Y%m%d_%H%M%S)"
  mkdir -p "$BACKUP_DIR"
  docker-compose images > "$BACKUP_DIR/images.txt" 2>/dev/null || true
  success "Backup saved to $BACKUP_DIR"
}

# ── Pull latest images ──────────────────────────────────────
pull_images() {
  header "Pulling Latest Images"
  log "Pulling version: ${VERSION}"
  docker-compose pull || warn "Some images could not be pulled (may be building locally)"
  success "Images pulled"
}

# ── Build if needed ──────────────────────────────────────────
build() {
  header "Building Application"
  log "Building production Docker image..."
  docker-compose build \
    --build-arg VITE_APP_VERSION="${VERSION}" \
    --build-arg VITE_BUILD_DATE="$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
    --no-cache
  success "Build complete"
}

# ── Deploy ───────────────────────────────────────────────────
deploy() {
  header "Deploying to ${ENV}"
  log "Starting containers..."
  docker-compose up -d --remove-orphans
  success "Containers started"
}

# ── Health check ─────────────────────────────────────────────
health_check() {
  header "Health Check"
  log "Waiting for service to be healthy..."

  for i in $(seq 1 $MAX_RETRIES); do
    if curl -sf "${HEALTH_URL}" > /dev/null 2>&1; then
      success "Service is healthy! (attempt $i/$MAX_RETRIES)"
      return 0
    fi
    log "Attempt $i/$MAX_RETRIES — waiting ${RETRY_DELAY}s..."
    sleep $RETRY_DELAY
  done

  error "Health check failed after $MAX_RETRIES attempts!"
  error "Check logs: docker-compose logs frontend"
  return 1
}

# ── Cleanup ─────────────────────────────────────────────────
cleanup() {
  header "Cleanup"
  log "Removing dangling images..."
  docker image prune -f
  success "Cleanup complete"
}

# ── Print status ─────────────────────────────────────────────
print_status() {
  header "Deployment Status"
  docker-compose ps
  echo ""
  success "Deployment to ${ENV} complete!"
  echo -e "${BOLD}Version:${NC}  ${VERSION}"
  echo -e "${BOLD}Health:${NC}   ${HEALTH_URL}"
  echo -e "${BOLD}Logs:${NC}     docker-compose logs -f frontend"
}

# ── Rollback ─────────────────────────────────────────────────
rollback() {
  error "Deployment failed — rolling back..."
  docker-compose down
  if ls -t ./backups/*/images.txt 2>/dev/null | head -1 | xargs -I{} dirname {} | xargs -I{} cat {}/images.txt; then
    warn "Previous image info available in ./backups/"
  fi
  error "Rollback complete. Manual intervention may be required."
  exit 1
}

# ── Main ─────────────────────────────────────────────────────
main() {
  header "🚀 DevOps Dashboard Deployment"
  echo -e "  Environment: ${BOLD}${ENV}${NC}"
  echo -e "  Version:     ${BOLD}${VERSION}${NC}"
  echo -e "  Date:        ${BOLD}$(date)${NC}"

  trap rollback ERR

  preflight
  backup
  pull_images
  build
  deploy
  health_check
  cleanup
  print_status
}

main "$@"
