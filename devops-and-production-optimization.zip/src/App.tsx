// ============================================================
// App — DevOps Production Dashboard
// Enterprise-grade DevOps & deployment control center
// ============================================================

import { useState, useEffect, Suspense, lazy } from "react";
import { ErrorBoundary } from "./components/ErrorBoundary";
import { Sidebar } from "./components/Sidebar";
import { Header } from "./components/Header";
import { alerts } from "./data/mockData";

// Lazy-load tab views for code splitting
const OverviewView     = lazy(() => import("./views/OverviewView").then(m => ({ default: m.OverviewView })));
const ServicesView     = lazy(() => import("./views/ServicesView").then(m => ({ default: m.ServicesView })));
const PipelineView     = lazy(() => import("./views/PipelineView").then(m => ({ default: m.PipelineView })));
const ContainersView   = lazy(() => import("./views/ContainersView").then(m => ({ default: m.ContainersView })));
const DeploymentsView  = lazy(() => import("./views/DeploymentsView").then(m => ({ default: m.DeploymentsView })));
const SecurityView     = lazy(() => import("./views/SecurityView").then(m => ({ default: m.SecurityView })));
const MonitoringView   = lazy(() => import("./views/MonitoringView").then(m => ({ default: m.MonitoringView })));
const InfrastructureView = lazy(() => import("./views/InfrastructureView").then(m => ({ default: m.InfrastructureView })));
const AlertsView       = lazy(() => import("./views/AlertsView").then(m => ({ default: m.AlertsView })));
const SettingsView     = lazy(() => import("./views/SettingsView").then(m => ({ default: m.SettingsView })));

const tabTitles: Record<string, string> = {
  overview:       "Overview",
  services:       "Services",
  pipeline:       "CI/CD Pipeline",
  containers:     "Docker Containers",
  deployments:    "Deployments",
  security:       "Security",
  monitoring:     "Monitoring",
  infrastructure: "Infrastructure",
  alerts:         "Alerts",
  settings:       "Settings",
};

function LoadingFallback() {
  return (
    <div className="flex items-center justify-center py-24">
      <div className="flex flex-col items-center gap-3">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-violet-600 border-t-transparent" />
        <p className="text-xs text-slate-500">Loading...</p>
      </div>
    </div>
  );
}

function ViewRenderer({ tab }: { tab: string }) {
  switch (tab) {
    case "overview":       return <OverviewView />;
    case "services":       return <ServicesView />;
    case "pipeline":       return <PipelineView />;
    case "containers":     return <ContainersView />;
    case "deployments":    return <DeploymentsView />;
    case "security":       return <SecurityView />;
    case "monitoring":     return <MonitoringView />;
    case "infrastructure": return <InfrastructureView />;
    case "alerts":         return <AlertsView />;
    case "settings":       return <SettingsView />;
    default:               return <OverviewView />;
  }
}

export default function App() {
  const [activeTab, setActiveTab] = useState("overview");
  const [lastRefresh, setLastRefresh] = useState("just now");
  const [tick, setTick] = useState(0);

  // Simulate live data refresh
  useEffect(() => {
    const interval = setInterval(() => {
      setTick(t => t + 1);
      const mins = Math.floor((Date.now() / 1000) % 60);
      setLastRefresh(mins < 2 ? "just now" : `${mins}s ago`);
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleRefresh = () => {
    setLastRefresh("just now");
    setTick(t => t + 1);
  };

  const unackedAlerts = alerts.filter(a => !a.acknowledged).length;

  return (
    <ErrorBoundary>
      <div className="flex h-screen overflow-hidden bg-slate-950 text-white">
        {/* Sidebar */}
        <Sidebar
          activeTab={activeTab}
          onTabChange={setActiveTab}
          alertCount={unackedAlerts}
        />

        {/* Main content area */}
        <div className="flex flex-1 flex-col overflow-hidden">
          <Header
            alertCount={unackedAlerts}
            lastRefresh={lastRefresh}
            onRefresh={handleRefresh}
            onAlertsClick={() => setActiveTab("alerts")}
          />

          {/* Page content */}
          <main className="flex-1 overflow-y-auto">
            <div className="p-6">
              {/* Page title */}
              <div className="mb-6">
                <h2 className="text-xl font-bold text-white">{tabTitles[activeTab]}</h2>
                <p className="text-xs text-slate-500">
                  {new Date().toLocaleDateString("en-US", {
                    weekday: "long", year: "numeric", month: "long", day: "numeric",
                    hour: "2-digit", minute: "2-digit"
                  })}
                  {" · "}
                  <span className="text-emerald-400">All systems operational</span>
                </p>
              </div>

              {/* Tab content with Suspense */}
              <Suspense fallback={<LoadingFallback />}>
                <ErrorBoundary>
                  <ViewRenderer tab={activeTab} key={`${activeTab}-${tick}`} />
                </ErrorBoundary>
              </Suspense>
            </div>
          </main>
        </div>
      </div>
    </ErrorBoundary>
  );
}
