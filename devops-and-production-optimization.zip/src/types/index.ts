// ============================================================
// Application Types
// ============================================================

export type Status = "healthy" | "warning" | "critical" | "unknown" | "building" | "deploying";
export type Environment = "production" | "staging" | "development";
export type Severity = "critical" | "high" | "medium" | "low" | "info";

export interface Service {
  id: string;
  name: string;
  status: Status;
  uptime: string;
  latency: number;
  requests: number;
  errorRate: number;
  version: string;
  environment: Environment;
  lastDeploy: string;
  healthUrl: string;
  replicas: { running: number; desired: number };
  cpu: number;
  memory: number;
}

export interface PipelineRun {
  id: string;
  branch: string;
  commit: string;
  commitMsg: string;
  author: string;
  avatar: string;
  status: "success" | "running" | "failed" | "cancelled" | "pending";
  duration: string;
  startedAt: string;
  jobs: PipelineJob[];
  environment: Environment;
}

export interface PipelineJob {
  name: string;
  status: "success" | "running" | "failed" | "skipped" | "pending";
  duration: string;
}

export interface Alert {
  id: string;
  severity: Severity;
  title: string;
  description: string;
  service: string;
  timestamp: string;
  acknowledged: boolean;
}

export interface MetricPoint {
  time: string;
  value: number;
}

export interface DockerContainer {
  id: string;
  name: string;
  image: string;
  status: string;
  cpu: number;
  memory: number;
  memoryLimit: number;
  ports: string[];
  uptime: string;
  restarts: number;
  health: "healthy" | "unhealthy" | "starting" | "none";
}

export interface DeploymentTarget {
  name: string;
  icon: string;
  status: Status;
  region: string;
  provider: string;
  url: string;
  lastDeploy: string;
}

export interface SecurityScan {
  id: string;
  type: "sast" | "dast" | "dependency" | "container" | "secrets";
  name: string;
  status: "passed" | "failed" | "warning" | "running";
  findings: { critical: number; high: number; medium: number; low: number };
  lastRun: string;
  coverage: number;
}
